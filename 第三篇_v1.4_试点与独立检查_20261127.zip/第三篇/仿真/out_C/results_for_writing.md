# 阶段 C 准备记录

2026-11-27。当前状态为 `not_run_due_to_pilot_stop`。阶段 A 试点触发自动停止，阶段 C 尚未执行控制仿真。

| 编号 | 项目 | 数量 | 来源 |
|---|---|---:|---|
| [R-C-PREP-01] | 工件训练输入 | 54 | inputs_frozen/workpiece_v14/surface_manifest.csv 第2～55行 |
| [R-C-PREP-02] | 工件测试输入 | 108 | inputs_frozen/workpiece_v14/surface_manifest.csv 第56～163行 |
| [R-C-PREP-03] | 可执行训练评估，已完成/应完成 | 0/41472 | checkpoint.json；manifest.csv 的 phase=train、status=queued |
| [R-C-PREP-04] | 可执行测试，已完成/应完成 | 0/6912 | checkpoint.json；manifest.csv 的 phase=test、status=queued |
| [R-C-PREP-05] | B2-fc 训练/测试映射行 | 10368/1728 | manifest.csv 的 status=not_applicable；equivalent_run_id 对应 B1-MPC |

每个形状的传送速度、幅值、空间周期、台阶宽度按已冻结组合生成。相位和台阶位置分别由训练种子3000～3053、测试种子4000～4107确定。

用户已确认固定中心光点、材料坐标 `s=1000vt` 和观测有效标志 `q=1`。控制器调用时将估计状态中的X/Y位置、速度和加速度设为零，保留Z估计，保证实际振镜转角固定为零。B2-fc登记为 `not_applicable`，等同于B1-MPC，收益统计不纳入这一项。其证据由阶段A边缘视场提供。

## 不成立或增益消失的结果

阶段 C 的控制仿真尚未运行，因此目前没有收益估计、区间或对方法有效性的判断。B2-fc 的结构等同关系属于预先规定的适用性记录。
