"""Full-plane checks on 48 standard and two stored training-motion cases."""
from pathlib import Path
import csv,json,time
import numpy as np
from check_moving_heat_v2 import cases_standard
from p3_adaptive_input import sampled_inputs,background_samples
from p3_background_v14 import converged_plane

BASE=Path(__file__).resolve().parents[1]
OUT=BASE/'implementation_checks/v1_4_background'


def main():
    OUT.mkdir(exist_ok=True)
    cases=cases_standard()
    for seed,D in [(1000,7),(1014,14)]:
        data=dict(np.load(BASE/f'implementation_checks/heat_training_motion_{seed}_D{D}.npz'))
        cases.append(dict(id=f'train_seed{seed}_D{D}',**{k:data[k] for k in ['times','e','w','bg_c','bg_w']}))
    rows=[]
    for case in cases:
        start=time.perf_counter()
        sample=sampled_inputs(case['times'],case['e'],case['w'],np.full(len(case['times'])-1,50.),bg_centres=case['bg_c'],bg_widths=case['bg_w'])
        centres,widths,energy=background_samples(sample,case['times'],case['bg_c'],case['bg_w'])
        plane,refinement,check=converged_plane(centres,widths,energy)
        assert check['passed'] and check['upper_bound_passed'],(case['id'],check)
        np.savez_compressed(OUT/(case['id']+'.npz'),**plane)
        rows.append(dict(case_id=case['id'],**check,peak_J_cm2=plane['peak_J_m2']/1e4,
                    input_energy_J=plane['input_energy_J'],integrated_energy_J=plane['integrated_energy_J'],
                    exact_domain_energy_J=plane['exact_domain_energy_J'],peak_integral_J_cm2=plane['peak_integral_J_m2']/1e4,
                    nx=len(plane['x_m']),ny=len(plane['y_m']),refinement_json=json.dumps(refinement),wall_s=time.perf_counter()-start))
        with (OUT/'full_plane_checks.csv').open('w',encoding='utf-8-sig',newline='') as f:
            writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
        print(f"Background full-plane {len(rows)}/50 passed",flush=True)
    report=dict(status='passed',completed=len(rows),expected=50,maximum_energy_error=max(r['energy_conservation_error'] for r in rows),maximum_grid_peak_error=max(r['peak_grid_error'] for r in rows),maximum_domain_peak_error=max(r['domain_peak_error'] for r in rows))
    (OUT/'checkpoint.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    print(json.dumps(report),flush=True)


if __name__=='__main__':main()
