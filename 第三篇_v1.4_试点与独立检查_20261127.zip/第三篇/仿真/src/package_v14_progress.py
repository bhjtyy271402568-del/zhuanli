"""Collect actual pilot/check outputs after the mandated solver-rate stop."""
from pathlib import Path
import csv
import hashlib
import json
import shutil
import zipfile

BASE=Path(__file__).resolve().parents[1]


def read_json(path):
    return json.loads(path.read_text(encoding='utf-8'))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    pilot=read_json(BASE/'out_pilot/timing_report.json')
    heat=read_json(BASE/'implementation_checks/v1_4_heat/checkpoint.json')
    background=read_json(BASE/'implementation_checks/v1_4_background/checkpoint.json')
    original=read_json(BASE/'PROVENANCE.json')
    unchanged=[]
    for record in original['files']:
        name=record['path']
        protected=name.startswith(('out_P0/','inputs_frozen/','implementation_checks/estimator_','implementation_checks/control_')) or name in ('src/p3_control.py','src/p3_estimator.py','src/p3_trajectories.py')
        if protected:
            assert sha(BASE/name)==record['sha256'],name
            unchanged.append(name)
    verification=dict(checked_files=len(unchanged),unchanged=True,files=unchanged)
    (BASE/'accepted_outputs_unchanged_v1_4.json').write_text(json.dumps(verification,ensure_ascii=False,indent=2),encoding='utf-8')
    for name in ['总索引.md','run_state.json']:
        saved=BASE/(Path(name).stem+'_v1_3_停止记录'+Path(name).suffix)
        if not saved.exists():
            shutil.copy2(BASE/name,saved)
    state=read_json(BASE/'run_state.json')
    state.update(version='1.4',date='2026-11-27',status='AUTOMATIC_STOP_QP_FAILURE_RATE',simulations_running=False,
                 stop_reason='Pilot completed100; 7 method-condition groups exceed frozen 1% solver failure gate',
                 trigger_file='out_pilot/qp_failed_groups.csv',stop_authority='第三篇_一次性运行补充指令.md section3 item4; latest v1.3 instruction preserves stop conditions',
                 next_work='Diagnose numerical failures in the recorded pilot candidates and finish heat-reference qualification before resuming affected batches')
    state.pop('maximum_relative_error',None)
    state.pop('independently_confirmed_relative_error',None)
    state['stages']['pilot']=dict(status='completed_failed_gate',completed=100,expected=100,failed_method_condition_groups=7)
    state['stages']['adaptive_input_check']=heat
    state['stages']['background_check']=background
    state['stages']['C']=read_json(BASE/'out_C/checkpoint.json')
    state['C_user_confirmed']=dict(fixed_centre=True,material_coordinate_moves_with_conveyor=True,visual_always_available=True,
        B2_fc='not_applicable; equivalent to B1-MPC; exclude from no-gain statistics; evidence only from Stage A Edge stratum')
    (BASE/'run_state.json').write_text(json.dumps(state,ensure_ascii=False,indent=2),encoding='utf-8')
    background_note=f'''# 背景全平面数值检查

2026-11-27。已计算48个标准运动算例与2个训练闭环片段，覆盖其全部中心位置以及最大束宽4倍的边界。扩大为6倍边界，并逐级减小网格步长。各点能流在固定物理坐标累积。

| 编号 | 结果 | 区间 | 来源 |
|---|---|---|---|
| [R-BG14-01] | 完成50/50，全部通过所列空间验收 | NA，确定性验收 | full_plane_checks.csv第2～51行 |
| [R-BG14-02] | 空间积分能量相对误差最大{background['maximum_energy_error']:.6g}，容差0.005 | NA | 同上energy_conservation_error列 |
| [R-BG14-03] | 网格加密峰值变化最大{background['maximum_grid_peak_error']:.9f}，容差0.01 | NA | 同上peak_grid_error列 |
| [R-BG14-04] | 扩大计算域峰值变化最大{background['maximum_domain_peak_error']:.9f}，容差0.01 | NA | 同上domain_peak_error列 |
| [R-BG14-05] | 50例H_bg,max≤H_peak_integral | NA | 同上upper_bound_passed列 |

各例NPZ保存x/y坐标、完整能流矩阵、空间积分能量、解析矩形积分能量、峰值位置与移动峰值积分。CSV保存逐级网格尺寸和变化。背景保守传输假设沿用已冻结规格。

## 适用范围与未完成事项

本表验证这50个运动记录中的空间积分。正式B中的每条轨迹仍需调用网格收敛检查，不能把本表替代未运行的B结果。时间输入采用已归档的细分算法，完整热输入时间资格由独立热分支记录。
'''
    (BASE/'implementation_checks/v1_4_background/results_for_writing.md').write_text(background_note,encoding='utf-8')
    index='''# 第三篇仿真总索引 · v1.4

2026-11-27。**100次试点已完成，QP失败率超限触发自动停止。正式A/B/C均未运行。**

## 优先查看

1. [试点编号结果与7组失败明细](out_pilot/results_for_writing.md)
2. [试点原始100行结果](out_pilot/pilot_results.csv)、[运行清单](out_pilot/pilot_manifest.csv)
3. [热模型空间/时间分离诊断和验证进度](implementation_checks/v1_4_heat/results_for_writing.md)
4. [背景全平面检查](implementation_checks/v1_4_background/results_for_writing.md)
5. [C阶段冻结清单与用户确认口径](out_C/frozen_manifest.json)、[C阶段检查点](out_C/checkpoint.json)

## 完成情况

| 阶段 | 计算完成数 | 验收状态 |
|---|---:|---|
| 已认可P0 | 478368/478368 | 111项自检通过 |
| 已认可轨迹 | 160/160 | 输入已冻结 |
| 已认可估计器/控制器检查 | 6/6、139/139 | 早期检查已通过 |
| 本轮试点 | 100/100 | 7个方法×工况组超过1%求解失败门限 |
| A训练、留出测试 | 0/53760、0/95760 | 尚未启动 |
| 热模型静止偏心 | 96/96 | 通过 |
| 热模型运动检查 | 30/50例，90/150行 | 84行通过，6行参考加密异常尚未诊断，余20例未运行 |
| 背景全平面空间检查 | 50/50 | 通过 |
| B | 0，正式运行清单尚未生成 | 尚未启动 |
| C | 控制仿真0次 | 工件输入和清单已准备 |

## 当前停止原因

B2-pos在D14、150Hz、6g、前扫描、A1、视线噪声0.5mrad下，当前试点候选共323/788次QP未通过，约40.99%。309次达到迭代上限，14次低精度求解后未通过约束核对。全部7组失败率见[分组表](out_pilot/qp_failed_groups.csv)，完整逐次状态和回退结果在原始CSV中。

试点使用冻结Sobol候选1，由执行器实现者在试点之前选择。候选0为基准点。正式48候选训练尚未开始，本次数据不构成S2增益结论。[参数原件](out_pilot/pilot_candidate_parameters.json)

停止依据是一次性补充指令第3节第4项，任一方案在任一工况下MPC失败率超过1%即停止。最新v1.3指令保留此条件。热分支在收到全局停止后保存当前30例进度，C保留准备文件。

## 热误差诊断更正

旧诊断表中的1/2/4为近历史毫秒数。此次实际加密空间与时间后，失败例的径向节点128/256/512误差均约2.84%；时间子步×2/×4后误差约1.06%/0.39%。这支持该例的时间求积误差判断。新积分在该例得到18.379822850057K。

完整50例资格尚未取得。已计算的两例参考加密差超过0.1%，需要继续诊断；不能用单例吻合替代完整验收。[空间加密表](implementation_checks/v1_4_heat/moving_space_refinement.csv) · [时间加密表](implementation_checks/v1_4_heat/moving_time_refinement.csv)

## C的用户确认

传送带带动起伏表面经过固定中心光点，Z跟随高度，视觉始终可用。B2-fc标为not_applicable（等同于B1-MPC），不计入无增益统计。其证据只取A的边缘视场。正式运行仍须通过当前停止关口。

## 耗时与证据限制

试点三进程墙钟约18.92秒，单次中位0.313秒、P95约1.338秒。A的实测吞吐率投影约7.86小时，完整ABC耗时尚未获得。试点未单独分离JIT成本、未测RSS峰值，均在编号报告披露。原始运行脚本保留在out_pilot/run_stage_a_executed.py。

## 原始资料和复核

- [P0编号结果](out_P0/results_for_writing.md)
- [已认可文件哈希核对](accepted_outputs_unchanged_v1_4.json)
- [本次机器可读状态](run_state.json)
- [本次文件哈希清单](PROVENANCE_v1_4.json)
- [本轮执行指令](参考输入/第三篇_v1.3停止后指令_20261127.md)

Python数值仿真。当前无后台仿真进程。原始已认可数据与旧失败记录均随包提供，阶段A/B/C的效能结果尚缺。
'''
    (BASE/'总索引.md').write_text(index,encoding='utf-8')
    files=[p for p in BASE.iterdir() if p.is_file() and p.suffix in ('.md','.json') and p.name!='PROVENANCE_v1_4.json']
    for folder in ['src','参考输入','out_P0','inputs_frozen','implementation_checks','out_pilot','out_A','out_C']:
        files.extend(p for p in (BASE/folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix not in ('.pyc','.nbc','.nbi','.tmp'))
    files=sorted(set(files))
    manifest=dict(version='1.4',status=state['status'],files=[dict(path=p.relative_to(BASE).as_posix(),bytes=p.stat().st_size,sha256=sha(p)) for p in files])
    manifest_path=BASE/'PROVENANCE_v1_4.json'
    manifest_path.write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
    files.append(manifest_path)
    destination=Path(r'F:\激光动态聚焦系统\第三篇\仿真\第三篇_v1.4_试点与独立检查_20261127.zip')
    with zipfile.ZipFile(destination,'w',zipfile.ZIP_DEFLATED) as archive:
        for path in files:
            archive.write(path,'第三篇/仿真/'+path.relative_to(BASE).as_posix())
    with zipfile.ZipFile(destination) as archive:
        assert archive.testzip() is None
        for item in manifest['files']:
            assert hashlib.sha256(archive.read('第三篇/仿真/'+item['path'])).hexdigest()==item['sha256']
    print(json.dumps(dict(package=str(destination),bytes=destination.stat().st_size,files=len(files),sha256=sha(destination),accepted_files_unchanged=len(unchanged)),ensure_ascii=False))


if __name__=='__main__':
    main()
