"""Continuous finite-disk surface heating with exact spatial Gaussian overlap.

All geometry uses metres and seconds. Target-centred offset and width interpolate
linearly between plant knots. Power is held over each interval. The production
solver integrates transformed heat age with Gauss-Legendre quadrature. The
reference uses independent adaptive QUADPACK integration of the same continuum.
"""
from functools import lru_cache
import math
import numpy as np
from numpy.polynomial.legendre import leggauss
from scipy.integrate import quad
from scipy.optimize import brentq
from scipy.stats import ncx2

K = .5
KAPPA = .14e-6


@lru_cache(maxsize=8)
def gauss_rule(order):
    return leggauss(order)


class ContinuousHeat:
    def __init__(self, times, e_xy, widths, power_W, alpha=.05, radius_m=.00025,
                 near_ms=2., order=8):
        self.times=np.asarray(times,dtype=float)
        self.offsets=np.asarray(e_xy,dtype=float)
        self.widths=np.asarray(widths,dtype=float)
        power=np.asarray(power_W,dtype=float)
        self.power=np.full(len(self.times)-1,float(power)) if power.ndim==0 else power
        self.alpha=float(alpha)
        self.radius=float(radius_m)
        self.near=near_ms*.001
        self.order=order
        self.requested=np.maximum(1,np.ceil(np.linalg.norm(np.diff(self.offsets,axis=0),axis=1)/(np.minimum(np.minimum(self.widths[:-1],self.widths[1:]),self.radius)/4)).astype(int))
        self.n_sub=np.minimum(self.requested,200)
        self.capped_steps=int(np.count_nonzero(self.requested>200))
        self.sub_edges=np.unique(np.concatenate([np.linspace(self.times[i],self.times[i+1],n+1) for i,n in enumerate(self.n_sub)]))
        slopes=np.diff(self.offsets,axis=0)/np.diff(self.times)[:,None]
        wslopes=np.diff(self.widths)/np.diff(self.times)
        self.globally_linear=(np.max(np.abs(slopes-slopes[0]))<1e-10 and np.max(np.abs(wslopes-wslopes[0]))<1e-10 and np.ptp(self.power)==0)

    def geometry(self, source_times):
        tt=np.asarray(source_times)
        e=np.stack([np.interp(tt,self.times,self.offsets[:,axis]) for axis in range(2)],axis=-1)
        w=np.interp(tt,self.times,self.widths)
        index=np.minimum(np.searchsorted(self.times,tt,side='right')-1,len(self.power)-1)
        power=np.where((tt>=self.times[0])&(tt<self.times[-1]),self.power[index],0.)
        return np.linalg.norm(e,axis=-1),w,power

    def integrand(self, u, observation):
        """Integrand after u=sqrt(observation-source_time)."""
        u=np.asarray(u,dtype=float)
        e,w,power=self.geometry(observation-u*u)
        spread=w*w+8*KAPPA*u*u
        variance=2*KAPPA*u*u*w*w/spread
        mean=e*8*KAPPA*u*u/spread
        # Triangle inequality + the exact 2-D normal radial tail bounds the
        # omitted finite-disk tail by exp(-32) < 1.27e-14 in this branch.
        overlap=np.ones_like(u)
        mask=(variance>0)&(self.radius-mean<8*np.sqrt(variance))
        if np.any(mask):
            overlap[mask]=ncx2.cdf(self.radius*self.radius/variance[mask],2,mean[mask]**2/variance[mask])
        return 4*self.alpha*power*math.sqrt(KAPPA)/(math.pi**1.5*K*spread)*np.exp(-2*e*e/spread)*overlap

    def at(self, observation):
        if observation<=self.times[0]:return 0.
        # Retain geometric substeps in the recent window. Older source geometry
        # is still integrated continuously, with one quadrature interval per knot.
        cut=max(self.times[0],observation-self.near)
        edges=np.unique(np.concatenate((self.times[self.times<cut],self.sub_edges[(self.sub_edges>=cut)&(self.sub_edges<observation)],[cut,observation])))
        low=np.sqrt(np.maximum(0.,observation-edges[1:]))
        high=np.sqrt(observation-edges[:-1])
        nodes,weights=gauss_rule(self.order)
        u=((high+low)[:,None]+(high-low)[:,None]*nodes[None])/2
        values=self.integrand(u.ravel(),observation).reshape(u.shape)
        return float(np.sum((high-low)*.5*(values@weights)))

    def reference(self, observation, refined=False):
        if observation<=self.times[0]:return 0.,0.
        end=math.sqrt(observation-self.times[0])
        if self.globally_linear:
            points=np.array([end/math.sqrt(2)]) if refined else None
        else:
            knots=self.times
            if refined:knots=np.sort(np.concatenate((knots,(knots[:-1]+knots[1:])/2)))
            points=np.sqrt(observation-knots[(knots>self.times[0])&(knots<observation)])
        def integrand(u):return float(self.integrand(np.asarray([u]),observation)[0])
        # Scale the integral by a production magnitude to retain relative
        # accuracy even for very small positive temperature rises.
        scale=max(self.at(observation),1e-280)
        eps=1e-11 if refined else 1e-8
        val,err=quad(lambda u:integrand(u)/scale,0,end,points=points,epsabs=eps,epsrel=eps,limit=max(300,len(self.times)*3))
        return float(val*scale),float(err*scale)

    def threshold_metrics(self, threshold_K=60., refined=False, reference=False):
        # Probe each prescribed geometric interval and its midpoint. Subsequent
        # root finding is continuous and has no 0.1 ms rounding.
        edges=self.sub_edges
        sample=np.unique(np.concatenate((edges,(edges[:-1]+edges[1:])/2)))
        evaluate=(lambda t:self.reference(t,refined)[0]) if reference else self.at
        values=np.array([evaluate(t) for t in sample])
        high=values>=threshold_K
        transitions=np.flatnonzero(high[1:]!=high[:-1])+1
        roots=[brentq(lambda t:evaluate(t)-threshold_K,sample[i-1],sample[i],xtol=1e-12) for i in transitions]
        starts=([sample[0]] if high[0] else [])+roots[0 if not high[0] else 1::2]
        ends=roots[1 if not high[0] else 0::2]+([sample[-1]] if high[-1] else [])
        return dict(first_s=float(starts[0]) if starts else None,continuous_hold_s=max((b-a for a,b in zip(starts,ends)),default=0.),crossings_s=roots,sample_times=sample,sample_values=values)
