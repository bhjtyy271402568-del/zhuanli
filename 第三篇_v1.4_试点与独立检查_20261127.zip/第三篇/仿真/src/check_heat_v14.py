"""Separate space/time diagnosis and all 50 continuum-reference heat checks."""
from pathlib import Path
import csv
import json
import math
import time
import numpy as np
from numpy.polynomial.legendre import leggauss
from scipy.special import erfc,i0e
from scipy.integrate import quad
from scipy.optimize import brentq,minimize_scalar
from scipy.stats import ncx2
from p3_heat_v14 import ContinuousHeat,K,KAPPA
from p3_physics import beam
from p3_adaptive_input import sampled_inputs,radial_sources,direct_temperature
from check_moving_heat_v2 import cases_standard

BASE=Path(__file__).resolve().parents[1]
OUT=BASE/'implementation_checks/v1_4_heat'


def write_csv(name,rows):
    with (OUT/name).open('w',encoding='utf-8-sig',newline='') as file:
        writer=csv.DictWriter(file,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)


def radial_grid(n,radius=.00025):
    x,w=leggauss(n)
    return (x+1)*radius/2,w*radius/2/K


def diagnose():
    stationary=[]
    for D in [7,14]:
        w=beam(D)[0]
        for offset in [0,1,2,3]:
            h=ContinuousHeat([0,.005],[[offset*w,0],[offset*w,0]],[w,w],50.)
            for t in [.0001,.0005,.0018,.005]:
                reference,error=h.reference(t,True)
                for nodes in [128,256,512]:
                    r,weights=radial_grid(nodes)
                    flux=5/(math.pi*w*w)*np.exp(-2*((r-offset*w)/w)**2)*i0e(4*r*offset/w)
                    actual=float((erfc(r/(2*np.sqrt(KAPPA*t)))*weights)@flux)
                    stationary.append(dict(D_mm=D,offset_over_w=offset,time_ms=t*1000,radial_nodes=nodes,radial_temperature_K=actual,continuous_reference_K=reference,reference_error_estimate_K=error,absolute_error_K=abs(actual-reference),relative_error=abs(actual/reference-1),passed=abs(actual-reference)<=max(.01*reference,.1)))
    write_csv('static_offcentre_space.csv',stationary)
    c=cases_standard()[12];reference=ContinuousHeat(c['times'],c['e'],c['w'],50).reference(.0018,True)[0]
    spatial=[]
    sample=sampled_inputs(c['times'],c['e'],c['w'],np.full(30,50.))
    for nodes in [128,256,512]:
        r,weights=radial_grid(nodes)
        source=radial_sources(sample,.05,r)
        actual=direct_temperature(.0018,sample['starts'],sample['ends'],source,r,weights)
        spatial.append(dict(radial_nodes=nodes,geometric_substep_multiplier=1,quadrature_panels=4,temperature_K=actual,continuous_reference_K=reference,relative_error=abs(actual/reference-1)))
    write_csv('moving_space_refinement.csv',spatial)
    temporal=[]
    # Multiplying the existing interval-panel count subdivides each geometric
    # substep equally, equivalent to multiplying n_sub at fixed four panels.
    for multiplier in [1,2,4]:
        sample=sampled_inputs(c['times'],c['e'],c['w'],np.full(30,50.),panels=4*multiplier)
        r,weights=radial_grid(128)
        actual=direct_temperature(.0018,sample['starts'],sample['ends'],radial_sources(sample,.05,r),r,weights)
        temporal.append(dict(radial_nodes=128,geometric_substep_multiplier=multiplier,panels_per_multiplied_substep=4,temperature_K=actual,continuous_reference_K=reference,relative_error=abs(actual/reference-1)))
    write_csv('moving_time_refinement.csv',temporal)
    print(json.dumps(dict(static_passed=sum(r['passed'] for r in stationary),static_total=len(stationary),space_error=[r['relative_error'] for r in spatial],time_error=[r['relative_error'] for r in temporal])),flush=True)


def all_cases():
    cases=cases_standard()
    for seed,D in [(1000,7),(1014,14)]:
        path=BASE/f'implementation_checks/heat_training_motion_{seed}_D{D}.npz'
        data=np.load(path)
        cases.append(dict(id=f'train_seed{seed}_D{D}',kind='closed_loop',D=D,speed=None,centre_s=None,defocus_zR=None,**{k:data[k] for k in ['times','e','w','bg_c','bg_w']}))
    return cases


def root_metrics(sample_times,sample_values,evaluate):
    above=sample_values>=60
    transitions=np.flatnonzero(above[1:]!=above[:-1])+1
    roots=[brentq(lambda t:evaluate(t)-60,sample_times[i-1],sample_times[i],xtol=1e-12) for i in transitions]
    starts=([sample_times[0]] if above[0] else [])+roots[0 if not above[0] else 1::2]
    ends=roots[1 if not above[0] else 0::2]+([sample_times[-1]] if above[-1] else [])
    return float(starts[0]) if starts else None,max((b-a for a,b in zip(starts,ends)),default=0.)


def capture_integral(h,refined=False):
    def source(t):
        e,w,_=h.geometry(np.asarray([t]))
        return float(ncx2.cdf(4*h.radius*h.radius/(w[0]*w[0]),2,4*e[0]*e[0]/(w[0]*w[0])))
    knots=h.times
    if refined:knots=np.sort(np.concatenate((knots,(knots[:-1]+knots[1:])/2)))
    value=quad(source,h.times[0],h.times[-1],points=knots[1:-1],epsabs=1e-14,epsrel=1e-10,limit=len(knots)*3)[0]
    return value


def run_case(case):
    start=time.perf_counter()
    h=ContinuousHeat(case['times'],case['e'],case['w'],50.,order=8)
    # Reference evaluated at every geometric substep boundary and midpoint.
    # These are physical-time queries, independent of the old FFT time grid.
    edges=h.sub_edges
    queries=np.unique(np.concatenate((edges,(edges[:-1]+edges[1:])/2)))
    normal=[];refined=[];reference_errors=[]
    for t in queries:
        a,_=h.reference(t,False);b,e=h.reference(t,True)
        normal.append(a);refined.append(b);reference_errors.append(e)
    normal=np.asarray(normal);refined=np.asarray(refined)
    relative=np.zeros_like(refined)
    np.divide(np.abs(normal-refined),np.abs(refined),out=relative,where=refined!=0)
    zero_ok=bool(np.all(normal[refined==0]==0))
    first_ref,hold_ref=root_metrics(queries,refined,lambda t:h.reference(t,True)[0])
    first_ref0,hold_ref0=root_metrics(queries,normal,lambda t:h.reference(t,False)[0])
    max_reference_error=float(np.max(relative))
    reference_passed=max_reference_error<=.001 and zero_ok
    if first_ref is not None:
        reference_passed=reference_passed and first_ref0 is not None and abs(first_ref-first_ref0)<=max(.001*first_ref,1e-10)
    else:reference_passed=reference_passed and first_ref0 is None
    reference_passed=reference_passed and abs(hold_ref-hold_ref0)<=max(.001*hold_ref,1e-10)
    # Peak at the largest sampled neighbourhood, then continuous bounded search.
    peak_index=int(np.argmax(refined))
    left=queries[max(0,peak_index-1)];right=queries[min(len(queries)-1,peak_index+1)]
    peak_time=queries[peak_index]
    if right>left:
        peak_search=minimize_scalar(lambda t:-h.reference(t,True)[0],bounds=(left,right),method='bounded',options={'xatol':1e-11})
        if -peak_search.fun>refined[peak_index]:peak_time=float(peak_search.x)
    peak_ref=h.reference(peak_time,True)[0]
    sample=sampled_inputs(case['times'],case['e'],case['w'],np.full(len(case['times'])-1,50.),bg_centres=case['bg_c'],bg_widths=case['bg_w'])
    eta=float(sample['eta']@(sample['ends']-sample['starts']))
    eta_ref=capture_integral(h,True)
    eta_ref0=capture_integral(h,False)
    eta_error=abs(eta/eta_ref-1) if eta_ref else abs(eta)
    capture_reference_error=abs(eta_ref0/eta_ref-1) if eta_ref else abs(eta_ref0)
    rows=[]
    series=dict(times_s=queries,reference_K=refined)
    for near in [1,2,4]:
        model=ContinuousHeat(case['times'],case['e'],case['w'],50.,near_ms=near,order=8)
        begin=time.perf_counter();predicted=np.array([model.at(t) for t in queries]);elapsed=time.perf_counter()-begin
        first,hold=root_metrics(queries,predicted,model.at)
        errors=np.abs(predicted-refined)
        allowed=np.maximum(.01*refined,.1)
        error_ratio=max(float(np.max(errors/allowed)),abs(model.at(peak_time)-peak_ref)/max(.01*peak_ref,.1))
        time_error=None if first is None or first_ref is None else abs(first-first_ref)
        first_passed=(first is None)==(first_ref is None) and (time_error is None or time_error<=max(.01*first_ref,2e-6))
        hold_error=abs(hold-hold_ref)
        hold_passed=hold_error<=max(.01*hold_ref,2e-6)
        row=dict(case_id=case['id'],kind=case['kind'],D_mm=case['D'],speed_m_s=case['speed'],centre_time_s=case['centre_s'],defocus_zR=case['defocus_zR'],near_ms=near,temperature_end_K=float(predicted[-1]),reference_end_K=float(refined[-1]),max_temperature_error_over_allowed=error_ratio,
                 max_reference_refinement_relative_error=max_reference_error,first_threshold_s=first,first_threshold_reference_s=first_ref,first_error_us=None if time_error is None else time_error*1e6,continuous_hold_s=hold,continuous_hold_reference_s=hold_ref,hold_error_us=hold_error*1e6,
                 capture_integral_s=eta,capture_reference_s=eta_ref,capture_relative_error=eta_error,capture_reference_refinement_error=capture_reference_error,n_sub_min=int(model.n_sub.min()),n_sub_max=int(model.n_sub.max()),n_sub_mean=float(model.n_sub.mean()),n_sub_distribution=json.dumps({int(k):int(v) for k,v in zip(*np.unique(model.n_sub,return_counts=True))}),capped_steps=model.capped_steps,
                 temperature_queries=len(queries),production_query_mean_ms=elapsed*1000/len(queries),reference_passed=bool(reference_passed),temperature_passed=error_ratio<=1,first_passed=bool(first_passed),hold_passed=bool(hold_passed),capture_passed=eta_error<=.01 and capture_reference_error<=.001)
        row['passed']=bool(row['reference_passed'] and row['temperature_passed'] and row['first_passed'] and row['hold_passed'] and row['capture_passed'])
        rows.append(row);series[f'near_{near}ms_K']=predicted
    np.savez_compressed(OUT/'series'/f"{case['id']}.npz",**series)
    for row in rows:row['case_wall_s']=time.perf_counter()-start
    return rows


def main():
    OUT.mkdir(exist_ok=True);(OUT/'series').mkdir(exist_ok=True)
    diagnose()
    rows=[]
    for index,case in enumerate(all_cases()):
        new=run_case(case);rows.extend(new)
        write_csv('moving_heat_convergence_v14.csv',rows)
        print(json.dumps(dict(completed=index+1,total=50,case=case['id'],passed=all(r['passed'] for r in new),maximum_allowed_ratio=max(r['max_temperature_error_over_allowed'] for r in new),ref_error=new[0]['max_reference_refinement_relative_error'])),flush=True)
    summary=dict(status='passed' if all(r['passed'] for r in rows) else 'failed',rows=len(rows),cases=50,passed=sum(r['passed'] for r in rows),failed_csv_rows=[i+2 for i,r in enumerate(rows) if not r['passed']],reference='finite-disk Gaussian overlap plus adaptive continuous-time quadrature',production='Gauss-Legendre heat-age quadrature with exact spatial overlap; near source geometric substeps and old plant intervals',full_plane_background_check='parent-owned pending')
    (OUT/'checkpoint.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(summary),flush=True)


if __name__=='__main__':main()
