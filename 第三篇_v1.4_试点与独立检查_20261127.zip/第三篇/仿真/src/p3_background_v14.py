"""Fixed-plane fluence with full-domain energy and mesh convergence."""
import math
import numpy as np
from scipy.special import erf


def plane_map(centres, widths, energy, padding_widths=4., points_per_width=3):
    centres=np.asarray(centres);widths=np.asarray(widths);energy=np.asarray(energy)
    active=energy>0
    centres=centres[active];widths=widths[active];energy=energy[active]
    if not len(energy):
        return dict(x_m=np.array([0.]),y_m=np.array([0.]),H_J_m2=np.zeros((1,1)),
                    peak_J_m2=0.,integrated_energy_J=0.,exact_domain_energy_J=0.,input_energy_J=0.,peak_integral_J_m2=0.)
    low=centres.min(axis=0)-padding_widths*widths.max()
    high=centres.max(axis=0)+padding_widths*widths.max()
    spacing=widths.min()/points_per_width
    x=np.linspace(low[0],high[0],math.ceil((high[0]-low[0])/spacing)+1)
    y=np.linspace(low[1],high[1],math.ceil((high[1]-low[1])/spacing)+1)
    result=np.zeros((len(y),len(x)))
    for begin in range(0,len(energy),256):
        end=begin+256
        exponent_x=(x[None]-centres[begin:end,0,None])/widths[begin:end,None]
        exponent_y=(y[None]-centres[begin:end,1,None])/widths[begin:end,None]
        amplitude=2*energy[begin:end]/(math.pi*widths[begin:end]**2)
        result+=np.exp(-2*exponent_y**2).T@(amplitude[:,None]*np.exp(-2*exponent_x**2))
    spatial_energy=float(np.trapezoid(np.trapezoid(result,x,axis=1),y))
    interval=.5*(erf(math.sqrt(2)*(high-centres)/widths[:,None])-erf(math.sqrt(2)*(low-centres)/widths[:,None]))
    exact_energy=float(energy@np.prod(interval,axis=1))
    peak_index=np.unravel_index(np.argmax(result),result.shape)
    return dict(x_m=x,y_m=y,H_J_m2=result,peak_J_m2=float(result[peak_index]),
                peak_x_m=float(x[peak_index[1]]),peak_y_m=float(y[peak_index[0]]),
                integrated_energy_J=spatial_energy,exact_domain_energy_J=exact_energy,
                input_energy_J=float(energy.sum()),peak_integral_J_m2=float(np.sum(2*energy/(math.pi*widths**2))))


def converged_plane(centres,widths,energy):
    records=[];previous=None
    for density in [3,6,12,24]:
        plane=plane_map(centres,widths,energy,4.,density)
        difference=None if previous is None else abs(plane['peak_J_m2']-previous['peak_J_m2'])/max(plane['peak_J_m2'],1e-300)
        records.append(dict(points_per_width=density,nx=len(plane['x_m']),ny=len(plane['y_m']),
                            peak_J_m2=plane['peak_J_m2'],peak_change=difference,
                            integrated_energy_J=plane['integrated_energy_J']))
        if difference is not None and difference<=.005:
            expanded=plane_map(centres,widths,energy,6.,density)
            domain_error=abs(expanded['peak_J_m2']-plane['peak_J_m2'])/max(expanded['peak_J_m2'],1e-300)
            energy_error=abs(expanded['integrated_energy_J']-expanded['input_energy_J'])/max(expanded['input_energy_J'],1e-300)
            if domain_error<=.01 and energy_error<=.005:
                return expanded,records,dict(domain_peak_error=domain_error,energy_conservation_error=energy_error,
                    peak_grid_error=difference,upper_bound_passed=expanded['peak_J_m2']<=expanded['peak_integral_J_m2']*(1+1e-12),passed=True)
        previous=plane
    return plane,records,dict(passed=False,reason='full-plane refinement failed frozen tolerances')
