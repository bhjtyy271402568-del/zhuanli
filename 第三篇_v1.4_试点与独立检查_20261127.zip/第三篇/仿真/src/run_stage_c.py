"""Stage C preparation and execution for moving nonplanar workpieces."""
from pathlib import Path
import argparse
import csv
import hashlib
import itertools
import json
import math
import os
import time
import numpy as np
from concurrent.futures import ProcessPoolExecutor
from scipy.stats import qmc
from p3_control import baseline_parameters, candidate_parameters, run_control
from p3_estimator import observer_series
from p3_physics import beam

BASE = Path(__file__).resolve().parents[1]
OUT = BASE / "out_C"
INPUT = BASE / "inputs_frozen/workpiece_v14"
METHODS = ("B1", "B1-MPC", "B2-pos", "B2-vel", "B2-fc")
ACTIVE_METHODS = ("B1", "B1-MPC", "B2-pos", "B2-vel")
DEPTH_TIERS = ("A1", "B1")
TRAIN_RUNS = 41472
TEST_RUNS = 6912


def write_json(path, value):
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")
    temporary.replace(path)


def write_csv(path, rows):
    temporary = path.with_suffix(path.suffix + ".tmp")
    with temporary.open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    temporary.replace(path)


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def prepare_surfaces():
    INPUT.mkdir(parents=True, exist_ok=True)
    OUT.mkdir(exist_ok=True)
    shapes = list(itertools.product((.2, .6, 1.), (5, 10, 15), (30, 60, 120), (1, 5)))
    times = np.arange(4001) * .0001
    records = []
    for split, start, repetitions in (("train", 3000, 1), ("test", 4000, 2)):
        for shape_id, (speed, amplitude, period, step_width) in enumerate(shapes):
            for repetition in range(repetitions):
                seed = start + shape_id * repetitions + repetition
                random = np.random.default_rng(np.random.SeedSequence([seed, 1701]))
                material_s = 1000 * speed * times
                phase = random.uniform(0, 2 * np.pi)
                step_position = random.uniform(0, material_s[-1])
                height = amplitude * (
                    .5 * np.sin(2 * np.pi * material_s / period + phase)
                    + .5 * np.tanh((material_s - step_position) / step_width)
                )
                assert np.max(np.abs(height)) <= amplitude + 1e-12
                calibration = np.random.default_rng(np.random.SeedSequence([seed, 902])).uniform(-.1, .1)
                path = INPUT / f"{seed}.npz"
                if path.exists():
                    saved = np.load(path)
                    assert np.array_equal(saved["height_mm"], height)
                    assert float(saved["phase_rad"]) == phase
                else:
                    np.savez_compressed(
                        path, times_s=times, material_s_mm=material_s, height_mm=height,
                        seed=seed, shape_id=shape_id, speed_m_s=speed, amplitude_mm=amplitude,
                        period_mm=period, step_width_mm=step_width, phase_rad=phase,
                        step_position_mm=step_position, calibration_residual_mm=calibration,
                    )
                records.append(dict(
                    seed=seed, split=split, shape_id=shape_id, repetition=repetition,
                    speed_m_s=speed, amplitude_mm=amplitude, period_mm=period,
                    step_width_mm=step_width, phase_rad=phase, step_position_mm=step_position,
                    minimum_height_mm=float(height.min()), maximum_height_mm=float(height.max()),
                    path=path.relative_to(BASE).as_posix(), sha256=sha256(path),
                ))
    assert len(records) == 162
    assert len({record["seed"] for record in records}) == 162
    write_csv(INPUT / "surface_manifest.csv", records)
    return records


def parameter_candidates(method):
    design = qmc.Sobol(d=6, scramble=True, seed=20261126).random_base2(6)[:48]
    baseline = np.array([.5, 1., 1/3, 0., .25, 0.])
    active = {"B1": [0, 1], "B1-MPC": [2], "B2-pos": [2, 3, 4], "B2-vel": [2, 5], "B2-fc": [2]}[method]
    result = []
    for candidate_id, point in enumerate(design):
        parameters = baseline_parameters() if candidate_id == 0 else candidate_parameters(method, point)
        normalized = np.array([
            parameters["k_lead"]-.5, np.log10(parameters["lowpass_Hz"])-1,
            (np.log10(parameters["lambda_u"])+4)/3,
            np.log10(parameters["window_ratio"])/2,
            (parameters["K_dwell"]-2)/8, parameters["beta_v"]/10,
        ])
        distance = float(np.sum((normalized[active]-baseline[active])**2))
        if method == "B2-fc":
            distance += float(parameters["use_future_angle"])
        result.append(dict(candidate_id=candidate_id, parameters=parameters, baseline_distance=math.sqrt(distance)))
    return result


def fingerprint():
    paths = [Path(__file__), BASE/"src/p3_control.py", BASE/"src/p3_estimator.py",
             BASE/"src/p3_physics.py", BASE/"src/params_p3_run_v1_3.json",
             INPUT/"surface_manifest.csv"]
    values = {path.relative_to(BASE).as_posix(): sha256(path) for path in paths}
    return hashlib.sha256(json.dumps(values, sort_keys=True).encode()).hexdigest(), values


def logical_run_id(version, phase, D, hz, tier, method, candidate_id, seed):
    text = f"{version}|C|{phase}|{D}|{hz}|{tier}|{method}|{candidate_id}|{seed}|q1"
    return hashlib.sha256(text.encode()).hexdigest()[:24]


def prepare():
    surfaces = prepare_surfaces()
    version, hashes = fingerprint()
    existing = OUT/"frozen_manifest.json"
    if existing.exists():
        previous = json.loads(existing.read_text(encoding="utf-8"))
        if previous["version_hash"] != version:
            results = OUT/"receipts"
            if results.exists() and any(results.iterdir()):
                raise RuntimeError("Stage C code or inputs changed after execution; preserve results in a new version directory")
    config = dict(
        version="1.4", version_hash=version, source_hashes=hashes,
        coordinate_convention="fixed on-axis observation point; material coordinate s=1000*v*t passes through it",
        geometry="laboratory point [0,0,254+h(s)] mm",
        surface="h(s)=A*(0.5*sin(2*pi*s/L+phase)+0.5*tanh((s-step_position)/b))",
        observation_validity="q=1 throughout; C specification contains no optical blanking condition",
        LOS_sigma_mrad=.5, methods=METHODS, active_methods=ACTIVE_METHODS, train_depth_tiers=DEPTH_TIERS,
        train_depth_weight="equal; one frozen parameter set per D and method across both tiers",
        train_trajectories=54, test_trajectories=108, logical_training_rows=51840,
        logical_test_rows=8640, executable_training_evaluations=TRAIN_RUNS,
        executable_test_runs=TEST_RUNS, not_applicable_training_rows=10368,
        not_applicable_test_rows=1728, train_Hz=30, test_Hz=[25,40,80,150], a_g=4,
        configuration="front", parameter_candidates={m:parameter_candidates(m) for m in ACTIVE_METHODS},
        B2_fc_status="not_applicable; structurally identical to B1-MPC under fixed zero galvo angle; evidence comes from Stage A edge views",
        fixed_angle_implementation="copy estimate and set X/Y position, velocity and acceleration to zero at controller call boundary; keep Z estimates and accepted controller implementation",
        execution_requires="parent confirms Stage A has passed; heat checkpoint not required for C",
        baseline_distance="Euclidean active normalized coordinate distance",
    )
    write_json(existing, config)
    manifest = []
    for phase, frequencies in (("train", (30,)), ("test", (25,40,80,150))):
        selected = [s for s in surfaces if s["split"] == phase]
        candidate_ids = range(48) if phase == "train" else (-1,)
        for D, hz, tier, method, candidate_id in itertools.product((7,14), frequencies, DEPTH_TIERS, METHODS, candidate_ids):
            for surface in selected:
                manifest.append(dict(
                    run_id=logical_run_id(version,phase,D,hz,tier,method,candidate_id,surface["seed"]),
                    phase=phase, D_mm=D, z_Hz=hz, a_g=4, configuration="front", depth_tier=tier,
                    method=method, candidate_id=candidate_id, seed=surface["seed"],
                    shape_id=surface["shape_id"], status="not_applicable" if method=="B2-fc" else "queued",
                    equivalent_run_id=logical_run_id(version,phase,D,hz,tier,"B1-MPC",candidate_id,surface["seed"]) if method=="B2-fc" else "",
                ))
    assert sum(r["phase"]=="train" for r in manifest)==51840
    assert sum(r["phase"]=="test" for r in manifest)==8640
    assert len({r["run_id"] for r in manifest})==len(manifest)
    write_csv(OUT/"manifest.csv",manifest)
    write_json(OUT/"checkpoint.json",dict(status="not_run_due_to_pilot_stop",training_completed=0,training_expected=TRAIN_RUNS,test_completed=0,test_expected=TEST_RUNS,training_not_applicable=10368,test_not_applicable=1728))
    return config, manifest


def observation_cache(seed, tier):
    directory = OUT/"observers"
    directory.mkdir(exist_ok=True)
    path = directory/f"{seed}_{tier}.npz"
    if path.exists():
        saved = np.load(path)
        return saved["position_mm"],saved["states"],saved["valid"],float(saved["bias_mm"])
    surface = np.load(INPUT/f"{seed}.npz")
    positions = np.zeros((4001,3))
    positions[:,2] = 254+surface["height_mm"]
    states,_,valid,_ = observer_series(positions,seed,tier,.5,False)
    bias = float(surface["calibration_residual_mm"])
    temporary = path.with_name(f"{path.stem}.{os.getpid()}.tmp.npz")
    np.savez_compressed(temporary,position_mm=positions,states=states,valid=valid,bias_mm=bias)
    temporary.replace(path)
    return positions,states,valid,bias


def cache_key(task):
    parameters = task["parameters"].copy()
    used = ("k_lead","lowpass_Hz") if task["method"]=="B1" else ("lambda_u","window_ratio","K_dwell","beta_v","use_future_angle")
    identity = dict(version=task["version_hash"],phase=task["phase"],seed=task["seed"],
                    tier=task["depth_tier"],D=task["D_mm"],Hz=task["z_Hz"],
                    controller="B1" if task["method"]=="B1" else "MPC",
                    parameters={key:parameters[key] for key in used})
    return hashlib.sha256(json.dumps(identity,sort_keys=True).encode()).hexdigest()[:24]


def execute_task(task):
    start = time.perf_counter()
    identity = cache_key(task)
    directory = OUT/"computed"
    directory.mkdir(exist_ok=True)
    path = directory/f"{identity}.json"
    checksum = path.with_suffix(".sha256")
    if path.exists() and checksum.exists() and sha256(path)==checksum.read_text().strip():
        metric = json.loads(path.read_text(encoding="utf-8"))
        return task,metric,True,time.perf_counter()-start,identity
    positions,states,valid,bias = observation_cache(task["seed"],task["depth_tier"])
    states = states.copy()
    states[:,[0,1,3,4,6,7]] = 0.
    case = dict(D_mm=task["D_mm"],z_Hz=task["z_Hz"],a_g=4,configuration="front")
    metric,series = run_control(positions,states,valid,case,task["method"],task["parameters"],bias,True)
    if np.any(series["xy"] != 0):
        raise RuntimeError("AUTOMATIC STOP: fixed-centre workpiece fixture produced a nonzero galvo state")
    error = np.abs(series["defocus_mm"])
    zr = beam(task["D_mm"])[1]*1000
    radius_ratio = np.sqrt(1+(error/zr)**2)
    for ratio in (1.2,1.5):
        by_radius = radius_ratio<=ratio
        by_defocus = error<=zr*np.sqrt(ratio**2-1)
        if not np.array_equal(by_radius,by_defocus):
            raise RuntimeError("AUTOMATIC STOP: Stage C beam-radius/defocus criterion disagreement")
        metric[f"fraction_w_le_{str(ratio).replace('.','p')}w0"] = float(by_radius.mean())
    if task["phase"]=="test":
        series_path = directory/f"{identity}.npz"
        temporary = series_path.with_suffix(".tmp.npz")
        np.savez_compressed(temporary,defocus_mm=series["defocus_mm"],focus_mm=series["focus_mm"],z_state=series["z"],xy_state=series["xy"])
        temporary.replace(series_path)
        metric["series_file"] = series_path.name
        metric["series_sha256"] = sha256(series_path)
    metric["compute_wall_s"] = time.perf_counter()-start
    write_json(path,metric)
    checksum.write_text(sha256(path),encoding="ascii")
    return task,metric,False,time.perf_counter()-start,identity


def recorded_result(task):
    receipt = OUT/"receipts"/f"{task['run_id']}.json"
    if not receipt.exists():return None
    saved = json.loads(receipt.read_text(encoding="utf-8"))
    path = OUT/"computed"/saved["result_file"]
    if not path.exists() or sha256(path)!=saved["result_sha256"]:return None
    metric = json.loads(path.read_text(encoding="utf-8"))
    if "series_file" in metric:
        series = OUT/"computed"/metric["series_file"]
        if not series.exists() or sha256(series)!=metric["series_sha256"]:return None
    return dict(**{k:task[k] for k in task if k not in ("parameters","version_hash")},**metric,
                reused=saved["reused"],dispatch_wall_s=saved["dispatch_wall_s"],compute_id=saved["compute_id"])


def run_group(pool, tasks):
    rows=[];pending=[]
    for task in tasks:
        found = recorded_result(task)
        if found is None:pending.append(task)
        else:rows.append(found)
    # Candidates with identical active parameters reuse a verified physical run.
    unique={}
    for task in pending:unique.setdefault(cache_key(task),[]).append(task)
    for task,metric,cached,wall,identity in pool.map(execute_task,[group[0] for group in unique.values()],chunksize=1):
        equivalents=unique[identity]
        path=OUT/"computed"/f"{identity}.json"
        for index,equivalent in enumerate(equivalents):
            reused=cached or index>0
            write_json(OUT/"receipts"/f"{equivalent['run_id']}.json",dict(
                run_id=equivalent["run_id"],result_file=path.name,result_sha256=sha256(path),
                compute_id=identity,reused=reused,dispatch_wall_s=wall if index==0 else 0.,status="reused" if reused else "complete"))
            rows.append(recorded_result(equivalent))
    return sorted(rows,key=lambda row:(row["candidate_id"],row["depth_tier"],row["seed"]))


def check_group(rows, method, D, hz, phase):
    for tier in DEPTH_TIERS:
        selected=[row for row in rows if row["depth_tier"]==tier]
        calls=sum(row["qp_calls"] for row in selected)
        failures=sum(row["qp_failures"] for row in selected)
        if calls and failures/calls>.01:
            detail=dict(status="failed",reason="MPC_failure_rate_over_1_percent",phase=phase,method=method,D_mm=D,z_Hz=hz,depth_tier=tier,qp_failures=failures,qp_calls=calls,fraction=failures/calls)
            write_json(OUT/"stop.json",detail)
            raise RuntimeError("AUTOMATIC STOP: Stage C method/physical-condition MPC failure rate exceeds one percent")


def summarize(rows):
    write_csv(OUT/"test_results.csv",rows)
    fields=("dwell","defocus_P95_mm","defocus_RMSE_mm","longest_focus_ms","fraction_w_le_1p2w0","fraction_w_le_1p5w0")
    summary=[];differences=[]
    for D,hz,tier in itertools.product((7,14),(25,40,80,150),DEPTH_TIERS):
        subset=[r for r in rows if r["D_mm"]==D and r["z_Hz"]==hz and r["depth_tier"]==tier]
        baseline={r["seed"]:r for r in subset if r["method"]=="B1-MPC"}
        for method in ACTIVE_METHODS:
            selected=sorted((r for r in subset if r["method"]==method),key=lambda r:r["seed"])
            assert len(selected)==108
            summary.append(dict(D_mm=D,z_Hz=hz,depth_tier=tier,method=method,n=108,**{f:float(np.mean([r[f] for r in selected])) for f in fields}))
            if method.startswith("B2-"):
                random=np.random.default_rng(20261126)
                # Each of 54 frozen shapes has two independent phase/step-position trajectories.
                bootstrap=random.integers(0,2,size=(10000,54,2))+2*np.arange(54)[None,:,None]
                for field in fields:
                    delta=np.array([r[field]-baseline[r["seed"]][field] for r in selected])
                    sampled=delta[bootstrap].mean(axis=(1,2))
                    low,high=np.quantile(sampled,[.025,.975])
                    differences.append(dict(D_mm=D,z_Hz=hz,depth_tier=tier,method=method,reference="B1-MPC",metric=field,n_trajectories=108,n_shape_strata=54,paired_mean_difference=float(delta.mean()),CI95_low=float(low),CI95_high=float(high)))
    write_csv(OUT/"summary.csv",summary)
    write_csv(OUT/"paired_differences.csv",differences)
    smooth=[]
    records={int(r["seed"]):r for r in csv.DictReader((INPUT/"surface_manifest.csv").open(encoding="utf-8-sig"))}
    for row in rows:
        surface=records[row["seed"]]
        if row["z_Hz"]==150 and float(surface["speed_m_s"])==.2 and int(surface["period_mm"])==120 and int(surface["step_width_mm"])==5:smooth.append(row)
    write_csv(OUT/"smooth_surface_150Hz.csv",smooth)
    handoff=["# 阶段 C 编号结果", "", "以固定中心光点观察传送工件。两档深度等权调参，q=1。", "", "| 编号 | D/mm | Hz | 深度 | 方法 | 驻留均值 | 轨迹数 | 来源 |", "|---|---:|---:|---|---|---:|---:|---|"]
    for i,row in enumerate(summary,1):
        handoff.append(f"| [R-C-{i:03d}] | {row['D_mm']} | {row['z_Hz']} | {row['depth_tier']} | {row['method']} | {row['dwell']:.8g} | 108 | summary.csv第{i+1}行；轨迹簇配对区间见paired_differences.csv |")
    handoff.extend(["", "## 不成立或增益消失的结果", "", "下列条目为驻留占比配对均值差≤0的实际工况。区间按54个形状分层、以轨迹为抽样单位计算。", ""])
    for i,row in enumerate(differences,2):
        if row["metric"]=="dwell" and row["paired_mean_difference"]<=0:
            handoff.append(f"- D{row['D_mm']} / {row['z_Hz']}Hz / {row['depth_tier']} / {row['method']}：差{row['paired_mean_difference']:.8g}，95%CI [{row['CI95_low']:.8g}, {row['CI95_high']:.8g}]；paired_differences.csv第{i}行。")
    handoff.extend(["", f"test_results.csv SHA-256 `{sha256(OUT/'test_results.csv')}`。", f"paired_differences.csv SHA-256 `{sha256(OUT/'paired_differences.csv')}`。"])
    (OUT/"results_for_writing.md").write_text("\n".join(handoff)+"\n",encoding="utf-8")


def execute(workers):
    prerequisite=BASE/"out_A/execution_checkpoint.json"
    if not prerequisite.exists():
        raise RuntimeError("Stage C is waiting for the Stage A completion checkpoint")
    previous_stage=json.loads(prerequisite.read_text(encoding="utf-8"))
    if previous_stage.get("status") not in ("raw_runs_complete","complete","passed") or previous_stage.get("training")!=53760 or previous_stage.get("test")!=95760:
        raise RuntimeError("Stage A completion counts have not passed; Stage C remains queued")
    config=json.loads((OUT/"frozen_manifest.json").read_text(encoding="utf-8"))
    version,_=fingerprint()
    if config["version_hash"]!=version:raise RuntimeError("Stage C source fingerprint changed since preparation")
    (OUT/"receipts").mkdir(exist_ok=True)
    manifest=list(csv.DictReader((OUT/"manifest.csv").open(encoding="utf-8-sig")))
    for row in manifest:
        for field in ("D_mm","z_Hz","a_g","candidate_id","seed","shape_id"):row[field]=int(row[field])
    completed_training=0;completed_test=0;train_rows=[];test_rows=[];frozen={}
    begin=time.perf_counter()
    with ProcessPoolExecutor(max_workers=workers) as pool:
        for D,method in itertools.product((7,14),ACTIVE_METHODS):
            tasks=[]
            for row in manifest:
                if row["phase"]=="train" and row["D_mm"]==D and row["method"]==method:
                    entry=config["parameter_candidates"][method][row["candidate_id"]]
                    tasks.append(dict(**row,version_hash=version,parameters=entry["parameters"]))
            results=run_group(pool,tasks);train_rows.extend(results);completed_training+=len(results)
            write_csv(OUT/"training_results.csv",train_rows)
            check_group(results,method,D,30,"train")
            utilities=[]
            for candidate in config["parameter_candidates"][method]:
                selected=[r for r in results if r["candidate_id"]==candidate["candidate_id"]]
                assert len(selected)==108
                utilities.append(dict(candidate,utility=float(np.mean([r["dwell"] for r in selected]))))
            best=max(r["utility"] for r in utilities)
            tied=[r for r in utilities if best-r["utility"]<1e-4]
            winner=min(tied,key=lambda r:(r["baseline_distance"],r["candidate_id"]))
            frozen[f"D{D}_{method}"]=winner
            write_json(OUT/"frozen_parameters.json",frozen)
            write_json(OUT/"checkpoint.json",dict(status="training",training_completed=completed_training,training_expected=TRAIN_RUNS,test_completed=completed_test,test_expected=TEST_RUNS,training_not_applicable=10368,test_not_applicable=1728,elapsed_wall_s=time.perf_counter()-begin))
            print(f"C training {completed_training}/{TRAIN_RUNS}; {D} {method}",flush=True)
        for D,hz,method in itertools.product((7,14),(25,40,80,150),ACTIVE_METHODS):
            tasks=[dict(**row,version_hash=version,parameters=frozen[f"D{D}_{method}"]["parameters"]) for row in manifest if row["phase"]=="test" and row["D_mm"]==D and row["z_Hz"]==hz and row["method"]==method]
            results=run_group(pool,tasks);test_rows.extend(results);completed_test+=len(results)
            write_csv(OUT/"test_results.csv",test_rows)
            check_group(results,method,D,hz,"test")
            write_json(OUT/"checkpoint.json",dict(status="testing",training_completed=completed_training,training_expected=TRAIN_RUNS,test_completed=completed_test,test_expected=TEST_RUNS,training_not_applicable=10368,test_not_applicable=1728,elapsed_wall_s=time.perf_counter()-begin))
            print(f"C test {completed_test}/{TEST_RUNS}; {D} {hz}Hz {method}",flush=True)
    assert completed_training==TRAIN_RUNS and completed_test==TEST_RUNS
    summarize(test_rows)
    by_id={row["run_id"]:row for row in train_rows+test_rows}
    for row in manifest:
        if row["method"] != "B2-fc":row["status"]="reused" if by_id[row["run_id"]]["reused"] else "complete"
    write_csv(OUT/"manifest.csv",manifest)
    write_json(OUT/"checkpoint.json",dict(status="passed",training_completed=TRAIN_RUNS,training_expected=TRAIN_RUNS,test_completed=TEST_RUNS,test_expected=TEST_RUNS,training_not_applicable=10368,test_not_applicable=1728,elapsed_wall_s=time.perf_counter()-begin,unique_compute_ids=len({r["compute_id"] for r in by_id.values()})))


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("action",choices=("prepare","run"))
    parser.add_argument("--workers",type=int,default=2)
    args=parser.parse_args()
    if args.action=="prepare":
        config,manifest=prepare()
        print(json.dumps(dict(prepared=True,executable_training=TRAIN_RUNS,executable_test=TEST_RUNS,manifest_rows=len(manifest),version=config["version_hash"])),flush=True)
    else:
        execute(args.workers)


if __name__=="__main__":
    main()
