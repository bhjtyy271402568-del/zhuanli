# v1.5 轨迹检查编号结果

| 编号 | 数值 | CI | 来源 |
|---|---|---|---|
| [R-TR15-01] | 验收160/160条 | NA，固定种子计数 | trajectory_manifest.csv第2～161行，accepted列 |
| [R-TR15-02] | 平稳统计18/18项通过，最大标准差偏差1.678339% | NA，验收统计 | trajectory_stationary_check.csv第2～19行 |
| [R-TR15-03] | 最大拒绝采样尝试次数5 | NA | trajectory_manifest.csv，attempts列 |

## 不成立或增益消失的结果

尚未运行新轨迹上的控制比较。白噪声驱动OU没有有限的瞬时加速度RMS，因此未将回复项σ_vω₀写成总加速度RMS。有限差分统计与其0.1ms时间尺度一起保留。

trajectory_manifest.csv SHA-256 `5413bc92b53b1261df6dd5164aec4ca68e8b60a73427ab83a0cb7748e3f5ab59`。
