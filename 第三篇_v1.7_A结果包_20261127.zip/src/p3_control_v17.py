"""v1.7 Z controller with certified exact-penalty soft state constraints."""
from functools import lru_cache
import json
import math
import numpy as np
from scipy.linalg import expm
import soft_qp_v17 as quadprog
from numba import njit
from p3_control import plant_step, advance_z
from p3_control import baseline_parameters, candidate_parameters, integrate_block
from p3_rays_v16 import (position_to_angle, field_curve, perpendicular_error,
                         target_station, focus_station, defocus, required_lens_position)

PERIOD = .002
DELAY = .0015


@njit(cache=True)
def _xy_future_states(state,commands,ticks):
    current=state.copy()
    result=np.empty((len(ticks),2))
    tick=0
    for j in range(len(ticks)):
        while tick<ticks[j]:
            for axis in range(2):
                current[axis]=plant_step(current[axis],commands[tick,axis],2*math.pi*300,150000.,600.,12.,.0001)
            tick+=1
        result[j]=current[:,0]
    return result


def xy_future(state,estimate,horizon_times,configuration):
    ticks=np.rint(np.asarray(horizon_times)/.0001).astype(np.int64)
    lag=.001+.0005+1.4/(2*math.pi*300)
    times=np.arange(ticks[-1])*.0001+lag
    positions=estimate[:3]+times[:,None]*estimate[3:6]+.5*times[:,None]**2*estimate[6:9]
    commands=np.clip(position_to_angle(positions,configuration),-12,12)
    return _xy_future_states(state,commands,ticks)


@lru_cache(maxsize=256)
def zoh(hz, interval):
    wn = 2 * math.pi * hz
    continuous = np.array([[0., 1.], [-wn*wn, -1.4*wn]])
    A = expm(continuous * interval)
    B = np.linalg.solve(continuous, (A-np.eye(2)) @ np.array([0., wn*wn]))
    return A, B


@lru_cache(maxsize=32)
def fractional_matrices(hz):
    """State [position, velocity, previous command], commands arrive after 1.5 ms."""
    A, _ = zoh(hz, PERIOD)
    A_short, B_new = zoh(hz, PERIOD-DELAY)
    _, B_delay = zoh(hz, DELAY)
    F = np.zeros((3, 3))
    F[:2, :2] = A
    F[:2, 2] = A_short @ B_delay
    G = np.r_[B_new, 1.]
    N = 20
    state_s = np.eye(3)
    state_t = np.zeros((3, N))
    positions_s=[];positions_t=[];velocities_s=[];velocities_t=[]
    for k in range(N):
        state_s=F@state_s
        state_t=F@state_t
        state_t[:,k]+=G
        positions_s.append(state_s[0].copy());positions_t.append(state_t[0].copy())
        velocities_s.append(state_s[1].copy());velocities_t.append(state_t[1].copy())
    difference=np.eye(N)
    for i in range(1,N):difference[i,i-1]=-1.
    return (F,G,np.array(positions_s),np.array(positions_t),np.array(velocities_s),np.array(velocities_t),
            difference)


class ZMPC:
    def __init__(self,hz,acc_g,D_mm,configuration,parameters):
        from p3_physics import beam
        self.hz=hz;self.amax=acc_g*9810.;self.configuration=configuration;self.par=parameters
        self.zr_mm=beam(D_mm)[1]*1000;self.scale=self.zr_mm/3.08
        _,_,self.Sz,self.Tz,self.Sv,self.Tv,self.Diff=fractional_matrices(hz)
        shift=np.zeros((20,20))
        for i in range(1,20):shift[i,i-1]=1.
        self.Ma=(self.Tv-shift@self.Tv)/PERIOD
        self.C=np.vstack((self.Tz/14,self.Tv/500,self.Ma/self.amax,np.eye(20)/14))
        self.soft_counts = np.zeros(3, dtype=int)
        self.first_acceleration_activations = 0
        self.first_acceleration_contact = 0
        self.last_reference = 0.
        self.xhat=None;self.last_prev=None
        self.solver_cache={};self.failures=0;self.calls=0;self.iterations=0;self.last_status='not_called';self.failure_records=[]

    def update_state(self,x,previous_command):
        # Known commands: old input for the first 1.5 ms, latest for the last 0.5 ms.
        if self.xhat is None:
            self.xhat=np.array(x,dtype=float)
        else:
            predicted=advance_z(self.xhat,self.last_prev,self.hz,self.amax/9810.,15)
            predicted=advance_z(predicted,previous_command,self.hz,self.amax/9810.,5)
            innovation=x[0]-predicted[0]
            predicted[0]+=.3*innovation
            predicted[1]+=30.*innovation
            self.xhat=predicted
        self.last_prev=previous_command
        return self.xhat.copy()

    def command(self,x,estimate,xy_state,previous_command):
        measured_contact = abs(x[0]) >= 14.-1e-6
        x=self.update_state(x,previous_command)
        times=np.arange(1,21)*PERIOD
        zref=estimate[2]+estimate[5]*times+.5*estimate[8]*times**2
        angles=xy_future(xy_state,estimate,times,self.configuration) if self.par['use_future_angle'] else np.repeat(xy_state[:,0][None],20,axis=0)
        curve=field_curve(angles,self.configuration)
        if self.configuration=='front':
            reference=(zref-254+curve)/3.08
            reference_velocity=(estimate[5]+estimate[8]*times+np.gradient(curve,PERIOD))/3.08
        else:
            positions=estimate[:3]+times[:,None]*estimate[3:6]+.5*times[:,None]**2*estimate[6:9]
            reference=required_lens_position(positions,angles,self.configuration)
            reference_velocity=np.gradient(reference,PERIOD)
        # The queued input is fixed over the next delay interval. Propagate its
        # actual clipped response, then express that known state at the switch
        # with an equivalent augmented initial state. For an unsaturated prefix
        # this is exactly the original fractional-ZOH augmentation.
        Ad,Bd=zoh(self.hz,DELAY)
        delayed=advance_z(x,previous_command,self.hz,self.amax/9810.)
        equivalent_x=np.linalg.solve(Ad,delayed-Bd*previous_command)
        initial=np.r_[equivalent_x,previous_command]
        weights=np.ones(20)
        start=20-self.par['K_dwell']
        if self.par['window_ratio']!=1:
            upper=x.copy();lower=x.copy()
            for k in range(20):
                vhi=min(500.,upper[1]+self.amax*PERIOD);vlo=max(-500.,lower[1]-self.amax*PERIOD)
                upper[0]=min(14.,upper[0]+(upper[1]+vhi)*PERIOD/2);upper[1]=vhi
                lower[0]=max(-14.,lower[0]+(lower[1]+vlo)*PERIOD/2);lower[1]=vlo
                if lower[0]<=reference[k]+self.scale and upper[0]>=reference[k]-self.scale:
                    start=k;break
            weights[start:min(20,start+self.par['K_dwell']+1)]=self.par['window_ratio']
        else:start=-1
        if start not in self.solver_cache:
            H=(self.Tz.T*weights)@self.Tz/self.scale**2
            H+=self.par['beta_v']*(self.Tv.T@self.Tv)/(self.scale/.01)**2
            H+=self.par['lambda_u']*(self.Diff.T@self.Diff)/self.scale**2
            self.solver_cache[start]=(H,weights.copy())
        H,weights=self.solver_cache[start]
        smooth=np.zeros(20);smooth[0]=-previous_command
        q=self.Tz.T@(weights*(self.Sz@initial-reference))/self.scale**2
        q+=self.par['beta_v']*self.Tv.T@(self.Sv@initial-reference_velocity)/(self.scale/.01)**2
        q+=self.par['lambda_u']*self.Diff.T@smooth/self.scale**2
        self.last_reference = float(reference[0])
        predicted_velocity=self.Sv@initial
        baseline_acceleration=(predicted_velocity-np.r_[x[1],predicted_velocity[:-1]])/PERIOD
        baseline=np.r_[self.Sz@initial/14,predicted_velocity/500,baseline_acceleration/self.amax,np.zeros(20)]
        bounds=np.r_[-1-baseline,-1+baseline]
        constraint=np.hstack((self.C.T,-self.C.T))
        self.calls+=1
        try:
            result=quadprog.solve_qp(2*H,-2*q,constraint,bounds)
            solution = result[0][:20]
            slacks = result[0][20:]
            self.soft_counts += np.any(slacks.reshape(3,20) > 1e-6, axis=1)
            if slacks[40] > 1e-6:
                self.first_acceleration_activations += 1
                self.first_acceleration_contact += int(measured_contact)
            relaxed = np.r_[slacks, np.zeros(20)]
            violation = float(max(np.max(np.abs(self.C@solution+baseline)-1-relaxed), -np.min(slacks)))
            self.iterations+=int(result[3][0])
            ok=np.isfinite(solution).all() and violation<=1e-6
            self.last_status='solved' if ok else 'constraint_check_failed'
        except ValueError as error:
            self.last_status=str(error);ok=False;violation=None
        if not ok:
            self.failures+=1
            self.failure_records.append(dict(call=self.calls,status=self.last_status,max_normalized_constraint_violation=violation,feedback_state=x.tolist(),previous_command=float(previous_command),reference_first_mm=float(reference[0])))
            return float(np.clip(previous_command,-14,14)),False
        return float(np.clip(solution[0],-14,14)),True


def run_control(position_mm,states,valid,case,method,parameters,calibration_bias_mm=0.,return_series=False):
    from p3_physics import beam
    hz=case["z_Hz"];acc_g=case["a_g"];configuration=case["configuration"]
    mpc=None if method in ("B0","B1") else ZMPC(hz,acc_g,case["D_mm"],configuration,parameters)
    z=np.zeros(2);xy=np.zeros((2,2));z_history=np.zeros((4001,2));xy_history=np.zeros((4001,2,2))
    z_schedule=np.zeros(4021);xy_schedule=np.zeros((4021,2))
    active_z=0.;active_xy=np.zeros(2);lowpass=0.;previous_z=0.;last_encoder_z=0.;last_encoder_xy=np.zeros(2)
    qp_status=[]
    reference_history = np.zeros(200)
    held_reference = 0.
    for tick in range(0,4000,5):
        if tick%10==0:
            index=tick//10;m=states[index]
            if valid[index]:
                delay=0 if method=="B0" else .001+.0005+1.4/(2*math.pi*300)
                pred=m[:3]+m[3:6]*delay+.5*m[6:9]*delay*delay
                target=np.clip(position_to_angle(pred,configuration),-12,12)
                xy_schedule[tick+10]=target
            else:xy_schedule[tick+10]=active_xy
        if tick%20==0:
            index=tick//10;m=states[index]
            enc_z=round(z[0]/.0005)*.0005
            enc_xy=np.round(xy[:,0]/(24/2**20))*(24/2**20)
            measured_z=np.array([enc_z,(enc_z-last_encoder_z)/.002])
            measured_xy=np.stack((enc_xy,(enc_xy-last_encoder_xy)/.002),axis=1)
            last_encoder_z=enc_z;last_encoder_xy=enc_xy
            if valid[index]:
                if method in ("B0","B1"):
                    lead=0 if method=="B0" else parameters["k_lead"]*(.0015+1.4/(2*math.pi*hz))
                    if configuration=='front':
                        reference=(m[2]+m[5]*lead+.5*m[8]*lead*lead-254+float(field_curve(enc_xy,configuration)))/3.08
                    else:
                        predicted_position=m[:3]+m[3:6]*lead+.5*m[6:9]*lead*lead
                        reference=float(required_lens_position(predicted_position,enc_xy,configuration))
                    held_reference = float(reference)
                    if method=="B0":lowpass=reference
                    else:lowpass+=(1-math.exp(-2*math.pi*parameters["lowpass_Hz"]*.002))*(reference-lowpass)
                    command=float(np.clip(lowpass,-14,14))
                else:
                    command,ok=mpc.command(measured_z,m,measured_xy,active_z);qp_status.append(ok)
                previous_z=command
            elif mpc is not None:
                # Encoder is available even while target measurements are invalid.
                mpc.update_state(measured_z,active_z)
            reference_history[tick//20] = mpc.last_reference if mpc is not None else held_reference
            z_schedule[tick+15]=previous_z
        # Commands are held. Z arrivals occur at 1.5ms modulo 2ms; XY at each 1ms.
        if tick>=15 and (tick-15)%20==0:active_z=z_schedule[tick]
        if tick>=10 and tick%10==0:active_xy=xy_schedule[tick].copy()
        z,xy,zs,xs=integrate_block(z,xy,active_z,active_xy,hz,acc_g,5)
        z_history[tick+1:tick+6]=zs;xy_history[tick+1:tick+6]=xs
    actual_focus=focus_station(z_history[:,0],xy_history[:,:,0],configuration)+calibration_bias_mm
    error=defocus(position_mm,z_history[:,0],xy_history[:,:,0],configuration,calibration_bias_mm)
    lateral=perpendicular_error(position_mm,xy_history[:,:,0],configuration)
    zr=beam(case["D_mm"])[1]*1000;inside=np.abs(error)<=zr
    edges=np.diff(np.concatenate(([False],inside,[False])).astype(np.int8));durations=(np.flatnonzero(edges==-1)-np.flatnonzero(edges==1))*.1
    metrics=dict(dwell=float(inside.mean()),dwell_2zR=float((np.abs(error)<=2*zr).mean()),defocus_median_mm=float(np.median(np.abs(error))),defocus_RMSE_mm=float(np.sqrt(np.mean(error**2))),defocus_P95_mm=float(np.percentile(np.abs(error),95)),defocus_P95_zR=float(np.percentile(np.abs(error),95)/zr),lateral_RMSE_mm=float(np.sqrt(np.mean(lateral*lateral))),lateral_P95_mm=float(np.percentile(lateral,95)),longest_focus_ms=float(durations.max()) if len(durations) else 0.,focus_segment_mean_ms=float(durations.mean()) if len(durations) else 0.,qp_calls=mpc.calls if mpc else 0,qp_failures=mpc.failures if mpc else 0,qp_iterations=mpc.iterations if mpc else 0,position_limit_fraction=float((np.abs(z_history[:,0])>=14-1e-6).mean()),velocity_limit_fraction=float((np.abs(z_history[:,1])>=500-1e-6).mean()))
    if not np.isfinite(z_history).all() or not np.isfinite(xy_history).all() or not np.isfinite(list(metrics.values())).all():
        raise RuntimeError("AUTOMATIC STOP: non-finite control state or metric")
    calls = mpc.calls if mpc is not None else 0
    counts = mpc.soft_counts if mpc is not None else np.zeros(3, dtype=int)
    for name, count in zip(("position", "velocity", "acceleration"), counts):
        metrics["soft_"+name+"_activation_fraction"] = float(count/max(calls,1))
    metrics["reference_outside_stroke_time_fraction"] = float(np.mean(np.abs(reference_history)>14.))
    metrics["first_acceleration_activation_calls"] = mpc.first_acceleration_activations if mpc else 0
    metrics["first_acceleration_contact_calls"] = mpc.first_acceleration_contact if mpc else 0
    metrics["qp_failure_details_json"]=json.dumps(mpc.failure_records if mpc else [])
    if return_series:return metrics,dict(z=z_history,xy=xy_history,focus_mm=actual_focus,target_station_mm=target_station(position_mm,xy_history[:,:,0],configuration),defocus_mm=error,lateral_mm=lateral)
    return metrics
