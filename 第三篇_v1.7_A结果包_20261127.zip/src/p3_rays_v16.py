"""Approved v1.6 geometry: post-scan focal length is measured along the ray."""
import numpy as np
from p3_rays_v15 import (FOCAL_MM, geometry_name, position_to_angle,
                         beam_axis, angle_to_position, perpendicular_error)


def field_curve(angle_deg,configuration):
    """Only the front-scan empirical axial field curvature remains."""
    if geometry_name(configuration)=='telecentric_ftheta':
        return .01285*np.sum(np.asarray(angle_deg)**2,axis=-1)
    return np.zeros(np.asarray(angle_deg).shape[:-1])


def target_station(position_mm,angle_deg,configuration):
    origin,direction=beam_axis(angle_deg,configuration)
    return np.sum((np.asarray(position_mm)-origin)*direction,axis=-1)


def focus_station(lens_position_mm,angle_deg,configuration):
    return FOCAL_MM+3.08*np.asarray(lens_position_mm)-field_curve(angle_deg,configuration)


def required_lens_position(position_mm,angle_deg,configuration,bias=0.):
    return (target_station(position_mm,angle_deg,configuration)-FOCAL_MM+
            field_curve(angle_deg,configuration)-bias)/3.08


def defocus(position_mm,lens_position_mm,angle_deg,configuration,bias=0.):
    """Signed target-minus-waist distance on the perpendicular beam section."""
    return target_station(position_mm,angle_deg,configuration)-focus_station(lens_position_mm,angle_deg,configuration)-bias


def waist_position(lens_position_mm,angle_deg,configuration,bias=0.):
    origin,direction=beam_axis(angle_deg,configuration)
    return origin+(focus_station(lens_position_mm,angle_deg,configuration)+bias)[...,None]*direction
