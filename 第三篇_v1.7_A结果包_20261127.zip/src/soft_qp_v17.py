"""Expanded position, velocity and acceleration soft QP with exact-feasible shortcut."""
import warnings
import numpy as np
from scipy.linalg import LinAlgWarning, solve
import quadprog_bounded

RHO = 1e6
EPSILON = 1e-6


def expand(G, a, C, b, rho):
    hessian = np.zeros((80, 80))
    hessian[:20, :20] = G
    hessian[20:, 20:] = 2*EPSILON*np.eye(60)
    linear = np.r_[a, -rho*np.ones(60)]
    constraints = np.zeros((80, 220))
    constraints[:20, :160] = C
    constraints[20:, :60] = np.eye(60)
    constraints[20:, 80:140] = np.eye(60)
    constraints[20:, 160:] = np.eye(60)
    return hessian, linear, constraints, np.r_[b, np.zeros(60)]


def diagnostics(G, a, C, b, x, multipliers):
    primal = float(max(0., np.max(b-C.T@x)))
    gradient = G@x-a
    dual = C@multipliers
    stationarity = float(np.max(np.abs(gradient-dual)))
    dual_negative = float(max(0., -min(multipliers)))
    complementarity = float(np.max(np.abs(multipliers*(C.T@x-b))))
    return dict(primal=primal, stationarity=stationarity,
                dual_negative=dual_negative, complementarity=complementarity)


def expanded_solve(G, a, C, b, rho=RHO):
    H, linear, constraints, bounds = expand(G, a, C, b, rho)
    result = list(quadprog_bounded.solve_qp(H, linear, constraints, bounds))
    active_indices = result[5]-1
    active = constraints[:, active_indices]
    k = active.shape[1]
    system = np.block([[H, -active], [-active.T, np.zeros((k,k))]])
    rhs = np.r_[linear, -bounds[active_indices]]
    with warnings.catch_warnings():
        warnings.simplefilter("error", LinAlgWarning)
        polished = solve(system, rhs, assume_a="sym")
        for _ in range(3):
            residual = rhs-system@polished
            polished += solve(system, residual, assume_a="sym")
    x = polished[:80]
    multipliers = np.zeros(220)
    multipliers[active_indices] = polished[80:]
    quality = diagnostics(H, linear, constraints, bounds, x, multipliers)
    if not np.isfinite(x).all() or max(quality.values()) > 1e-6:
        raise ValueError("expanded KKT check failed: "+str(quality))
    result[0] = x
    result[1] = .5*x@H@x-linear@x
    result[4] = multipliers
    return tuple(result)


def solve_qp(G, a, C, b, rho=RHO):
    # A feasible hard optimum is also a soft optimum when each shared slack's
    # summed upper/lower multiplier is at most rho. This certifies exact reuse.
    try:
        hard = quadprog_bounded.solve_qp(G, a, C, b)
    except ValueError:
        hard = None
    if hard is not None:
        slack_multipliers = hard[4][:60]+hard[4][80:140]
        if np.max(slack_multipliers) <= rho and np.max(b-C.T@hard[0]) <= 1e-6:
            result = list(hard)
            result[0] = np.r_[hard[0], np.zeros(60)]
            result[4] = np.r_[hard[4], rho-slack_multipliers]
            return tuple(result)
    return expanded_solve(G, a, C, b, rho)
