# quadprog有限迭代保护

原始版本：quadprog 0.1.14，来源https://github.com/quadprog/quadprog 与本轮保存的PyPI源码包。原GPLv2+许可保留在LICENSE。

只增加两项数值退出保护：外层超过10000步、累计内层超过100000步，返回新状态3；Python包装将状态3转为ValueError，沿用控制器原有的失败计数与保持上一命令。约束、目标函数、所有计算公式及原1e-6约束回查不变。不能把超限当成功，也不能因此放宽组级1%停止门限。

这些保护数值在正式重跑之前冻结，不参与训练或按测试表现调整。正常返回的路径保持原C源码运算；仍须通过训练数据上的新旧一致性检查。本模块没有替换环境中安装的原quadprog，可并列作核对。

在仿真目录的src中执行：`../.venv_run/Scripts/python.exe quadprog_bounded/build_extension.py build_ext --inplace`。需要Cython和Microsoft C++ Build Tools；编译日志、源文件及二进制哈希保存在implementation_checks/v1_6_qp_hang。
