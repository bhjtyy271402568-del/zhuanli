"""quadprog 0.1.14 with bounded iterations; unchanged optimization problem."""
from ._native import solve_qp

__version__ = '0.1.14+iteration_guard_v16'
