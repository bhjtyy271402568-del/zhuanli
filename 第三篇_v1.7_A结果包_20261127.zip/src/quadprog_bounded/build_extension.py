from pathlib import Path
from setuptools import Extension, setup

HERE=Path(__file__).resolve().parent
setup(name='quadprog-bounded-v16',version='0.1.14',
      ext_modules=[Extension('quadprog_bounded._native',
          [str(HERE/n) for n in ('linear-algebra.c','qr-update.c','quadprog.pyx','solve.QP.c')])])
