"""v1.6 XY hold-delay compensation and additive acquisition diagnostics."""
import math
import numpy as np
from numba import njit
from p3_control import plant_step
from p3_rays_v16 import position_to_angle,angle_to_position,perpendicular_error


@njit(cache=True)
def follow_commands(commands_deg,delay_ticks):
    state=np.zeros((2,2))
    history=np.zeros((4001,2,2))
    applied=np.zeros(2)
    for tick in range(4000):
        source=tick-delay_ticks
        if source>=0 and source%10==0:
            applied=commands_deg[source//10]
        for axis in range(2):
            target=min(12.,max(-12.,applied[axis]))
            state[axis]=plant_step(state[axis],target,2*math.pi*300,150000.,600.,12.,.0001)
        history[tick+1]=state
    return history


def b1_xy(position,states,valid,geometry,delay_ticks=10):
    lead=delay_ticks*.0001+.0005+1.4/(2*math.pi*300)
    predicted=states[:,:3]+lead*states[:,3:6]+.5*lead**2*states[:,6:9]
    commands=position_to_angle(predicted,geometry)
    previous=np.zeros(2)
    for i in range(len(commands)):
        if valid[i]:previous=commands[i].copy()
        else:commands[i]=previous
    history=follow_commands(commands,delay_ticks)
    error=perpendicular_error(position,history[:,:,0],geometry)
    return error,history


def error_metrics(error):
    bad=error>2
    changes=np.diff(np.r_[False,bad,False].astype(np.int8))
    starts=np.flatnonzero(changes==1)
    ends=np.flatnonzero(changes==-1)
    result=dict(median_mm=float(np.median(error)),P95_mm=float(np.percentile(error,95)),
                RMSE_mm=float(np.sqrt(np.mean(error**2))),max_loss_ms=float(np.max(ends-starts)*.1) if len(starts) else 0.,
                loss_segments=[dict(start_ms=float(a*.1),end_ms=float(b*.1),duration_ms=float((b-a)*.1)) for a,b in zip(starts,ends)])
    for name,part in [('first20',error[:200]),('after20',error[200:])]:
        result.update({name+'_median_mm':float(np.median(part)),name+'_P95_mm':float(np.percentile(part,95)),name+'_RMSE_mm':float(np.sqrt(np.mean(part**2)))})
    return result


def capture_index(error_mm,dt_s=.0001):
    """Start of the first strict <1 mm run spanning >=5 ms, endpoints included."""
    intervals=int(round(.005/dt_s))
    required=intervals+1
    good=np.asarray(error_mm)<1.
    changes=np.diff(np.r_[False,good,False].astype(np.int8))
    starts=np.flatnonzero(changes==1);ends=np.flatnonzero(changes==-1)
    eligible=starts[(ends-starts)>=required]
    return int(eligible[0]) if len(eligible) else None


def capture_metrics(error_mm,dt_s=.0001):
    """Additional statistics; all-period official metrics remain unchanged."""
    start=capture_index(error_mm,dt_s)
    names=('post_capture_lateral_median_mm','post_capture_lateral_P95_mm',
           'post_capture_lateral_RMSE_mm','post_capture_max_loss_ms')
    result=dict(capture_time_ms=None if start is None else float(start*dt_s*1000))
    if start is None:
        result.update({name:None for name in names});return result
    part=np.asarray(error_mm)[start:]
    changes=np.diff(np.r_[False,part>2.,False].astype(np.int8))
    durations=np.flatnonzero(changes==-1)-np.flatnonzero(changes==1)
    result.update(zip(names,(float(np.median(part)),float(np.percentile(part,95)),
        float(np.sqrt(np.mean(part**2))),float(np.max(durations)*dt_s*1000) if len(durations) else 0.)))
    return result
