"""User-approved ideal telecentric F-theta and angular-projection ray models.

Mechanical angles are degrees, optical slopes use twice the mechanical angle.
The angular-projection origin is the equivalent galvo pivot at (0, 0, 0).
"""
import numpy as np

FOCAL_MM=254.


def geometry_name(configuration):
    if configuration in ('front','telecentric_ftheta'):
        return 'telecentric_ftheta'
    if configuration in ('post','angular_projection'):
        return 'angular_projection'
    raise ValueError(configuration)


def position_to_angle(position_mm,configuration):
    position=np.asarray(position_mm)
    if geometry_name(configuration)=='telecentric_ftheta':
        optical=position[...,:2]/FOCAL_MM
    else:
        optical=np.arctan2(position[...,:2],position[...,2,None])
    return np.rad2deg(optical)/2


def beam_axis(angle_deg,configuration):
    optical=np.deg2rad(np.asarray(angle_deg))*2
    origin=np.zeros(optical.shape[:-1]+(3,))
    direction=np.zeros_like(origin)
    if geometry_name(configuration)=='telecentric_ftheta':
        origin[...,:2]=FOCAL_MM*optical
        direction[...,2]=1.
    else:
        direction[...,:2]=np.tan(optical)
        direction[...,2]=1.
        direction/=np.linalg.norm(direction,axis=-1,keepdims=True)
    return origin,direction


def angle_to_position(angle_deg,depth_mm,configuration):
    origin,direction=beam_axis(angle_deg,configuration)
    travel=(np.asarray(depth_mm)-origin[...,2])/direction[...,2]
    return (origin+travel[...,None]*direction)[...,:2]


def field_curve(angle_deg,configuration):
    angle=np.asarray(angle_deg)
    if geometry_name(configuration)=='telecentric_ftheta':
        return .01285*np.sum(angle**2,axis=-1)
    _,direction=beam_axis(angle,configuration)
    return FOCAL_MM*(1/direction[...,2]-1)


def perpendicular_error(position_mm,angle_deg,configuration):
    origin,direction=beam_axis(angle_deg,configuration)
    displacement=np.asarray(position_mm)-origin
    return np.linalg.norm(np.cross(displacement,direction),axis=-1)


def axial_distance_along_ray(position_mm,focus_depth_mm,angle_deg,configuration):
    origin,direction=beam_axis(angle_deg,configuration)
    target_station=np.sum((np.asarray(position_mm)-origin)*direction,axis=-1)
    waist_station=(np.asarray(focus_depth_mm)-origin[...,2])/direction[...,2]
    return target_station-waist_station
