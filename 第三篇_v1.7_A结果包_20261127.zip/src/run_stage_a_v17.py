"""Reproducible pilot and Stage A execution using the approved plant and observer."""
import os
for name in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS"):
    os.environ[name] = "1"

import argparse
from concurrent.futures import ProcessPoolExecutor
import csv
from functools import lru_cache
import hashlib
import itertools
import json
from pathlib import Path
import platform
import time
import numpy as np
from scipy.stats import qmc
from p3_control_v17 import baseline_parameters, candidate_parameters, run_control
from p3_rays_v16 import required_lens_position
from p3_xy_v16 import capture_metrics
from p3_estimator_v15 import observer_series
from p3_physics import beam

BASE = Path(__file__).resolve().parents[1]
OUT = BASE / "out_A_v17"
PILOT = BASE / "out_pilot_v17"
WORKERS = 19
METHODS = ["B0", "B1", "B1-MPC", "B2-pos", "B2-vel", "B2-fc", "P3-control"]
MAIN = dict(D_mm=7, z_Hz=30, a_g=4, configuration="front", depth_tier="A1", los_sigma_mrad=.5)


def encode(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, allow_nan=False)


def sha(value):
    return hashlib.sha256(encode(value).encode()).hexdigest()


def atomic_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name + f".{os.getpid()}.tmp")
    temp.write_text(encode(value), encoding="utf-8")
    temp.replace(path)


def csv_write(path, rows):
    if not rows:
        return
    temp = path.with_suffix(".tmp")
    with temp.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    temp.replace(path)


def code_version():
    names = ["run_stage_a_v17.py", "p3_control_v17.py", "soft_qp_v17.py", "p3_control.py", "p3_estimator_v15.py", "p3_rays_v16.py", "p3_rays_v15.py", "p3_xy_v16.py", "p3_physics.py", "params_p3_run_v1_3.json"]
    names += [p.relative_to(BASE/'src').as_posix() for p in sorted((BASE/'src/quadprog_bounded').iterdir()) if p.suffix in ('.py','.pyx','.c','.pyd')]
    return sha({name: hashlib.sha256((BASE / "src" / name).read_bytes()).hexdigest() for name in names})[:16]


def stratum(seed):
    if seed < 2000:
        return "Center" if seed < 1014 else "Edge" if seed < 1027 else "Z-Maneuver"
    return "Center" if seed < 2040 else "Edge" if seed < 2080 else "Z-Maneuver"


def tuning_candidates(method):
    points = qmc.Sobol(d=6, scramble=True, seed=20261126).random_base2(6)[:48]
    baseline = baseline_parameters()
    rows = []
    for index, point in enumerate(points):
        parameters = baseline.copy() if index == 0 else candidate_parameters(method, point)
        components = []
        if method == "B1":
            components.extend([parameters["k_lead"] - 1., np.log10(parameters["lowpass_Hz"]) - 2])
        if method not in ("B0", "B1"):
            components.append((np.log10(parameters["lambda_u"]) + 3) / 3)
        if method in ("B2-pos", "P3-control"):
            components.extend([np.log10(parameters["window_ratio"]) / 2, (parameters["K_dwell"] - 4) / 8])
        if method in ("B2-vel", "P3-control"):
            components.append(parameters["beta_v"] / 10)
        if method in ("B2-fc", "P3-control"):
            components.append(float(parameters["use_future_angle"]))
        rows.append(dict(candidate=index, parameters=parameters, baseline_distance=float(np.linalg.norm(components))))
    return rows


def effective_parameters(method, parameters):
    if method == "B0":
        return {}
    if method == "B1":
        return {key: parameters[key] for key in ("k_lead", "lowpass_Hz")}
    return {key: parameters[key] for key in ("lambda_u", "window_ratio", "K_dwell", "beta_v", "use_future_angle")}


def job(stage, case, method, candidate, seed, blind, version):
    record = dict(stage=stage, case=case, method=method, candidate=candidate["candidate"],
                  parameters=candidate["parameters"], seed=seed, blind=blind, version=version)
    record["run_id"] = sha(record)[:24]
    physical = dict(case=case, method=method if method in ("B0", "B1") else "MPC",
                    parameters=effective_parameters(method, candidate["parameters"]), seed=seed, blind=blind, version=version)
    record["cache_key"] = sha(physical)[:32]
    return record


@lru_cache(maxsize=64)
def trajectory(seed):
    data = np.load(BASE / f"inputs_frozen/trajectories_v15/{seed}.npz")
    return data["position_mm"], float(data["calibration_residual_mm"])


@lru_cache(maxsize=64)
def estimate(seed, depth, noise, blind, replay, version, configuration):
    key = sha([seed, depth, noise, blind, replay, version, configuration])[:24]
    path = OUT / "observer_cache" / f"{key}.npz"
    if path.exists():
        with np.load(path) as data:
            return data["states"], data["valid"]
    position, _ = trajectory(seed)
    states, _, valid, _ = observer_series(position, seed, depth, noise, blind, replay, geometry=configuration)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(f"{key}.{os.getpid()}.tmp.npz")
    np.savez_compressed(temp, states=states, valid=valid)
    try:
        temp.rename(path)
    except OSError:
        if not path.exists():
            raise
        with np.load(path) as existing:
            if not np.array_equal(existing["states"],states) or not np.array_equal(existing["valid"],valid):
                raise RuntimeError("Concurrent observer cache values differ")
        temp.unlink()
    return states, valid


def evaluate(task):
    started = time.perf_counter()
    cache = OUT / "physical_runs" / task["version"] / f"{task['cache_key']}.json"
    if cache.exists():
        stored = json.loads(cache.read_text(encoding="utf-8"))
        if stored["sha256"] != sha(stored["metrics"]):
            raise RuntimeError("Completed result hash mismatch")
        return task, stored["metrics"], 0., True
    seed = task["seed"]
    position, bias = trajectory(seed)
    case = task["case"]
    states, valid = estimate(seed, case["depth_tier"], case["los_sigma_mrad"], task["blind"], task["method"] != "B0", task["version"], case["configuration"])
    metrics, series = run_control(position, states, valid, case, task["method"], task["parameters"], bias, True)
    zr = beam(case["D_mm"])[1] * 1000
    inside = np.abs(series["defocus_mm"]) <= zr
    edges = np.diff(np.r_[False, inside, False].astype(np.int8))
    durations = (np.flatnonzero(edges == -1) - np.flatnonzero(edges == 1)) * .1
    required = required_lens_position(position, series["xy"][:, :, 0], case["configuration"], bias)
    reachable = np.abs(required) <= 14
    metrics.update(lateral_median_mm=float(np.median(series["lateral_mm"])),
                   geometric_unreachable_fraction=float((~reachable).mean()),
                   reachable_dwell=float(inside[reachable].mean()) if reachable.any() else None,
                   focus_segments_ms_json=encode(durations.tolist()),
                   focus_time_in_segments_ge_1ms=float(durations[durations >= 1].sum() / 400.1),
                   focus_time_in_segments_ge_5ms=float(durations[durations >= 5].sum() / 400.1),
                   focus_time_in_segments_ge_10ms=float(durations[durations >= 10].sum() / 400.1),
                   sampled_acceleration_limit_fraction=float((np.abs(np.diff(series["z"][:, 1]) / .0001) >= case["a_g"] * 9810 * .999).mean()))
    metrics.update(capture_metrics(series["lateral_mm"]))
    wall = time.perf_counter() - started
    stored = dict(metrics=metrics, sha256=sha(metrics), wall_s=wall, seed=seed, case=case, method=task["method"])
    atomic_json(cache, stored)
    return task, metrics, wall, False


def flat_result(result):
    task, metrics, elapsed, reused = result
    return dict(run_id=task["run_id"], stage=task["stage"], **task["case"], method=task["method"],
                candidate=task["candidate"], seed=task["seed"], stratum=stratum(task["seed"]), blind=int(task["blind"]),
                cache_key=task["cache_key"], reused=int(reused), wall_s=elapsed, **metrics)


def run_group(executor, tasks, output, label):
    output.mkdir(parents=True, exist_ok=True)
    csv_write(output / f"{label}_manifest.csv", [dict(run_id=t["run_id"], cache_key=t["cache_key"], seed=t["seed"], method=t["method"], candidate=t["candidate"], blind=int(t["blind"]), case_json=encode(t["case"])) for t in tasks])
    rows = []
    for result in executor.map(evaluate, tasks, chunksize=1):
        row = flat_result(result)
        rows.append(row)
        if len(rows) % 20 == 0 or len(rows) == len(tasks):
            csv_write(output / f"{label}_results.csv", rows)
            atomic_json(output / f"{label}_checkpoint.json", dict(status="complete" if len(rows) == len(tasks) else "running", completed=len(rows), expected=len(tasks), unique_executed=sum(1-r["reused"] for r in rows)))
    return rows


def check_qp(rows):
    groups = {}
    for row in rows:
        key = tuple(row[k] for k in ("method", "D_mm", "z_Hz", "a_g", "configuration", "depth_tier", "los_sigma_mrad"))
        group = groups.setdefault(key, [0, 0])
        group[0] += row["qp_failures"]
        group[1] += row["qp_calls"]
    return [dict(group=list(key), failures=v[0], calls=v[1], rate=v[0]/v[1] if v[1] else 0.) for key,v in groups.items()]


def pilot(executor, version):
    cases = [dict(MAIN, D_mm=d, z_Hz=hz, a_g=acc, configuration=config) for d,hz,acc,config in [(7,25,3,"front"),(14,150,6,"front"),(7,150,6,"post"),(14,25,3,"post")]]
    tasks = []
    for index in range(100):
        method = METHODS[index % 7]
        case = cases[(index // 7) % 4]
        seed = [1000,1014,1027,1006][(index // 28) % 4]
        blind = bool((index // 28) % 2)
        candidate = tuning_candidates(method)[1]
        tasks.append(job("pilot", case, method, candidate, seed, blind, version))
    begin = time.perf_counter()
    rows = run_group(executor, tasks, PILOT, "pilot")
    groups = check_qp(rows)
    times = np.array([row["wall_s"] for row in rows if not row["reused"]])
    method_means = {m: float(np.mean([r["wall_s"] for r in rows if r["method"]==m and not r["reused"]])) for m in METHODS}
    elapsed = time.perf_counter()-begin
    # Project the observed worker schedule. Serial work is reported separately.
    A_serial_hours = (53760 + 95760) * float(np.mean(list(method_means.values()))) / 3600
    A_scheduled_hours = (53760 + 95760) * elapsed / len(rows) / 3600
    report = dict(status="passed", completed=100, expected=100, code_version=version,
                  elapsed_wall_s=elapsed, workers=WORKERS, cpu_logical=os.cpu_count(), python=platform.python_version(),
                  independent_runs=len(times), reused=100-len(times), single_run_median_s=float(np.median(times)),
                  single_run_P95_s=float(np.percentile(times,95)), by_method_mean_s=method_means,
                  A_serial_work_projection_hours=A_serial_hours, A_worker_schedule_projection_hours=A_scheduled_hours, ABC_projection_hours=None,
                  ABC_projection_status="B and C runtimes are not yet measured; A-only estimate cannot establish the total", qp_groups=groups)
    if any(g["rate"]>.01 for g in groups):
        report["status"]="failed_QP_rate"
    if A_scheduled_hours > 72:
        report["status"]="stopped_estimated_A_schedule_exceeds_72_hours"
    atomic_json(PILOT/"timing_report.json",report)
    (PILOT/"run_log.md").write_text("100次试点覆盖两档口径、25/150Hz、3/6g、前后扫描、7方法及两种盲窗。计时仅用于调度。首次JIT与估计器未命中费用保留在单次耗时中。求解失败按方法与物理工况合并，单次失败保留在原始结果。完整A+B+C耗时尚需B/C执行器实测。\n",encoding="utf-8")
    print(encode(report),flush=True)
    if report["status"]!="passed":
        raise RuntimeError("AUTOMATIC STOP: "+report["status"])
    return report


def train(executor, version, D):
    all_scores = []
    winners = {}
    case = dict(MAIN, D_mm=D)
    for method in METHODS:
        candidates = tuning_candidates(method)
        tasks = [job("A_train",case,method,c,seed,blind,version) for c in candidates for seed in range(1000,1040) for blind in (False,True)]
        label = f"train_D{D}_{method}"
        begin=time.perf_counter()
        rows=run_group(executor,tasks,OUT/"training",label)
        for candidate in candidates:
            subset=[r for r in rows if r["candidate"]==candidate["candidate"]]
            utility=float(np.mean([np.mean([r["dwell"] for r in subset if r["stratum"]==layer and r["blind"]==blind]) for layer in ("Center","Edge","Z-Maneuver") for blind in (0,1)]))
            all_scores.append(dict(D_mm=D,method=method,candidate=candidate["candidate"],utility=utility,baseline_distance=candidate["baseline_distance"],parameters_json=encode(candidate["parameters"])))
        scores=[r for r in all_scores if r["method"]==method]
        best=max(r["utility"] for r in scores)
        chosen=min((r for r in scores if best-r["utility"]<1e-4),key=lambda r:(r["baseline_distance"],r["candidate"]))
        winners[method]=dict(candidate=chosen["candidate"],parameters=json.loads(chosen["parameters_json"]),train_utility=chosen["utility"])
        csv_write(OUT/f"training_scores_D{D}.csv",all_scores)
        atomic_json(OUT/f"trained_parameters_D{D}.json",winners)
        groups=check_qp(rows)
        atomic_json(OUT/"training"/f"{label}_qp_check.json",groups)
        print(encode(dict(stage="training",D=D,method=method,completed=len(rows),chosen_candidate=chosen["candidate"],utility=chosen["utility"],wall_s=time.perf_counter()-begin,qp=groups)),flush=True)
        if any(g["rate"]>.01 for g in groups):
            raise RuntimeError("AUTOMATIC STOP: training method-condition QP failure rate exceeds 1 percent")
    winners["B2-best"] = max((m for m in METHODS if m.startswith("B2-")), key=lambda m:winners[m]["train_utility"])
    atomic_json(OUT/f"trained_parameters_D{D}.json",winners)
    return winners


def test_cases():
    cases=[]
    for D,hz,acc,config in itertools.product([7,14],[25,40,80,150],[3,4,6],["front","post"]):
        cases.append((dict(MAIN,D_mm=D,z_Hz=hz,a_g=acc,configuration=config),range(2000,2120),"core"))
    cases.append((MAIN.copy(),range(2000,2120),"main"))
    for corner in [False,True]:
        base=dict(MAIN,z_Hz=25,a_g=3) if corner else MAIN.copy()
        seeds=range(2040,2080) if corner else range(2000,2120)
        for depth in ["A2","B1","B2"]:
            cases.append((dict(base,depth_tier=depth),seeds,"corner" if corner else "oat"))
        for noise in [.2,1.5,4]:
            cases.append((dict(base,los_sigma_mrad=noise),seeds,"corner" if corner else "oat"))
    assert len(cases)==61 and sum(len(s)*14 for _,s,_ in cases)==95760
    return cases


def is_preview(case):
    return case["D_mm"]==7 and case["a_g"]==4 and case["configuration"]=="front" and case["depth_tier"]=="A1" and case["los_sigma_mrad"]==.5


def tests(executor,version,trained,preview):
    for index,(case,seeds,part) in enumerate(test_cases()):
        if is_preview(case)!=preview:
            continue
        tasks=[job("A_test",case,m,trained[case["D_mm"]][m],seed,blind,version) for m in METHODS for seed in seeds for blind in (False,True)]
        label=f"case_{index:02d}"
        rows=run_group(executor,tasks,OUT/"test",label)
        groups=check_qp(rows)
        atomic_json(OUT/"test"/f"{label}_qp_check.json",groups)
        print(encode(dict(stage="test",case=case,preview=preview,completed=len(rows),qp=groups)),flush=True)
        if any(g["rate"]>.01 for g in groups):
            raise RuntimeError("AUTOMATIC STOP: test method-condition QP failure rate exceeds 1 percent")



def consistency(executor,version):
    case=dict(MAIN,D_mm=14,a_g=6)
    tasks=[job("runner_consistency",dict(case,z_Hz=hz),method,tuning_candidates(method)[1],seed,False,version)
           for seed in range(1000,1040) for method in METHODS for hz in (25,150)]
    rows=run_group(executor,tasks,BASE/"implementation_checks/v1_7_runner","runner")
    reference=list(csv.DictReader((BASE/"implementation_checks/v1_6_control/bandwidth_matched_runs.csv").open(encoding="utf-8-sig")))
    lookup={(int(r["seed"]),r["method"],int(r["z_Hz"])):r for r in reference}
    differences=[]
    for row in rows:
        ref=lookup[(row["seed"],row["method"],row["z_Hz"])]
        differences.append(max(abs(row[k]-float(ref[k])) for k in ("defocus_median_mm","lateral_RMSE_mm","qp_calls","qp_failures")))
    report=dict(status="passed" if max(differences)<=1e-10 else "failed",completed=len(rows),expected=560,max_absolute_difference=max(differences),code_version=version)
    atomic_json(BASE/"implementation_checks/v1_6_runner/checkpoint.json",report)
    print(encode(report),flush=True)
    if report["status"]!="passed":raise RuntimeError("AUTOMATIC STOP: runner consistency failed")


def main():
    parser=argparse.ArgumentParser();parser.add_argument("--pilot-only",action="store_true");parser.add_argument("--consistency-only",action="store_true")
    args=parser.parse_args()
    OUT.mkdir(exist_ok=True);PILOT.mkdir(exist_ok=True)
    version=code_version()
    atomic_json(OUT/"run_metadata.json",dict(version=version,expected_training=53760,expected_test=95760,methods=METHODS,workers=WORKERS,parameters_file="src/params_p3_run_v1_3.json",candidate_design="Scrambled six-dimensional Sobol seed20261126 first48; candidate0 replaced by baseline; inactive coordinates ignored for ties",training_utility="equal mean of three strata and two blind states"))
    with ProcessPoolExecutor(max_workers=WORKERS) as executor:
        if args.consistency_only:
            consistency(executor,version)
            return
        previous_report=PILOT/"timing_report.json"
        report=json.loads(previous_report.read_text(encoding="utf-8")) if previous_report.exists() else {}
        if report.get("status")!="passed" or report.get("code_version")!=version:
            report=pilot(executor,version)
        if args.pilot_only:
            return
        trained={7:train(executor,version,7)}
        tests(executor,version,trained,True)
        atomic_json(OUT/"preview_checkpoint.json",dict(status="complete",train_logical=26880,test_logical=8400))
        trained[14]=train(executor,version,14)
        tests(executor,version,trained,False)
    atomic_json(OUT/"execution_checkpoint.json",dict(status="raw_runs_complete",training=53760,test=95760,statistics_pending=True))


if __name__=="__main__":
    main()
