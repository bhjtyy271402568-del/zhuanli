"""Frozen, training-independent trajectory-cluster statistics for completed Stage A."""
import os
for name in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[name]='1'
import argparse
from concurrent.futures import ProcessPoolExecutor
import csv
import hashlib
import json
import platform
import time
from pathlib import Path
import numpy as np
from run_stage_a_v17 import test_cases,is_preview,METHODS,stratum

BASE=Path(__file__).resolve().parents[1]
OUT=BASE/'out_A_v17'
METRICS=['dwell','defocus_median_mm','defocus_P95_mm','lateral_median_mm','longest_focus_ms']
SUPPLEMENT=['lateral_P95_mm','geometric_unreachable_fraction','capture_time_ms','post_capture_lateral_median_mm','post_capture_lateral_P95_mm','post_capture_lateral_RMSE_mm','post_capture_max_loss_ms']
HIGHER={'dwell','longest_focus_ms'}
LAYERS=['Center','Edge','Z-Maneuver']
BLINDS=['combined_blind','blind0','blind1']
COMPARISONS=[(m,'B1-MPC') for m in METHODS if m!='B1-MPC']+[(m,'B1') for m in ['B2-pos','B2-vel','B2-fc','P3-control']]
REPS=10000
SEED=20261126


def read_csv(path):
    with path.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))


def write_csv(path,rows):
    if not rows:raise ValueError('No rows for '+str(path))
    temp=path.with_suffix('.tmp')
    with temp.open('w',encoding='utf-8-sig',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    temp.replace(path)


def write_json(path,value):
    temp=path.with_suffix('.tmp');temp.write_text(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8');temp.replace(path)


def rng_for(case_index,blind_index,layer_index,kind=0):
    return np.random.default_rng(np.random.SeedSequence([SEED,case_index,blind_index,layer_index,kind]))


def bootstrap_counts(n,rng):
    draws=rng.integers(0,n,(REPS,n))
    counts=np.zeros((REPS,n),dtype=np.int16)
    np.add.at(counts,(np.arange(REPS)[:,None],draws),1)
    return counts


def bootstrap_medians(values,counts):
    """Exact resampled median from integer counts, without sorting each sample."""
    values=np.asarray(values)
    if values.ndim==1:values=values[:,None]
    n=int(counts[0].sum());low=(n-1)//2;high=n//2
    result=np.empty((len(counts),values.shape[1]))
    for column in range(values.shape[1]):
        order=np.argsort(values[:,column],kind='stable');ordered=values[order,column]
        cdf=np.cumsum(counts[:,order],axis=1)
        lo=np.argmax(cdf>low,axis=1);hi=np.argmax(cdf>high,axis=1)
        result[:,column]=(ordered[lo]+ordered[hi])*.5
    return result


def sign_flip_p(values,rng):
    values=np.asarray(values,dtype=float);observed=abs(float(values.mean()))
    if np.all(values==0):return 1.
    signs=2*rng.integers(0,2,(REPS,len(values)),dtype=np.int8)-1
    null=np.abs(signs@values/len(values))
    return float((1+np.count_nonzero(null>=observed-1e-15))/(REPS+1))


def holm(p_values):
    p=np.asarray(p_values,dtype=float);order=np.argsort(p,kind='stable');adjusted=np.empty(len(p))
    adjusted[order]=np.minimum(1,np.maximum.accumulate(p[order]*(len(p)-np.arange(len(p)))))
    return adjusted


def selfcheck():
    checks=[]
    def check(name,value):checks.append(dict(check=name,passed=bool(value)))
    c=bootstrap_counts(4,np.random.default_rng(SEED))
    check('zero_bootstrap',np.all(c@np.zeros(4)/4==0) and np.all(bootstrap_medians(np.zeros(4),c)==0))
    check('constant_bootstrap',np.all(c@np.full(4,3.)/4==3) and np.all(bootstrap_medians(np.full(4,3.),c)==3))
    check('zero_sign_flip',sign_flip_p(np.zeros(40),np.random.default_rng(SEED))==1)
    check('holm_hand_calculation',np.allclose(holm([.01,.04,.03]),[.03,.06,.06]))
    draws=np.array([[0,0,1,3],[3,2,1,0],[2,2,2,2]])
    counts=np.zeros((3,4),dtype=np.int16);np.add.at(counts,(np.arange(3)[:,None],draws),1)
    values=np.array([1.,10.,3.,-5.])
    check('count_median_equals_explicit',np.array_equal(bootstrap_medians(values,counts)[:,0],np.median(values[draws],axis=1)))
    blind=np.array([[1.,5.],[2.,8.]])
    check('two_blinds_one_cluster',np.array_equal(blind.mean(axis=1),[3.,5.]))
    check('group_rng_repeat_and_mode_independent',np.array_equal(bootstrap_counts(4,rng_for(48,0,0)),bootstrap_counts(4,rng_for(48,0,0))))
    check('stratum_equal_weight',np.mean([np.mean([0,0]),np.mean([6])])==3)
    result=dict(status='passed' if all(c['passed'] for c in checks) else 'failed',checks=checks)
    write_json(OUT/'statistics_selfcheck.json',result)
    if result['status']!='passed':raise RuntimeError('Statistics self-check failed')
    return result


def valid_completed_group(folder,label,expected):
    checkpoint=folder/(label+'_checkpoint.json');result=folder/(label+'_results.csv');manifest=folder/(label+'_manifest.csv');qp=folder/(label+'_qp_check.json')
    if not all(p.exists() for p in (checkpoint,result,manifest,qp)):return None
    state=json.loads(checkpoint.read_text(encoding='utf-8'))
    if state.get('status')!='complete' or state.get('completed')!=expected or state.get('expected')!=expected:return None
    rows=read_csv(result);declared=read_csv(manifest)
    if len(rows)!=expected or len(declared)!=expected:raise ValueError('Completed count mismatch '+label)
    identifiers=[r['run_id'] for r in rows];planned=[r['run_id'] for r in declared]
    if len(set(identifiers))!=expected or set(identifiers)!=set(planned):raise ValueError('Manifest run_id mismatch '+label)
    for item in json.loads(qp.read_text(encoding='utf-8')):
        if item['rate']>.01:raise ValueError('QP gate not passed '+label)
    return rows


def collect(preview):
    groups=[];pending=[];completed=0
    selected=[(i,c,list(seeds),part) for i,(c,seeds,part) in enumerate(test_cases()) if not preview or is_preview(c)]
    for index,case,seeds,part in selected:
        label=f'case_{index:02d}';expected=len(seeds)*len(METHODS)*2
        rows=valid_completed_group(OUT/'test',label,expected)
        if rows is None:pending.append(label);continue
        keys=[(r['method'],int(r['seed']),int(r['blind'])) for r in rows]
        wanted={(m,s,b) for m in METHODS for s in seeds for b in (0,1)}
        if len(set(keys))!=expected or set(keys)!=wanted:raise ValueError('Method-seed-blind mismatch '+label)
        for row in rows:
            if row['stage']!='A_test' or row['stratum']!=stratum(int(row['seed'])):raise ValueError('Stage/stratum mismatch '+label)
            if any(str(row[k])!=str(v) for k,v in case.items()):raise ValueError('Case mismatch '+label)
            if not np.isfinite([float(row[m]) for m in METRICS]).all():raise ValueError('Non-finite metric '+label)
        for method in METHODS:
            own=[r for r in rows if r['method']==method]
            calls=sum(int(r['qp_calls']) for r in own);failures=sum(int(r['qp_failures']) for r in own)
            if calls and failures/calls>.01:raise ValueError('Raw QP rate exceeds gate '+label)
        groups.append((index,case,seeds,part,rows));completed+=expected
    train_completed=0;train_pending=[]
    for D in ([7] if preview else [7,14]):
        for method in METHODS:
            label=f'train_D{D}_{method}'
            rows=valid_completed_group(OUT/'training',label,3840)
            if rows is None:train_pending.append(label)
            else:train_completed+=len(rows)
    status=dict(status='ready' if not pending and not train_pending else 'waiting_for_complete_groups',
                completed_test=completed,expected_test=8400 if preview else 95760,completed_training=train_completed,
                expected_training=26880 if preview else 53760,completed_conditions=len(groups),expected_conditions=5 if preview else 61,
                pending_test_groups=pending,pending_training_groups=train_pending)
    return groups,status


def group_statistics(index,case,seeds,rows):
    lookup={(r['method'],int(r['seed']),int(r['blind'])):r for r in rows}
    summaries=[];pairs=[];tests=[];supplement=[]
    source=f'test/case_{index:02d}_results.csv'
    for blind_index,blind in enumerate(BLINDS):
        selected_blinds=[0,1] if blind_index==0 else [blind_index-1]
        layer_data={};layer_counts={}
        for layer_index,layer in enumerate(LAYERS):
            selected=[s for s in seeds if stratum(s)==layer]
            if not selected:continue
            matrix=np.array([[[np.mean([float(lookup[m,s,b][metric]) for b in selected_blinds]) for metric in METRICS] for m in METHODS] for s in selected])
            layer_data[layer]=matrix
            layer_counts[layer]=bootstrap_counts(len(selected),rng_for(index,blind_index,layer_index))
        for layer in list(layer_data)+['All_strata_equal_weight']:
            layer_names=list(layer_data) if layer=='All_strata_equal_weight' else [layer]
            values=np.concatenate([layer_data[l] for l in layer_names],axis=0)
            counts=np.concatenate([layer_counts[l] for l in layer_names],axis=1)
            means=np.mean([layer_data[l].mean(axis=0) for l in layer_names],axis=0)
            boot_means=np.mean([((layer_counts[l]@layer_data[l].reshape(len(layer_data[l]),-1))/len(layer_data[l])).reshape(REPS,len(METHODS),len(METRICS)) for l in layer_names],axis=0)
            n=len(values);base=dict(case_index=index,**case,stratum=layer,blind=blind,trajectories=n,layers_json=json.dumps(layer_names),source_csv=source)
            for m,method in enumerate(METHODS):
                for k,metric in enumerate(METRICS):
                    low,high=np.percentile(boot_means[:,m,k],[2.5,97.5])
                    summaries.append(dict(**base,method=method,metric=metric,higher_is_better=metric in HIGHER,mean=float(means[m,k]),CI95_low=float(low),CI95_high=float(high)))
            delta=np.stack([values[:,METHODS.index(m),:]-values[:,METHODS.index(ref),:] for m,ref in COMPARISONS],axis=1)
            boot_median=bootstrap_medians(delta.reshape(n,-1),counts).reshape(REPS,len(COMPARISONS),len(METRICS))
            for j,(method,reference) in enumerate(COMPARISONS):
                m=METHODS.index(method);r=METHODS.index(reference)
                for k,metric in enumerate(METRICS):
                    mean_diff=means[m,k]-means[r,k]
                    low,high=np.percentile(boot_means[:,m,k]-boot_means[:,r,k],[2.5,97.5])
                    median_low,median_high=np.percentile(boot_median[:,j,k],[2.5,97.5])
                    pairs.append(dict(**base,method=method,reference=reference,metric=metric,higher_is_better=metric in HIGHER,
                                      paired_mean_difference=float(mean_diff),mean_CI95_low=float(low),mean_CI95_high=float(high),
                                      paired_median_difference=float(np.median(delta[:,j,k])),median_CI95_low=float(median_low),median_CI95_high=float(median_high)))
            # The only inferential family: main case 48, paired two-blind means, each layer.
            if index==48 and blind_index==0 and layer in LAYERS:
                for method_index,method in enumerate(['B2-pos','B2-vel','B2-fc']):
                    difference=values[:,METHODS.index(method),0]-values[:,METHODS.index('B1-MPC'),0]
                    probability=sign_flip_p(difference,rng_for(index,0,LAYERS.index(layer),100+method_index))
                    tests.append(dict(case_index=index,**case,stratum=layer,blind=blind,method=method,reference='B1-MPC',metric='dwell',trajectories=n,
                                      paired_mean_difference=float(difference.mean()),p_raw=probability,permutations=REPS,source_csv=source))
            selected=[s for s in seeds if stratum(s) in layer_names]
            for method in METHODS:
                for metric in SUPPLEMENT:
                    per_layer=[];missing=0;available=0
                    for name in layer_names:
                        cluster_values=[]
                        for seed in selected:
                            if stratum(seed)!=name:continue
                            raw=[lookup[method,seed,b].get(metric,'') for b in selected_blinds]
                            if any(value in ('','None','null') for value in raw):missing+=1;continue
                            cluster_values.append(np.mean([float(value) for value in raw]));available+=1
                        if cluster_values:per_layer.append(float(np.mean(cluster_values)))
                    supplement.append(dict(**base,method=method,metric=metric,available_clusters=available,missing_clusters=missing,
                                           conditional_mean=float(np.mean(per_layer)) if len(per_layer)==len(layer_names) else None,
                                           interpretation='descriptive; nonmissing clusters only; no CI or test'))
    return summaries,pairs,tests,supplement


def statistics_worker(group):
    index,case,seeds,part,rows=group
    return group_statistics(index,case,seeds,rows)


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--preview',action='store_true');parser.add_argument('--selfcheck',action='store_true');args=parser.parse_args()
    OUT.mkdir(exist_ok=True);selfcheck()
    if args.selfcheck:
        print('Statistics artificial-data self-checks passed.',flush=True);return
    prefix='preview_' if args.preview else ''
    started=time.perf_counter()
    groups,status=collect(args.preview)
    write_json(OUT/(prefix+'statistics_checkpoint.json'),status)
    if status['status']!='ready':
        print(json.dumps(status,ensure_ascii=False),flush=True);return
    summaries=[];pairs=[];tests=[];supplement=[];source_map=[];source_hashes={}
    with ProcessPoolExecutor(max_workers=19) as pool:
        grouped_results=list(pool.map(statistics_worker,groups))
    for (index,case,seeds,part,rows),(a,b,c,d) in zip(groups,grouped_results):
        summaries.extend(a);pairs.extend(b);tests.extend(c);supplement.extend(d)
        source=f'test/case_{index:02d}_results.csv'
        source_hashes[source]=hashlib.sha256((OUT/source).read_bytes()).hexdigest()
        source_map.extend(dict(case_index=index,source_csv=source,run_id=r['run_id'],seed=int(r['seed']),stratum=r['stratum'],method=r['method'],blind=int(r['blind']),candidate=int(r['candidate'])) for r in rows)
        print(f'statistics completed condition {len(source_hashes)}/{len(groups)}',flush=True)
    if len(tests)!=9:raise ValueError('Expected exactly nine preregistered tests')
    for row,adjusted in zip(tests,holm([r['p_raw'] for r in tests])):
        row['p_holm']=float(adjusted);row['reject_at_0_05']=bool(adjusted<=.05)
    for name,rows in [('summary.csv',summaries),('paired_differences.csv',pairs),('main_tests_holm.csv',tests),('supplementary_summary.csv',supplement),('source_map.csv',source_map)]:write_csv(OUT/(prefix+name),rows)
    pair_lookup={(r['case_index'],r['stratum'],r['blind'],r['method'],r['reference'],r['metric']):(line,r) for line,r in enumerate(pairs,2)}
    report=[f'# 阶段 A {"批次2预览" if args.preview else "完整阶段"}编号结果',
            f'\n[R-A17-01] 本报告范围完成测试{status["completed_test"]}/{status["expected_test"]}；训练{status["completed_training"]}/{status["expected_training"]}；物理工况{len(groups)}/{status["expected_conditions"]}。'+('这是正式A的预览子集；完整A目标仍为95760测试及53760训练，本文不宣称完整阶段完成。' if args.preview else ''),
            '\n[R-A17-02] 主指标保留400ms全时段。每seed两盲窗等权合簇，另列单盲窗结果；10000次按轨迹分层Bootstrap，百分位95%CI。总体层等权，未按时间点抽样。具体固定口径见statistical_plan.md。',
            '\n[R-A17-03] 九项主检验：主点三个B2相对B1-MPC，各三层，驻留占比，双侧符号翻转10000次与Holm校正。以下p值不用于其他比较。',
            '\n|方法|层|n|配对均差及95%CI|Holm p|拒绝零假设|主检验CSV行 / 配对CSV行|','|---|---|---:|---|---:|---|---|']
    for test_line,row in enumerate(tests,2):
        pair_line,pair=pair_lookup[(row['case_index'],row['stratum'],row['blind'],row['method'],row['reference'],row['metric'])]
        report.append(f"|{row['method']}|{row['stratum']}|{row['trajectories']}|{row['paired_mean_difference']:.8g} [{pair['mean_CI95_low']:.8g}, {pair['mean_CI95_high']:.8g}]|{row['p_holm']:.7g}|{row['reject_at_0_05']}|{test_line} / {pair_line}|")
    report.append(f'\n上述行号分别对应 `{prefix}main_tests_holm.csv` 和 `{prefix}paired_differences.csv`，包括表头第1行。主检验来自 `test/case_48_results.csv`，其SHA256为 `{source_hashes["test/case_48_results.csv"]}`；其余源文件哈希见 `{prefix}statistics_checkpoint.json` 的source_hashes。')
    report+=['\n## 不成立或增益消失的结果','\n[R-A17-04] 下列主检验未通过Holm门限或均差不为正；这些结果保留，不据此追加调参。']
    unsuccessful=[r for r in tests if not r['reject_at_0_05'] or r['paired_mean_difference']<=0]
    report += [f"- {r['method']}/{r['stratum']}：驻留差{r['paired_mean_difference']:.8g}，Holm p={r['p_holm']:.7g}。" for r in unsuccessful] or ['- 九项中没有符合上述条件的条目；适用范围仍仅为预登记主检验。']
    described=[r for r in pairs if r['metric']=='dwell' and r['blind']=='combined_blind' and r['reference']=='B1-MPC']
    nonpositive=sum(r['paired_mean_difference']<=0 for r in described);cross=sum(r['mean_CI95_low']<=0<=r['mean_CI95_high'] for r in described)
    report += [f'\n[R-A17-05] 其他适用性描述：combined_blind、对B1-MPC的驻留差条目共{len(described)}个（含各层及总体），其中{nonpositive}个均差≤0，{cross}个95%CI包含0。完整条目保留在配对表；这些重叠子组不构成独立全局检验。',
               '\n[R-A17-06] 补充表列横向P95、不可达率、捕获和捕获后指标。未捕获保留缺失并列数量，条件均值只针对非缺失簇；没有以捕获后统计替代全时段结果。',
               '\n所有表以case_index/stratum/method/blind与source_map.csv映射原run_id/seed。数值是算法仿真；本文不写实物损伤、专利新颖性或工程可用性的结论。']
    (OUT/(prefix+'results_for_writing.md')).write_text('\n'.join(report)+'\n',encoding='utf-8')
    status.update(status='statistics_complete',wall_s=time.perf_counter()-started,python_version=platform.python_version(),numpy_version=np.__version__,bootstrap_repetitions=REPS,seed=SEED,main_tests=9,summary_rows=len(summaries),paired_rows=len(pairs),source_hashes=source_hashes,
                  code_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),plan_sha256=hashlib.sha256((OUT/'statistical_plan.md').read_bytes()).hexdigest())
    write_json(OUT/(prefix+'statistics_checkpoint.json'),status)
    (OUT/(prefix+'statistics_run_log.md')).write_text(f'# 统计运行日志\n\n读取完整正式组：测试{status["completed_test"]}/{status["expected_test"]}、训练{status["completed_training"]}/{status["expected_training"]}。仅后处理，没有重新执行控制器。墙钟{status["wall_s"]:.3f}秒；Python {platform.python_version()}，NumPy {np.__version__}。\n\n10000次分层轨迹Bootstrap及九项双侧配对符号翻转/Holm，按测试前冻结方案执行。源CSV哈希、统计代码哈希和计划哈希见statistics_checkpoint（预览有preview_前缀）。本次执行8项统计自检，并核对各组原始数据与运行清单。采用19个单线程进程按工况并行，随机种子按原方案逐组固定。\n',encoding='utf-8')
    print(json.dumps({k:v for k,v in status.items() if k!='source_hashes'},ensure_ascii=False),flush=True)


if __name__=='__main__':main()
