"""v1.3: shared substep geometry; recent heat is integrated before coarse binning.

The 0.1 ms plant grid is unchanged. Four midpoint quadrature panels per
geometric substep integrate the varying source; n_sub itself follows the brief.
Old histories use time-averaged radial flux in the existing 0.1 ms kernel.
"""
import math
import numpy as np
from numba import njit
from scipy.special import i0e
from scipy.stats import ncx2
from p3_heat_memory import HeatMemory, DT, KAPPA


QUADRATURE_PANELS = 4


def subdivision(e0, e1, w0, w1, radius=None):
    scale = min(w0, w1)
    if radius is not None:
        scale = min(scale, radius)
    requested = max(1, math.ceil(np.linalg.norm(np.asarray(e1)-e0)/(scale/4)))
    return min(requested, 200), requested


def sampled_inputs(times, e_xy, widths, power, radius=.00025, panels=QUADRATURE_PANELS,
                   bg_centres=None, bg_widths=None):
    """All positions/widths are in metres; use vector displacement through centre."""
    starts=[]; ends=[]; offsets=[]; ws=[]; powers=[]; blocks=[]; rows=[]
    for k in range(len(times)-1):
        n, requested=subdivision(e_xy[k],e_xy[k+1],widths[k],widths[k+1],radius)
        bn=1; breq=1
        if bg_centres is not None:
            bn,breq=subdivision(bg_centres[k],bg_centres[k+1],bg_widths[k],bg_widths[k+1])
        # Attenuation on the background also varies with target interception.
        count=max(n,bn)*panels
        edges=np.linspace(times[k],times[k+1],count+1)
        f=(np.arange(count)+.5)/count
        starts.extend(edges[:-1]);ends.extend(edges[1:]);blocks.extend([k]*count)
        offsets.extend(e_xy[k]+f[:,None]*(e_xy[k+1]-e_xy[k]))
        ws.extend(widths[k]+f*(widths[k+1]-widths[k]))
        powers.extend(np.repeat(power[k],count))
        rows.append((n,requested,bn,breq,count))
    result=dict(starts=np.array(starts),ends=np.array(ends),e_xy=np.array(offsets),
                w=np.array(ws),power=np.array(powers),block=np.array(blocks),
                subdivision=np.array(rows,dtype=int))
    offset=np.linalg.norm(result['e_xy'],axis=1)
    result['eta']=ncx2.cdf(4*radius**2/result['w']**2,2,4*offset**2/result['w']**2)
    return result


def radial_sources(sample, alpha, radial_nodes):
    w=sample['w'][:,None]; e=np.linalg.norm(sample['e_xy'],axis=1)[:,None]
    r=radial_nodes[None]
    return 2*alpha*sample['power'][:,None]/(math.pi*w*w)*np.exp(-2*((r-e)/w)**2)*i0e(4*r*e/(w*w))


@njit(cache=True)
def direct_temperature(time, starts, ends, source, r, weights):
    total=0.
    for i in range(len(starts)):
        if starts[i]>=time:break
        old=time-starts[i];young=max(0.,time-ends[i])
        for j in range(len(r)):
            if source[i,j]==0:continue
            a=math.erfc(r[j]/(2*math.sqrt(KAPPA*old)))
            b=math.erfc(r[j]/(2*math.sqrt(KAPPA*young))) if young>0 else 0.
            total+=(a-b)*weights[j]*source[i,j]
    return total


def coarse_average(sample, source, times):
    result=np.zeros((len(times)-1,source.shape[1]))
    duration=sample['ends']-sample['starts']
    np.add.at(result,sample['block'],source*duration[:,None])
    return result/np.diff(times)[:,None]


class AdaptiveHeatHistory:
    """Direct recent substeps plus coarse older bins; exact same source budget.

    Used for physical-time convergence. Long runs can feed the averaged bins to
    HeatMemory: its already verified exponential tail uses those same bins.
    """
    def __init__(self,times,sample,alpha=.05,near_s=.002):
        self.times=times;self.sample=sample;self.near=near_s
        table=HeatMemory();self.r=table.r;self.weights=table.weights
        self.source=radial_sources(sample,alpha,self.r)
        self.coarse=coarse_average(sample,self.source,times)

    def at(self,t):
        # Move only whole 0.1 ms bins to the old history; never discard a near substep.
        cut=max(0,min(len(self.times)-1,int(math.floor((t-self.near)/DT+1e-10))))
        old=direct_temperature(t,self.times[:cut],self.times[1:cut+1],self.coarse[:cut],self.r,self.weights)
        first=np.searchsorted(self.sample['block'],cut)
        return old+direct_temperature(t,self.sample['starts'][first:],self.sample['ends'][first:],self.source[first:],self.r,self.weights)


def background_samples(sample,times,centres,widths,alpha=.05):
    mid=(sample['starts']+sample['ends'])/2
    centre=np.stack([np.interp(mid,times,centres[:,a]) for a in range(2)],axis=1)
    w=np.interp(mid,times,widths)
    energy=sample['power']*(1-alpha*sample['eta'])*(sample['ends']-sample['starts'])
    return centre,w,energy


def fluence_at(points,centre,w,energy):
    # SI J/m^2 at fixed positions, never a moving-centre fluence.
    answer=np.zeros(len(points))
    for first in range(0,len(energy),2048):
        last=first+2048
        square=np.sum((points[:,None]-centre[None,first:last])**2,axis=2)
        answer+=np.exp(-2*square/w[None,first:last]**2)@(2*energy[first:last]/(math.pi*w[first:last]**2))
    return answer
