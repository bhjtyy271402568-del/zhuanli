"""v1.3 temporal convergence: 48 fixed cases + two training-only closed-loop records."""
from pathlib import Path
import csv
import hashlib
import json
import math
import shutil
import time
import numpy as np
from scipy.fft import rfft,irfft,next_fast_len
from scipy.special import erfc
from scipy.optimize import brentq, minimize_scalar
from p3_heat_memory import HeatMemory,DT,KAPPA
from p3_physics import beam
from p3_adaptive_input import sampled_inputs,radial_sources,AdaptiveHeatHistory,background_samples,fluence_at

BASE=Path(__file__).resolve().parents[1]
OUT=BASE/'implementation_checks'


def write_csv(path,rows):
    with path.open('w',encoding='utf-8-sig',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)


def reference(case,refinement):
    """Independent uniform grid; full history FFT of exact radial Green intervals."""
    step=DT/refinement;n=int(round(case['times'][-1]/step))
    edges=np.arange(n+1)*step;mid=(edges[:-1]+edges[1:])/2
    e=np.stack([np.interp(mid,case['times'],case['e'][:,a]) for a in range(2)],axis=1)
    w=np.interp(mid,case['times'],case['w'])
    sample=dict(starts=edges[:-1],ends=edges[1:],e_xy=e,w=w,power=np.full(n,50.))
    from scipy.stats import ncx2
    sample['eta']=ncx2.cdf(4*.00025**2/w**2,2,4*np.sum(e*e,axis=1)/w**2)
    table=HeatMemory();source=radial_sources(sample,.05,table.r)
    size=next_fast_len(2*n-1);spectrum=np.zeros(size//2+1,dtype=complex)
    for first in range(0,len(table.r),16):
        last=first+16
        S=np.zeros((n+1,min(16,len(table.r)-first)))
        S[1:]=erfc(table.r[None,first:last]/(2*np.sqrt(KAPPA*edges[1:,None])))*table.weights[None,first:last]
        H=np.diff(S,axis=0)
        spectrum+=np.sum(rfft(source[:,first:last],n=size,axis=0)*rfft(H,n=size,axis=0),axis=1)
    temp=np.maximum(0,irfft(spectrum,n=size)[:n])
    return edges,np.concatenate(([0.],temp)),sample


def interval_metrics(t,y,threshold=60.):
    above=y>=threshold;changes=np.flatnonzero(above[1:]!=above[:-1])+1
    cross=[t[i-1]+(threshold-y[i-1])/(y[i]-y[i-1])*(t[i]-t[i-1]) for i in changes]
    starts=([t[0]] if above[0] else [])+cross[0 if not above[0] else 1::2]
    ends=cross[1 if not above[0] else 0::2]+([t[-1]] if above[-1] else [])
    return (float(starts[0]) if starts else None),max((b-a for a,b in zip(starts,ends)),default=0.)


def adaptive_metrics(history,case):
    # Standard cases have one crossing. Real cases get ten probes per plant step.
    step=DT/(10 if case['kind']=='closed_loop' else 1)
    t=np.linspace(0,case['times'][-1],round(case['times'][-1]/step)+1)
    y=np.array([history.at(q) for q in t]);above=y>=60
    changes=np.flatnonzero(above[1:]!=above[:-1])+1
    roots=[brentq(lambda s:history.at(s)-60,t[i-1],t[i],xtol=1e-11) for i in changes]
    starts=([0.] if above[0] else [])+roots[0 if not above[0] else 1::2]
    ends=roots[1 if not above[0] else 0::2]+([t[-1]] if above[-1] else [])
    return t,y,(float(starts[0]) if starts else None),max((b-a for a,b in zip(starts,ends)),default=0.)


def cases_standard():
    cases=[]
    for speed in [.03,.1,.3,1.]:
        for D in [7,14]:
            w0,zr,_=beam(D)
            for centre in [.002325,.00235,.002375]:
                for zscale in [0,2]:
                    t=np.arange(31)*DT;w=beam(D,zscale*zr*1000)[2]
                    e=np.stack((speed*(t-centre),np.zeros_like(t)),axis=1)
                    cases.append(dict(id=f'v{speed}_D{D}_phase{centre*1e6:.0f}_dz{zscale}zR',kind='standard',D=D,speed=speed,centre_s=centre,defocus_zR=zscale,times=t,e=e,w=np.full(len(t),w),bg_c=e*(354/254),bg_w=np.full(len(t),beam(D,100-zscale*zr*1000)[2])))
    return cases


def closed_loop_cases():
    from p3_control import run_control,baseline_parameters
    from p3_estimator import observer_series
    cases=[]
    for seed,D in [(1000,7),(1014,14)]:
        path=OUT/f'heat_training_motion_{seed}_D{D}.npz'
        if not path.exists():
            d=np.load(BASE/f'inputs_frozen/trajectories/{seed}.npz')
            states,_,valid,_=observer_series(d['position_mm'],seed,'A1',.5,True)
            _,series=run_control(d['position_mm'],states,valid,dict(D_mm=D,z_Hz=30,a_g=4,configuration='front'),'B1-MPC',baseline_parameters(),float(d['calibration_residual_mm']),True)
            p=d['position_mm'];angles=series['xy'][:,:,0]*math.pi/180*2
            e=(p[:,2,None]*np.tan(angles)-p[:,:2])/1000
            width=np.array([beam(D,z)[2] for z in series['defocus_mm']])
            zbg=float(np.max(p[:,2])+100)
            bg_c=zbg*np.tan(angles)/1000
            bg_w=np.array([beam(D,zbg-z)[2] for z in series['focus_mm']])
            # Select six milliseconds around the closest approach, after filter initialization.
            centre=int(np.argmin(np.linalg.norm(e[200:],axis=1)))+200
            start=max(0,min(3940,centre-30));end=start+61
            np.savez_compressed(path,times=np.arange(61)*DT,e=e[start:end],w=width[start:end],bg_c=bg_c[start:end],bg_w=bg_w[start:end],seed=seed,D=D,original_start_s=start*DT,selection='minimum lateral offset after 20 ms, six-ms excerpt; thermal state zero at excerpt start')
        d=dict(np.load(path))
        cases.append(dict(id=f'train_seed{seed}_D{D}',kind='closed_loop',D=D,speed=None,centre_s=None,defocus_zR=None,**{k:d[k] for k in ['times','e','w','bg_c','bg_w']}))
    return cases


def run_case(case):
    begin=time.perf_counter()
    fine_t,fine_T,fine_s=reference(case,256)
    coarse_t,coarse_T,coarse_s=reference(case,128)
    first_ref,hold_ref=interval_metrics(fine_t,fine_T)
    first_coarse,hold_coarse=interval_metrics(coarse_t,coarse_T)
    observed=case['times'][1:]
    ref_at=np.interp(observed,fine_t,fine_T)
    cref_at=np.interp(observed,coarse_t,coarse_T)
    relevant=np.maximum(ref_at,1e-12)
    ref_relative=float(np.max(np.abs(cref_at-ref_at)/relevant))
    # Exact zero remains an attained-status check, not an invented relative error.
    ref_pass=ref_relative<=.001 and ((first_ref is None)==(first_coarse is None))
    if first_ref is not None:
        ref_pass=ref_pass and abs(first_ref-first_coarse)<=max(.001*first_ref,2e-8)
    ref_pass=ref_pass and abs(hold_ref-hold_coarse)<=max(.001*hold_ref,2e-8)
    sample=sampled_inputs(case['times'],case['e'],case['w'],np.full(len(case['times'])-1,50.),bg_centres=case['bg_c'],bg_widths=case['bg_w'])
    duration=sample['ends']-sample['starts']
    eta=float(sample['eta']@duration);eta_ref=float(fine_s['eta']@(fine_s['ends']-fine_s['starts']))
    eta_err=abs(eta-eta_ref)/max(eta_ref,1e-300)
    cb,wb,eb=background_samples(sample,case['times'],case['bg_c'],case['bg_w'])
    cr,wr,er=background_samples(fine_s,case['times'],case['bg_c'],case['bg_w'])
    # Identical fixed physical coordinates for coarse/fine fluence, including the reference peak.
    centroid=np.average(cr,axis=0,weights=er)
    spread=max(float(np.max(wr)),float(np.linalg.norm(np.ptp(cr,axis=0))))
    from scipy.optimize import minimize
    peak=minimize(lambda xy:-fluence_at(np.asarray(xy)[None],cr,wr,er)[0],centroid,method='Nelder-Mead',options=dict(xatol=1e-10,fatol=1e-7)).x
    x,y=np.meshgrid(np.linspace(peak[0]-spread,peak[0]+spread,9),np.linspace(peak[1]-spread,peak[1]+spread,9))
    points=np.vstack((np.stack((x.ravel(),y.ravel()),axis=1),peak))
    h=fluence_at(points,cb,wb,eb);hr=fluence_at(points,cr,wr,er)
    h_error=float(np.max(np.abs(h-hr)/np.maximum(hr,1e-300)))
    rows=[]
    for near_ms in [1,2,4]:
        history=AdaptiveHeatHistory(case['times'],sample,near_s=near_ms/1000)
        t,y,first,hold=adaptive_metrics(history,case)
        pred=np.array([history.at(q) for q in observed])
        errors=np.abs(pred-ref_at);allowed=np.maximum(.01*ref_at,.1)
        # Also check the actual peak of the independent solution.
        peak_t=fine_t[int(np.argmax(fine_T))];peak_ref=float(np.max(fine_T));peak_actual=history.at(peak_t)
        max_ratio=max(float(np.max(errors/allowed)),abs(peak_actual-peak_ref)/max(.01*peak_ref,.1))
        time_error=None if first is None or first_ref is None else abs(first-first_ref)
        time_pass=(first is None)==(first_ref is None) and (time_error is None or time_error<=max(.01*first_ref,2e-6))
        hold_error=abs(hold-hold_ref);hold_pass=hold_error<=max(.01*hold_ref,2e-6)
        sub=sample['subdivision']
        rows.append(dict(case_id=case['id'],kind=case['kind'],D_mm=case['D'],speed_m_s=case['speed'],centre_time_s=case['centre_s'],defocus_zR=case['defocus_zR'],near_ms=near_ms,
            deltaT_end_K=float(pred[-1]),deltaT_end_ref_K=float(ref_at[-1]),temperature_max_normalized_error=max_ratio,reference_max_relative_error=ref_relative,
            first_threshold_s=first,first_threshold_ref_s=first_ref,first_error_us=None if time_error is None else time_error*1e6,
            continuous_hold_s=hold,continuous_hold_ref_s=hold_ref,hold_error_us=hold_error*1e6,
            eta_time_integral_s=eta,eta_time_integral_ref_s=eta_ref,eta_relative_error=eta_err,H_fixed_peak_J_m2=float(np.max(h)),H_fixed_peak_ref_J_m2=float(np.max(hr)),H_fixed_points_max_relative_error=h_error,
            n_sub_min=int(sub[:,0].min()),n_sub_max=int(sub[:,0].max()),n_sub_mean=float(sub[:,0].mean()),n_sub_histogram=json.dumps(dict(zip(*[v.tolist() for v in np.unique(sub[:,0],return_counts=True)]))),
            capped_steps=int(np.sum((sub[:,1]>200)|(sub[:,3]>200))),requested_n_sub_max=int(sub[:,1].max()),quadrature_evaluations=len(sample['starts']),plant_steps=len(case['times'])-1,
            reference_passed=bool(ref_pass),temperature_passed=max_ratio<=1,first_passed=bool(time_pass),hold_passed=bool(hold_pass),capture_passed=eta_err<=.01,background_passed=h_error<=.01,
            passed=bool(ref_pass and max_ratio<=1 and time_pass and hold_pass and eta_err<=.01 and h_error<=.01)))
    np.savez_compressed(OUT/'heat_v2_series'/f"{case['id']}.npz",reference_times_s=fine_t,reference_deltaT_K=fine_T,plant_times_s=case['times'],subdivision=sample['subdivision'])
    for row in rows:row['case_total_wall_s']=time.perf_counter()-begin
    return rows


def main():
    (OUT/'heat_v2_series').mkdir(exist_ok=True)
    shutil.copy2(Path(r'C:\Users\Administrator\Desktop\Hubstudio\新建环境1\第三篇_停止后修正指令_20261127.md'),BASE/'参考输入/第三篇_停止后修正指令_20261127.md')
    p=json.loads((BASE/'src/params_p3_run_v1_2.json').read_text(encoding='utf-8'))
    p['version']='1.3-adaptive-input';p['date']='2026-11-27'
    p['adaptive_input']=dict(quarter_radius_rule=True,max_substeps=200,source_quadrature_panels=4,near_ms=2,near_sensitivity_ms=[1,2,4],reference_uniform_refinement=[128,256],temperature_relative_tolerance=.01,temperature_absolute_K=.1,time_absolute_us=2)
    (BASE/'src/params_p3_run_v1_3.json').write_text(json.dumps(p,ensure_ascii=False,indent=2),encoding='utf-8')
    allcases=cases_standard()+closed_loop_cases();rows=[]
    for i,case in enumerate(allcases):
        new=run_case(case);rows.extend(new)
        write_csv(OUT/'moving_heat_convergence_v2.csv',rows)
        print(json.dumps(dict(completed=i+1,total=len(allcases),case=case['id'],main_passed=new[1]['passed'],main_temperature_ratio=new[1]['temperature_max_normalized_error']),ensure_ascii=False),flush=True)
    mainrows=[r for r in rows if r['near_ms']==2]
    report=dict(version='1.3',status='passed' if all(r['passed'] for r in mainrows) else 'failed',standard_cases=48,closed_loop_training_cases=2,main_passed=sum(r['passed'] for r in mainrows),sensitivity_passed=sum(r['passed'] for r in rows),sensitivity_total=len(rows),failed_rows=[i+2 for i,r in enumerate(rows) if not r['passed']],scope='Only adaptive-input selfchecks; accepted P0/trajectory/estimator/controller checks not rerun')
    (OUT/'moving_heat_checkpoint_v2.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    print(json.dumps(report),flush=True)
    if report['status']!='passed':raise RuntimeError('AUTOMATIC STOP: v1.3 convergence failure; inspect absolute-error floors and implementation before reporting')


if __name__=='__main__':main()
