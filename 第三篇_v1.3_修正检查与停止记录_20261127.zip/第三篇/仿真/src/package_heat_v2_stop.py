"""Package actual v1.3 check outputs after the required automatic stop."""
from pathlib import Path
import csv,hashlib,json,shutil,zipfile

BASE=Path(__file__).resolve().parents[1]
OUT=BASE/'implementation_checks'


def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    rows=list(csv.DictReader((OUT/'moving_heat_convergence_v2.csv').open(encoding='utf-8-sig')))
    mainrows=[r for r in rows if r['near_ms']=='2']
    diagnosis=json.loads((OUT/'moving_heat_v2_diagnosis.json').read_text(encoding='utf-8'))
    original=json.loads((BASE/'PROVENANCE.json').read_text(encoding='utf-8'))
    accepted=[]
    for item in original['files']:
        name=item['path']
        protected=name.startswith('out_P0/') or name.startswith('inputs_frozen/') or name.startswith('implementation_checks/estimator_') or name.startswith('implementation_checks/control_') or name in ['src/p3_control.py','src/p3_estimator.py','src/p3_trajectories.py']
        if protected:
            assert digest(BASE/name)==item['sha256'],name
            accepted.append(name)
    (OUT/'accepted_outputs_unchanged_v1_3.json').write_text(json.dumps(dict(unchanged=True,verified_files=len(accepted),paths=accepted),ensure_ascii=False,indent=2),encoding='utf-8')
    p12=json.loads((BASE/'src/params_p3_run_v1_2.json').read_text(encoding='utf-8'))
    p13=json.loads((BASE/'src/params_p3_run_v1_3.json').read_text(encoding='utf-8'))
    assert {k:v for k,v in p13.items() if k not in ('version','date','adaptive_input')}=={k:v for k,v in p12.items() if k not in ('version','date')}
    for name in ['总索引.md','run_state.json']:
        archive=BASE/(Path(name).stem+'_v1_2_停止记录'+Path(name).suffix)
        if not archive.exists():shutil.copy2(BASE/name,archive)
    actual=list(csv.DictReader((OUT/'moving_heat_v2_independent_diagnosis.csv').open(encoding='utf-8-sig')))[3]
    relative=float(actual['relative_error'])*100
    state=json.loads((BASE/'run_state.json').read_text(encoding='utf-8'))
    state.update(version='1.3',status='AUTOMATIC_STOP_WAITING_FOR_INSTRUCTION',date='2026-11-27',simulations_running=False,
                 stop_reason='Confirmed recent-substep source quadrature error beyond 1 percent and 0.1 K floor',
                 trigger_file='implementation_checks/moving_heat_v2_diagnosis.json',maximum_relative_error=None,
                 independently_confirmed_relative_error=float(actual['relative_error']),
                 stop_authority='第三篇_停止后修正指令_20261127.md section 4; original automatic stop conditions unchanged',
                 next_work='Replace constant-source midpoint panels with a higher-order or weighted adaptive Green integral inside the prescribed geometric substeps; separately remove FFT near-zero reference cancellation artifacts without changing tolerances')
    state.pop('maximum_error_source_row',None)
    state['stages']['adaptive_input_check']=dict(status='failed',completed_cases=50,expected_cases=50,sensitivity_rows=150,main_rows_passing_current_checks=8,reference_qualification_incomplete=True)
    (BASE/'run_state.json').write_text(json.dumps(state,ensure_ascii=False,indent=2),encoding='utf-8')
    report=f'''# v1.3 热输入修正检查：编号事实

本阶段工具为Python数值积分，非Zemax、非实物测量。状态：自检失败后停止。

| 编号 | 数值与口径 | CI | 来源 |
|---|---|---|---|
| [R-HEAT13-01] | 48个标准算例+2个训练闭环片段；各计算1/2/4ms近历史，共150行；主值为2ms | NA：确定性检查 | moving_heat_convergence_v2.csv第2～151行；每case_id三行 |
| [R-HEAT13-02] | D7、速度0.1m/s、无离焦、过中心时刻2.325ms、观察时刻1.8ms：实现17.8580790029K；独立连续积分18.3798228501K；差0.5217438471K，{relative:.6f}% | NA | moving_heat_v2_independent_diagnosis.csv第5行；moving_heat_v2_diagnosis.json |
| [R-HEAT13-03] | 同例容差max(1%×18.3798228501K,0.1K)=0.1837982285K；实际误差超限 | NA | 同上；修正指令§3.2 |
| [R-HEAT13-04] | 独立连续积分的静止特例与已验收解析式相对差2.22e-16；该变源算例quad误差估计1.60e-12K（不等同严格误差上界） | NA | moving_heat_v2_diagnosis.json |
| [R-HEAT13-05] | 50个主值算例的几何n_sub最大28，无步骤触及200上限；每几何子步使用4个中点积分面板 | NA | moving_heat_convergence_v2.csv，near_ms=2；n_sub_*、quadrature_evaluations、capped_steps列 |
| [R-HEAT13-06] | 已认可文件{len(accepted)}个与前次交付SHA-256逐一相同；P0、冻结轨迹、估计器和控制器检查均未重跑 | NA | accepted_outputs_unchanged_v1_3.json；旧PROVENANCE.json |

## 不成立或尚不能判定的结果

- 当前子步内分段常值的热输入求积仍有实际超差，不能进入后续正式批次。
- 原始检查器50个主值中有8个通过全部检查。38个参考解比较未通过，部分源于FFT卷积对近零温升的相对误差放大；不能把这38个全部称为物理模型失败，也不能删除这些行后宣称通过。
- 温升检查15/50通过；首次阈值、保持时间、截获积分及背景固定点能流的原始比较各50/50通过。这些计数受参考解尚未全面合格的限制，**不是正式验收通过**。
- 本次背景能流检查比较81个固定坐标和一个参考峰值坐标；未完成B阶段所需的全平面空间域、网格与能量守恒验收。
- 两个实际闭环片段来自训练种子1000、1014，分别D7、D14。按初始化20ms以后最小偏心选取6ms片段，热初态从零开始。这验证记录中的局部运动，不表示重跑整条400ms热历史。
- A/B/C仍未启动，没有新增机制收益、完成率或背景安全结论。

## 诊断与后续修正范围

独立参考将有限圆盘中的空间高斯重叠用非中心卡方积分计算，再对平方根热龄做自适应时间积分。它没有使用现有径向128节点或中点源采样，静止特例另与已认可公式核对。

确认失败的1.8ms观察时刻早于2ms近历史长度：2ms、4ms两档均没有压缩旧历史。因此该例定位于最近热输入的时间求积；延长近历史不能修复这例。

后续应在既定几何子步内采用高阶、线性源精确矩或带Green权重的自适应求积，并独立处理参考卷积的近零舍入噪声。不得调整1%/0.1K/2μs门限。本次按修正指令§4保留现场，未继续修改并重跑。
'''
    (OUT/'results_for_writing_v1_3.md').write_text(report,encoding='utf-8')
    log='''# v1.3 运行日志

授权：第三篇_停止后修正指令_20261127.md。

1. 保留v1.2结果与失败记录；新建v1.3参数，仅新增热输入离散设置。
2. 新增p3_adaptive_input.py：步首/末的矢量偏心与束宽线性插值，按四分之一半径规则、上限200确定几何子步；每子步4个中点积分面板。截获和背景剩余功率在相同细分节点求值。
3. 最近1/2/4ms按细节点用Green积分；更老部分先求0.1ms平均源再积分。本次验证直接求和旧分箱，未重新拟合既有压缩核。
4. 为两项新增实际运动检查，仅重放训练种子1000和1014获取所需闭环运动。没有重跑已认可的6/139项估计器/控制器验收。
5. check_moving_heat_v2.py完成50/50组、150行，输出检查失败并以退出码1结束。50例纯检查计时合计约51.70秒；不含首次JIT/闭环运动生成，不能据此推算A/B/C总耗时。
6. diagnose_heat_v2.py独立连续积分确认一例温升误差2.84%，超过同时含绝对下限的门限。不是近零量相对误差误报。
7. 依修正指令§4停止；无后台仿真；试点/A/B/C未启动。

子步分布、求积次数、每例耗时均见moving_heat_convergence_v2.csv。4倍求积面板是数值实现开销，不改变几何n_sub或运动网格。

吸收阈值与背景上限沿用冻结假设；背景阈值是工程扫描值，没有经过作物实验验证。本轮高温仅为线性热方程计算值，不是可实现组织温度。
'''
    (OUT/'run_log_v1_3.md').write_text(log,encoding='utf-8')
    index='''# 第三篇仿真总索引 · v1.3

**状态：修正后的热积分仍有真实超差，依指令再次停止；未全跑完。** 日期：2026-11-27。

## 本次先看

1. [v1.3编号结果与失败诊断](implementation_checks/results_for_writing_v1_3.md)
2. [48标准+2闭环、三档近历史的150行结果](implementation_checks/moving_heat_convergence_v2.csv)
3. [独立连续积分核对](implementation_checks/moving_heat_v2_independent_diagnosis.csv)
4. [运行日志](implementation_checks/run_log_v1_3.md)、[状态](run_state.json)、[v1.3参数](src/params_p3_run_v1_3.json)

| 阶段 | 完成/应完成 | 状态 |
|---|---:|---|
| P0 | 478368/478368；111项自检通过 | 已获认可，未重跑 |
| 冻结轨迹 | 160/160 | 已获认可，未改动 |
| 估计器/控制器检查 | 6/6、139/139 | 已获认可，未重跑 |
| v1.3热输入数值检查 | 50/50组完成计算；150行含敏感性 | **未通过验收** |
| 100次试点 | 0/100 | 未启动 |
| A训练 | 0/53760 | 未启动 |
| A测试 | 0/95760 | 未启动 |
| B/C | 未启动，正式运行清单尚未生成 | 不填写虚假完成率 |

失败证据：D7、0.1m/s、无离焦，1.8ms处温升实现17.8581K、独立连续积分18.3798K。差0.5217K（2.84%），超过允许0.1838K。该时刻尚无压缩旧历史，问题是子步内的热源求积。

另有参考FFT近零相对误差问题，已单独披露；没有把全部参考异常都解释为模型失败。原始检查计数和未完成验证详见编号结果。

## 原有结果与证据链

- [P0编号结果](out_P0/results_for_writing.md)、[P0原始数据](out_P0/static_threshold_times.csv)
- [已认可文件未变更的哈希核对](implementation_checks/accepted_outputs_unchanged_v1_3.json)
- [上一版停止记录](总索引_v1_2_停止记录.md)、[最初6例失败表](implementation_checks/moving_heat_convergence.csv)
- [本次修正指令原件](参考输入/第三篇_停止后修正指令_20261127.md)
- [当前文件哈希清单](PROVENANCE_v1_3.json)

## 不成立或未完成事项

当前热输入修正尚未满足数值精度，不能把它用于正式M-T结果。A/B/C未运行，因此不存在本轮的控制增益、作业完成率或背景安全收益。B/C完整批量执行器仍待完成；不能将检查脚本视为已经完成的全阶段流水线。

Python数值仿真，非Zemax、非实物测量。当前没有后台仿真进程。停止依据为最新修正指令§4“确认确实是实现问题后，才停止报告”，原自动停止条件继续有效。
'''
    (BASE/'总索引.md').write_text(index,encoding='utf-8')
    files=[]
    for p in BASE.iterdir():
        if p.is_file() and p.suffix in ('.md','.json') and p.name!='PROVENANCE_v1_3.json':files.append(p)
    for directory in ['src','参考输入','out_P0','inputs_frozen','implementation_checks']:
        files.extend(p for p in (BASE/directory).rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix not in ('.pyc','.nbc','.nbi'))
    files=sorted(set(files))
    manifest=dict(version='1.3',status=state['status'],files=[dict(path=p.relative_to(BASE).as_posix(),bytes=p.stat().st_size,sha256=digest(p)) for p in files])
    mpath=BASE/'PROVENANCE_v1_3.json';mpath.write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8');files.append(mpath)
    destination=Path(r'F:\激光动态聚焦系统\第三篇\仿真\第三篇_v1.3_修正检查与停止记录_20261127.zip')
    with zipfile.ZipFile(destination,'w',compression=zipfile.ZIP_DEFLATED) as z:
        for path in files:z.write(path,'第三篇/仿真/'+path.relative_to(BASE).as_posix())
    with zipfile.ZipFile(destination) as z:
        assert z.testzip() is None
        for item in manifest['files']:assert hashlib.sha256(z.read('第三篇/仿真/'+item['path'])).hexdigest()==item['sha256']
    print(json.dumps(dict(package=str(destination),bytes=destination.stat().st_size,files=len(files),sha256=digest(destination),accepted_unchanged=len(accepted)),ensure_ascii=False))


if __name__=='__main__':main()
