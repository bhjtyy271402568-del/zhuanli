"""Read-only diagnosis after the v1.3 automatic stop; no pilot/A/B/C execution."""
from pathlib import Path
import csv,json,math
import numpy as np
from scipy.integrate import quad
from scipy.stats import ncx2
from p3_physics import beam,thermal_temperature,K,KAPPA
from p3_adaptive_input import sampled_inputs,AdaptiveHeatHistory
from check_moving_heat_v2 import cases_standard,reference

BASE=Path(__file__).resolve().parents[1]
OUT=BASE/'implementation_checks'


def continuous_reference(t,w,speed,centre,radius=.00025):
    # Integrate the spatial Gaussian overlap analytically, including the finite
    # disk via noncentral chi-square, then integrate time with u=sqrt(heat age).
    def f(u):
        spread=w*w+8*KAPPA*u*u
        e=speed*(t-u*u-centre)
        overlap=1.
        if u>0:
            variance=2*KAPPA*u*u*w*w/spread
            mean=e*8*KAPPA*u*u/spread
            overlap=ncx2.cdf(radius*radius/variance,2,mean*mean/variance)
        return 4*2.5*math.sqrt(KAPPA)/(math.pi**1.5*K*spread)*math.exp(-2*e*e/spread)*overlap
    value,error=quad(f,0,math.sqrt(t),epsabs=1e-9,epsrel=1e-10,limit=500)
    return value,error


def main():
    case=cases_standard()[12];t=.0018
    w=case['w'][0]
    exact,error=continuous_reference(t,w,.1,.002325)
    stationary,stationary_error=continuous_reference(t,w,0.,.002325)
    known=thermal_temperature(t,w,50,.05,.00025)
    rows=[]
    for refinement in [128,256]:
        tt,temperature,_=reference(case,refinement)
        rows.append(dict(type='uniform_full_history_reference',setting=refinement,temperature_K=float(np.interp(t,tt,temperature))))
    sample=sampled_inputs(case['times'],case['e'],case['w'],np.full(30,50.))
    for near_ms in [1,2,4]:
        value=AdaptiveHeatHistory(case['times'],sample,near_s=near_ms/1000).at(t)
        rows.append(dict(type='implemented_quadrature',setting=near_ms,temperature_K=value))
    for row in rows:
        row['independent_continuous_K']=exact
        row['absolute_error_K']=abs(row['temperature_K']-exact)
        row['relative_error']=abs(row['temperature_K']/exact-1)
    with (OUT/'moving_heat_v2_independent_diagnosis.csv').open('w',encoding='utf-8-sig',newline='') as f:
        wr=csv.DictWriter(f,fieldnames=list(rows[0]));wr.writeheader();wr.writerows(rows)
    summary=dict(case=case['id'],observation_time_s=t,independent_continuous_K=exact,
                 quadrature_error_estimate_K=error,stationary_formula_relative_error=abs(stationary/known-1),
                 actual_temperature_tolerance_K=max(.01*exact,.1),
                 genuine_input_quadrature_failure=rows[3]['absolute_error_K']>max(.01*exact,.1),
                 diagnosis='recent source quadrature, not compressed old history; at t=1.8ms the 2ms and 4ms variants have no compressed history')
    (OUT/'moving_heat_v2_diagnosis.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
    print(json.dumps(summary,ensure_ascii=False),flush=True)


if __name__=='__main__':main()
