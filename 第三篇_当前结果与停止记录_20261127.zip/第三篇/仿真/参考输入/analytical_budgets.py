# -*- coding: utf-8 -*-
"""
第三篇数值仿真设计说明书 —— 第 1 节解析量级核算脚本
所有光学、动力学与能量量级均由第一性原理公式直接计算，避免拍脑袋估算。
"""
import math
import numpy as np

# 1. 光学高斯光束与瑞利长度核算（严格沿用第一篇 1064 nm, f = 254 mm）
lam = 1.064e-3       # mm (1064 nm)
M2 = 1.2             # 第一篇 M2 <= 1.3，取典型值 1.2
f = 254.0            # mm
dz_ratio = 3.08      # 物方焦移 / 音圈镜组行程 (mm/mm，取自第一篇表1: 40/13.0 ≈ 3.077)

print("=== 1. 高斯光束束腰与瑞利长度核算 ===")
beam_configs = {}
for D_beam in [7.0, 14.0]:
    w_in = D_beam / 2.0  # 1/e^2 半径 (mm)
    w0 = M2 * lam * f / (math.pi * w_in)  # mm
    zR = math.pi * w0**2 / (M2 * lam)     # mm
    theta_div = w0 / zR                   # rad (半发散角)
    beam_configs[D_beam] = (w0, zR, theta_div)
    print(f"D={D_beam:4.1f} mm: w0={w0*1e3:5.2f} um (2w0={2*w0*1e3:5.1f} um), z_R={zR:5.3f} mm, 2z_R={2*zR:5.3f} mm, theta_div={theta_div*1e3:5.2f} mrad")
    for dz in [0.0, 1.0, 2.0, 5.0, 10.0, 15.0]:
        w = w0 * math.sqrt(1.0 + (dz / zR)**2)
        ratio = 1.0 / (1.0 + (dz / zR)**2)
        # 圆形目标 r_t=0.25mm 对准中心时截获功率比例 1 - exp(-2 r_t^2 / w^2)
        cap_250 = 1.0 - math.exp(-2.0 * (0.25**2) / (w**2))
        cap_500 = 1.0 - math.exp(-2.0 * (0.50**2) / (w**2))
        print(f"   dz={dz:4.1f} mm ({dz/zR:5.2f} z_R): w={w*1e3:6.1f} um, I/I0={ratio:6.4f}, cap(r=250um)={cap_250*100:5.1f}%, cap(r=500um)={cap_500*100:5.1f}%")

# 2. 穿焦时间 vs 所需作用时间核算
print("\n=== 2. 穿焦时间 T_cross = 2*z_R / |v_rel,z| vs 所需作用时间 T_req ===")
for D_beam in [7.0, 14.0]:
    w0, zR, _ = beam_configs[D_beam]
    print(f"[D={D_beam:.0f} mm, z_R={zR:.3f} mm] 穿焦时间 2*z_R/|v_rel,z| (ms):")
    for v_rel in [0.3, 0.5, 1.0, 1.5]:  # m/s = mm/ms
        t_cross = (2.0 * zR) / v_rel
        print(f"   |v_rel,z|={v_rel:.1f} m/s -> T_cross = {t_cross:.2f} ms")

print("\n按全目标能量门槛 E_th / P 计算的最短理想作用时间 (ms):")
for P in [20.0, 50.0, 100.0]:
    row = [f"E={E}mJ: {E/P:.2f}ms" for E in [20, 50, 100, 200, 300]]
    print(f"   P={P:5.1f} W -> " + " | ".join(row))

print("\n按局域辐照度门槛与离焦展宽核算 (r_t=0.25 mm, 目标面积 A_t=pi*r_t^2=1.963e-3 cm^2):")
A_t_cm2 = math.pi * (0.025**2)
for P in [20.0, 50.0]:
    for D_beam in [7.0, 14.0]:
        w0, zR, _ = beam_configs[D_beam]
        for dz in [0.0, 2.0, 5.0, 10.0]:
            w = w0 * math.sqrt(1.0 + (dz / zR)**2)
            A_beam_cm2 = math.pi * (w * 0.1)**2
            I_peak = 2.0 * P / A_beam_cm2  # W/cm^2
            # 有效作用时间达到 F_th=30 J/cm^2 (按光斑平均辐照度 P / (pi w^2))
            I_avg_spot = P / A_beam_cm2
            t_30 = (30.0 / I_avg_spot) * 1e3  # ms
            print(f"   P={P:4.0f}W, D={D_beam:2.0f}mm, dz={dz:4.1f}mm: I_avg_spot={I_avg_spot:9.1f} W/cm^2, t(30J/cm^2)={t_30:6.3f} ms")

# 3. 音圈 Z 轴滞后与饱和核算
print("\n=== 3. Z 轴音圈动态滞后与饱和核算 (物方/镜组比 = 3.08) ===")
for f_bw in [25.0, 40.0, 80.0, 150.0]:
    wn = 2.0 * math.pi * f_bw
    zeta = 0.7
    # 二阶欠阻尼系统(zeta=0.7)斜坡稳态滞后 = 2*zeta / wn * v_z; 一阶等效 = 1/wn * v_z
    t_lag_1st = 1.0 / wn * 1e3          # ms
    t_lag_2nd = (2.0 * zeta / wn) * 1e3 # ms
    print(f"f_bw={f_bw:5.1f} Hz: 一阶等效时间常数={t_lag_1st:5.2f} ms, 二阶(zeta=0.7)斜坡滞后时间={t_lag_2nd:5.2f} ms")
    for v_z in [0.3, 0.5, 1.0]:
        ez_1 = v_z * t_lag_1st  # mm
        ez_2 = v_z * t_lag_2nd  # mm
        print(f"   v_z={v_z:.1f} m/s: 一阶滞后={ez_1:5.2f} mm ({ez_1/2.14:.2f} zR7 / {ez_1/0.54:.2f} zR14); 二阶滞后={ez_2:5.2f} mm ({ez_2/2.14:.2f} zR7 / {ez_2/0.54:.2f} zR14)")

print("\nZ 轴加速度饱和下的反转接续距离与时间 (目标 Z 向反转 Δv_z = 2*v_z):")
for a_lens_g in [3.0, 6.0, 12.0]:  # 镜组加速度 (g)
    a_lens = a_lens_g * 9.81       # m/s^2
    a_obj = a_lens * dz_ratio      # 物方焦面最大加速度 (m/s^2)
    for v_z in [0.5, 1.0]:
        # 目标以 v_z 匀速反向变为 -v_z（相对速度差 2*v_z），按邦邦时间最优追及：
        # 减速到反向同速需 t_match = 2*v_z / a_obj，但位置已多跑出 Δz_over = v_z * t_match = 2*v_z^2 / a_obj
        # 完整追平位置+速度的时间最优邦邦控制时间 T_min = (2 + sqrt(2)) * v_z / a_obj ?
        # 精确解：初始 e=0, e_dot = 2*v_z, 加速度 -a_obj 先减速到 t1 反向再刹车到 t2:
        # 设相对运动 e(0)=0, e_dot(0)=dv=2*v_z，控输入 |u|<=a_obj，最小时间回原点:
        # 经典双积分器时间最优公式：T* = (1 + sqrt(2)) * dv / a_obj; 最大位置偏差 e_peak = dv^2 / (2*a_obj)
        dv = 2.0 * v_z
        t_opt = (1.0 + math.sqrt(2.0)) * dv / a_obj * 1e3  # ms
        e_peak = (dv**2) / (2.0 * a_obj) * 1e3             # mm
        print(f"   a_lens={a_lens_g:4.1f}g (a_obj={a_obj:5.1f} m/s^2), v_z=±{v_z:.1f} m/s: 峰值离焦={e_peak:5.2f} mm ({e_peak/2.14:.2f} zR7 / {e_peak/0.54:.2f} zR14), 最小追平时间={t_opt:5.1f} ms")

# 4. 场曲前馈增量核算（直接采用第一篇表1实测数据: 0°->12° 机械角, dz_L = +0.601 mm -> dZ_fc = 1.851 mm）
print("\n=== 4. 预测转角场曲前馈增量核算 ===")
# 前扫描场镜（第一篇表1）：dZ_fc(theta) = c_fc * theta^2, theta=12 deg -> 0.601*3.08 = 1.851 mm
dZ_fc_12 = 0.601 * dz_ratio
c_fc = dZ_fc_12 / (12.0**2)
# 后扫描无场镜球面光程：dZ_post(theta) = Z0 * (1/cos(2*theta_rad) - 1)（机械角 theta -> 光学偏转角 2*theta）
print(f"前扫描 F-Theta 场镜(第一篇表1): 12°机械角场曲={dZ_fc_12:.2f} mm (c_fc={c_fc:.5f} mm/deg^2)")
tau_z_resp = 0.020  # 20 ms 典型 Z 响应期
for v_lat in [0.5, 1.0, 2.0]:  # m/s
    # 机械角速度 dtheta/dt: 光学角速度 = v_lat / f (rad/s), 机械角 = 光学角 / 2
    omega_mech_deg = math.degrees((v_lat * 1e3 / f) / 2.0)  # deg/s
    dtheta = omega_mech_deg * tau_z_resp                    # deg in 20 ms
    print(f"v_lat={v_lat:.1f} m/s (机械转速={omega_mech_deg:5.1f} deg/s, 20ms转角变化 Δθ={dtheta:.2f}°):")
    for th0 in [2.0, 5.0, 8.0, 10.0]:
        th1 = min(12.0, th0 + dtheta)
        dz_fth = c_fc * (th1**2 - th0**2)
        dz_post = 254.0 * (1.0/math.cos(math.radians(2*th1)) - 1.0/math.cos(math.radians(2*th0)))
        print(f"   θ={th0:4.1f}°->{th1:4.1f}°: 场镜ΔZ_fc={dz_fth:5.2f} mm ({dz_fth/2.14:.2f} zR7 / {dz_fth/0.54:.2f} zR14) | 后扫描无场镜ΔZ_post={dz_post:5.2f} mm")

# 5. 异步深度延迟位移 & 盲窗协方差漂移核算
print("\n=== 5. 异步深度延迟位移 v_z * tau_z 与出光盲窗漂移 ===")
for name, rate_hz, tau_ms in [("档位A(第一篇色差ROI)", 250, 5.0), ("档位A慢(200Hz/8ms)", 200, 8.0), ("档位B1(外部双目/ToF 60Hz/20ms)", 60, 20.0), ("档位B2(外部深度 30Hz/30ms)", 30, 30.0)]:
    # 总观测平均滞后 = tau_ms + 0.5 * (1000/rate_hz)
    t_eff = tau_ms + 0.5 * (1000.0 / rate_hz)
    print(f"{name}: 固定延迟={tau_ms:.0f} ms, 半周期采样滞后={0.5*1000/rate_hz:.1f} ms, 平均总滞后={t_eff:.1f} ms")
    for v_z in [0.3, 0.5, 1.0]:
        lag_mm = v_z * t_eff
        print(f"   v_z={v_z:.1f} m/s -> 未对齐Z偏差={lag_mm:5.2f} mm ({lag_mm/2.14:.2f} zR7 / {lag_mm/0.54:.2f} zR14)")

print("\n出光盲窗 q=0 期间纯外推漂移 (1/2 * a_man * T_blind^2):")
for a_man in [3.0, 8.0, 15.0]:  # m/s^2
    vals = [f"T={T}ms: {0.5*a_man*(T*1e-3)**2*1e6:5.0f} um" for T in [3, 5, 10, 15, 25]]
    print(f"   机动加速度 a={a_man:4.1f} m/s^2 -> " + " | ".join(vals))

print("\n生物组织热弛豫时间核算 tau_th = d^2 / (4*kappa), kappa=0.14 mm^2/s:")
for d_um in [60, 100, 200, 300, 500]:
    tau_th = (d_um * 1e-3)**2 / (4.0 * 0.14) * 1e3  # ms
    print(f"   特征尺度 d={d_um:3d} um -> tau_th = {tau_th:6.2f} ms")
