"""P0 static calculations and automatic checkpoint. Does not run closed-loop control."""
from pathlib import Path
import csv
import hashlib
import itertools
import json
import math
import time
import numpy as np
from scipy.integrate import quad
from scipy.optimize import brentq
from p3_physics import beam, capture, static_time, thermal_time, thermal_temperature, infinite_numeric_temperature, finite_spatial_temperature, analytic_stationary_limit

BASE = Path(__file__).resolve().parents[1]
OUT = BASE / "out_P0"
OUT.mkdir(exist_ok=True)
P = json.loads((BASE / "src/params_p3_run_v1_2.json").read_text(encoding="utf-8"))
START = time.time()


def csvout(name, rows):
    with (OUT/name).open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader(); writer.writerows(rows)


def checkpoint_failure(message):
    (OUT/"checkpoint.json").write_text(json.dumps({"stage": "P0", "status": "failed", "reason": message}, ensure_ascii=False, indent=2), encoding="utf-8")
    raise RuntimeError(message)


def main():
    assert P["execution_enabled"]
    selfchecks = []
    refs = []
    for D,dz,quoted_t,quoted_w,quoted_T in [(7,0,.04,29.5,13500),(7,10,19.7,140.9,2830),(14,10,290,276,1450)]:
        w0,zr,w = beam(D,dz)
        exact = thermal_time(w,50,.01,60)
        numerical = brentq(lambda logt: infinite_numeric_temperature(math.exp(logt),w,50,.01)-60, math.log(exact)-2, math.log(exact)+2, xtol=1e-13)
        numerical = math.exp(numerical)
        err = abs(numerical/exact-1)
        refs.append(dict(D_mm=D,defocus_mm=dz,w0_um=w0*1e6,zR_mm=zr*1e3,w_um=w*1e6,quoted_w_um=quoted_w,steady_T_K=analytic_stationary_limit(w,50,.01),quoted_steady_T_K=quoted_T,time_us=exact*1e6,quoted_approx_time_us=quoted_t,approx_quoted_relative_difference=(exact*1e6/quoted_t-1),numeric_kernel_time_us=numerical*1e6,kernel_vs_exact_relative_error=err,quoted_value_status="rounded_approximation_not_full_precision_reference"))
        selfchecks.append(dict(check=f"thermal_reference_D{D}_dz{dz}",relative_error=err,tolerance=.01,status="pass" if err<=.01 else "fail"))
    for D,dz,alpha,power,t in itertools.product([7,14],[0,10,15],[.01,.2],[20,100],[1e-8,1e-5,.01,.4]):
        w=beam(D,dz)[2]
        finite=thermal_temperature(t,w,power,alpha,.00025)
        independent=finite_spatial_temperature(t,w,power,alpha,.00025)
        err=abs(finite/independent-1)
        selfchecks.append(dict(check=f"finite_thermal_{D}_{dz}_{alpha}_{power}_{t}",relative_error=err,tolerance=.01,status="pass" if err<=.01 else "fail"))
    for w,rad in itertools.product([.00003,.00014,.000414],[.00025,.0005]):
        analytic=capture(w,rad)
        numeric=quad(lambda r: 4*r/(w*w)*math.exp(-2*r*r/(w*w)),0,rad,epsabs=1e-12)[0]
        err=abs(numeric/analytic-1)
        selfchecks.append(dict(check=f"capture_{w}_{rad}",relative_error=err,tolerance=1e-6,status="pass" if err<=1e-6 else "fail"))
    background=[]
    for D,offset in itertools.product([7,14],[50,100,150]):
        w0,zr,w=beam(D,offset)
        grid=np.linspace(-4*w,4*w,321)
        I1=np.exp(-2*grid*grid/(w*w))
        numerical_power=2*50/(math.pi*w*w)*np.trapezoid(I1,grid)**2
        err=abs(numerical_power/50-1)
        selfchecks.append(dict(check=f"background_energy_D{D}_offset{offset}",relative_error=err,tolerance=.005,status="pass" if err<=.005 else "fail"))
        background.append(dict(D_mm=D,offset_from_focus_mm=offset,w_bg_mm=w*1e3,dilution_ratio=(w/w0)**2,I_peak_unattenuated_50W_W_cm2=2*50/(math.pi*w*w)/1e4,I_peak_alpha5pct_eta1_W_cm2=2*47.5/(math.pi*w*w)/1e4))
    csvout("thermal_reference_comparison.csv",refs)
    csvout("selfchecks.csv",selfchecks)
    csvout("background_dilution.csv",background)
    failed=[r for r in selfchecks if r["status"]!="pass"]
    if failed:
        checkpoint_failure(f"P0 self-check failed: {failed[:3]}")
    print(f"P0 selfchecks {len(selfchecks)}/{len(selfchecks)} passed",flush=True)

    definitions=[]
    for E,tau in itertools.product(P["models"]["ME"]["E_th_abs_mJ"],[5,15,50,"infinity"]):
        definitions.append(("M-E",dict(E_mJ=E,tau=tau)))
    for E,tau,I in itertools.product([20,50,100,200],[5,15,50,"infinity"],[0,10,30,80]):
        definitions.append(("M-I",dict(E_mJ=E,tau=tau,I_min_kW=I)))
    for temp,hold in itertools.product([40,60],[0,1]):
        definitions.append(("M-T",dict(deltaT=temp,hold_ms=hold)))
    expected=2*3*3*2*len(definitions)*151
    manifest={"stage":"P0","expected_rows":expected,"completed_rows":0,"models":{m:sum(x[0]==m for x in definitions) for m in ["M-E","M-I","M-T"]},"defocus_points":151,"parameters_sha256":hashlib.sha256((BASE/"src/params_p3_run_v1_2.json").read_bytes()).hexdigest(),"status":"running","tool":"Python numerical simulation, not Zemax"}
    (OUT/"manifest.json").write_text(json.dumps(manifest,indent=2),encoding="utf-8")
    fields=["row_id","model","D_mm","power_W","alpha","radius_mm","E_threshold_mJ","threshold_basis","tau_ms","I_min_kW_cm2","deltaT_K","hold_ms","defocus_mm","w_um","capture_fraction","threshold_time_ms","status","energy_reference_label"]
    ratio_fields=["model","D_mm","power_W","alpha","radius_mm","E_threshold_mJ","tau_ms","I_min_kW_cm2","deltaT_K","hold_ms","relative_v_m_s","defocus_mm","time_to_crossing_ratio","below_one_fifth","status","source_row"]
    boundary=[]; counts={m:{"reachable":0,"unreachable":0} for m in ["M-E","M-I","M-T"]}; summary=[]
    with (OUT/"static_threshold_times.csv").open("w",encoding="utf-8-sig",newline="") as f, (OUT/"focus_crossing_ratios.csv").open("w",encoding="utf-8-sig",newline="") as g:
        writer=csv.DictWriter(f,fieldnames=fields); writer.writeheader()
        ratios=csv.DictWriter(g,fieldnames=ratio_fields);ratios.writeheader()
        rowid=0
        for D,power,alpha,radius in itertools.product([7,14],[20,50,100],[.01,.05,.2],[.25,.5]):
            for model,kw in definitions:
                values=[]
                for iz in range(151):
                    dz=iz/10
                    t=static_time(model,D,dz,power,alpha,radius,**kw)
                    if t is not None and (not math.isfinite(t) or t<0):
                        checkpoint_failure("Nonfinite/negative physical threshold time")
                    w0,zr,w=beam(D,dz);eta=capture(w,radius/1000)
                    rowid+=1
                    row=dict(row_id=rowid,model=model,D_mm=D,power_W=power,alpha=alpha,radius_mm=radius,E_threshold_mJ=kw.get("E_mJ",""),threshold_basis={"M-E":"absorbed_relaxation_weighted","M-I":"captured_relaxation_weighted","M-T":"centre_temperature_and_hold"}[model],tau_ms=kw.get("tau",""),I_min_kW_cm2=kw.get("I_min_kW",""),deltaT_K=kw.get("deltaT",""),hold_ms=kw.get("hold_ms",""),defocus_mm=dz,w_um=w*1e6,capture_fraction=eta,threshold_time_ms="" if t is None else t*1000,status="unreachable" if t is None else "reachable",energy_reference_label=P["models"]["MI"]["zero_I_label"] if model=="M-I" and kw["I_min_kW"]==0 else "")
                    writer.writerow(row);counts[model][row["status"]]+=1;values.append(t)
                    if D==7 and radius==.25 and dz<=10 and (model!="M-I" or kw["I_min_kW"]==0):
                        for velocity in [.3,.5,1,1.5]:
                            ratio=None if t is None else t/(2*zr/velocity)
                            rr={key:row[key] for key in ["model","D_mm","power_W","alpha","radius_mm","E_threshold_mJ","tau_ms","I_min_kW_cm2","deltaT_K","hold_ms","defocus_mm","status"]}
                            rr.update(relative_v_m_s=velocity,time_to_crossing_ratio="" if ratio is None else ratio,below_one_fifth=ratio is not None and ratio<.2,source_row=rowid+1)
                            ratios.writerow(rr)
                    if power==50 and alpha==.05 and radius==.25 and ((model=="M-E" and kw==dict(E_mJ=5,tau=15)) or (model=="M-I" and kw==dict(E_mJ=50,tau=15,I_min_kW=10)) or (model=="M-T" and kw==dict(deltaT=60,hold_ms=1))):
                        summary.append(row)
                for velocity in [.3,.5,1,1.5]:
                    target=.2*(2*beam(D)[1]/velocity)
                    good=[t is not None and t<target for t in values]
                    transitions=[i for i in range(1,151) if good[i]!=good[i-1]]
                    edges=[]
                    for i in transitions:
                        lo,hi=(i-1)/10,i/10
                        while hi-lo>.01:
                            mid=(lo+hi)/2;t=static_time(model,D,mid,power,alpha,radius,**kw)
                            if (t is not None and t<target)==good[i-1]:lo=mid
                            else:hi=mid
                        edges.append((lo,hi))
                    boundary.append(dict(model=model,D_mm=D,power_W=power,alpha=alpha,radius_mm=radius,parameters_json=json.dumps(kw,sort_keys=True),relative_v_m_s=velocity,criterion_ratio=.2,all_0_to_10_pass=all(good[:101]),all_0_to_15_pass=all(good),none_pass=not any(good),transition_brackets_mm=json.dumps(edges),finite_0_to_10=sum(t is not None for t in values[:101])))
            manifest["completed_rows"]=rowid
            (OUT/"manifest.json").write_text(json.dumps(manifest,indent=2),encoding="utf-8")
            print(f"P0 static rows {rowid}/{expected}",flush=True)
    if rowid!=expected:checkpoint_failure("P0 completion below 100%")
    csvout("defocus_boundaries.csv",boundary)
    csvout("main_point_curves.csv",summary)
    csvout("model_status_counts.csv",[dict(model=m,**v) for m,v in counts.items()])
    sensitivity=[]
    for D,offset,shift in itertools.product([7,14],[50,100,150],range(1001)):
        shift=shift/10
        wt=beam(D,shift)[2];eta=capture(wt,.00025)
        wb=beam(D,offset-shift)[2];Pbg=50*(1-.05*eta)
        sensitivity.append(dict(D_mm=D,bg_offset_mm=offset,focus_shift_behind_target_mm=shift,capture_fraction=eta,P_bg_W=Pbg,w_bg_mm=wb*1000,peak_I_W_cm2=2*Pbg/(math.pi*wb*wb)/1e4,H_fixed_peak_5ms_J_cm2=2*Pbg/(math.pi*wb*wb)/1e4*.005))
    csvout("background_focus_shift.csv",sensitivity)
    make_figures(summary,sensitivity)
    manifest.update(status="complete",completed_rows=rowid,completion_fraction=1.0,selfchecks_passed=len(selfchecks),elapsed_wall_s=time.time()-START)
    (OUT/"manifest.json").write_text(json.dumps(manifest,indent=2),encoding="utf-8")
    (OUT/"checkpoint.json").write_text(json.dumps({"stage":"P0","status":"passed","next":"trajectory_validation_then_pilot100","selfchecks_passed":len(selfchecks),"completed":rowid,"expected":expected,"completion":1.0},indent=2),encoding="utf-8")
    write_reports(refs,background,counts,manifest)
    print(json.dumps(manifest),flush=True)


def make_figures(summary,sensitivity):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    plt.rcParams.update({"font.family":"DejaVu Sans","svg.fonttype":"none","font.size":10})
    fig,axes=plt.subplots(1,3,figsize=(12,3.7))
    for ax,model in zip(axes,["M-E","M-T","M-I"]):
        for D,style in [(7,"-"),(14,"--")]:
            group=[r for r in summary if r["model"]==model and r["D_mm"]==D]
            ax.plot([r["defocus_mm"] for r in group],[r["threshold_time_ms"] if r["status"]=="reachable" else None for r in group],style,color="black",label=f"D={D} mm")
        ax.set(xlabel="Axial defocus (mm)",ylabel="Proxy threshold time (ms)",title=model);ax.legend();ax.grid(alpha=.2)
    fig.tight_layout();fig.savefig(OUT/"static_threshold_times.svg");fig.savefig(OUT/"static_threshold_times.png",dpi=300);plt.close(fig)
    fig,ax=plt.subplots(figsize=(7,4))
    for D,style in [(7,"-"),(14,"--")]:
        group=[r for r in sensitivity if r["D_mm"]==D and r["bg_offset_mm"]==100]
        ax.semilogy([r["focus_shift_behind_target_mm"] for r in group],[r["peak_I_W_cm2"] for r in group],style,color="black",label=f"D={D} mm")
    for limit,style in [(1000,":"),(3000,"-."),(10000,":")]:ax.axhline(limit,color="0.5",linestyle=style,linewidth=.7)
    ax.set(xlabel="Focus shift behind target (mm)",ylabel="Background peak irradiance (W/cm2)");ax.legend();ax.grid(alpha=.2);fig.tight_layout();fig.savefig(OUT/"background_focus_shift.svg");fig.savefig(OUT/"background_focus_shift.png",dpi=300);plt.close(fig)


def write_reports(refs,bg,counts,manifest):
    lines=["# results_for_writing — P0", "", "工具：Python数值仿真，非Zemax、非实物测量。数值是代理模型计算，不是昆虫实测致死率。", "", "| 编号 | 数值 | 95%CI | 工况与来源 |", "|---|---|---|---|"]
    for i,r in enumerate(refs,1):
        lines.append(f"| [R-P0-{i:02d}] | w={r['w_um']:.9g} μm；z_R={r['zR_mm']:.9g} mm；到60K {r['time_us']:.9g} μs | NA：确定性解析值；独立积分相对误差{r['kernel_vs_exact_relative_error']:.3g} | D{r['D_mm']}、离焦{r['defocus_mm']}mm、50W、α1%、无限面源；thermal_reference_comparison.csv第{i+1}行 |")
    for i,r in enumerate(bg,4):
        lines.append(f"| [R-P0-{i:02d}] | w_bg={r['w_bg_mm']:.9g} mm，稀释比{r['dilution_ratio']:.9g}；未衰减峰值I={r['I_peak_unattenuated_50W_W_cm2']:.9g} W/cm² | NA：确定性计算 | D{r['D_mm']}、焦后{r['offset_from_focus_mm']}mm；background_dilution.csv第{i-2}行；50W未扣吸收与5%吸收列分开 |")
    lines += ["", "## 不成立或增益消失的结果", "", "尚未比较控制器，因此无S2/S3/S4增益结果。M-E和M-I部分代理门槛因稳态弛豫上限或辐照度门槛无法达到，详见model_status_counts.csv和原始表status=unreachable；这些行没有删去，也没有填NaN/Inf。", "", "任务书约0.04μs的参考为低有效位舍入；本轮精确公式得到0.0377114μs，给值相对差约5.72%，独立积分与未舍入解析式误差远小于1%。不将舍入差说成热求解器误差。19.7和290μs同样保留原参考与计算差。", "", "全条件T_threshold/T_cross逐点表见focus_crossing_ratios.csv；条件跨界与0～10mm全范围判据见defocus_boundaries.csv。本执行方只提供每个条件的true/false，不替审核方决定机制去留。", "", "## 图说明", "", "- static_threshold_times：P50W、α5%、目标半径0.25mm，按补充指令各模型主点比较离焦与模型阈值时间。", "- background_focus_shift：固定背景在目标后100mm，焦点后移时的背景峰值I；灰线仅为工程扫描限额，没有作物实验验证。", "", "数值原表行号从含表头的第1行计；确定性值不构造Bootstrap CI。"]
    (OUT/"results_for_writing.md").write_text("\n".join(lines)+"\n",encoding="utf-8")
    log=["# P0 run_log", "", "参数来源：G0审核意见＋一次性补充指令；SHA-256见manifest。控制阶段尚未执行。", "", f"静态明细完成 {manifest['completed_rows']}/{manifest['expected_rows']}；独立热/截获/背景积分自检全部通过。", "", "M-E阈值2/5/20/50/200mJ为吸收口径扫描假设；α1/5/20%为扫描假设。背景I=1000/3000/10000W/cm²与H=5/20/50J/cm²为工程扫描值，没有作物实验验证。", "", "M-I I_min=0单列为‘与文献口径一致的截获能量参照’，仍含所列τ热弛豫，不能当作未经修正的文献LD90。", "", "M-T有限目标主计算采用圆盘截断热源；无限高斯面源仅用于给定解析公式的参考核对。数值采用独立格林积分检查，不用0.1ms控制网格代替微秒阈值计算。", "", "数学不可达用状态及空时间表示；∞仅是配置中的无弛豫标志字符串，不是数值异常。", "", "提供的0.04μs仅一位有效数字，独立数值自检以未舍入解析式为准；所有约值的差异另列，未修改输入去拟合参考值。", "", "输出齐全后自动继续轨迹和试点，不等待人工G1；无收益/不可达不触发停止。", "", "原始CSV按文件实际行顺序存储；statics无随机采样，CI不适用。图以黑白线型区分。"]
    (OUT/"run_log.md").write_text("\n".join(log)+"\n",encoding="utf-8")


if __name__=="__main__":
    main()
