from pathlib import Path
import csv
import json
import math
import numpy as np
from p3_estimator import Observer,observation_schedule,observer_series

BASE=Path(__file__).resolve().parents[1]
OUT=BASE/"implementation_checks"
OUT.mkdir(exist_ok=True)


def main():
    errors=[];checks=[]
    for seed in range(1000,1040):
        data=np.load(BASE/f"inputs_frozen/trajectories/{seed}.npz")
        pos=data["position_mm"]
        for blind in (False,True):
            means,covs,valid,info=observer_series(pos,seed,"A1",.5,blind)
            err=np.sum((means[valid,:3]-pos[::10][valid])**2,axis=1)
            noise=(pos[::10][valid,2]*.0005)**2*2+.5**2
            errors.append(dict(seed=seed,layer=str(data["layer"]),blind=blind,RMSE_mm=float(np.sqrt(err.mean())),mean_square_mm2=float(err.mean()),noise_position_RMS_mm=float(np.sqrt(noise.mean())),noise_mean_square_mm2=float(noise.mean()),initialized_samples=int(valid.sum()),total_samples=len(valid),all_finite=bool(np.isfinite(means).all() and np.isfinite(covs).all()),discarded=info["discarded"]))
            if seed==1000:
                repeated=observer_series(pos,seed,"A1",.5,blind)
                checks.append(dict(check=f"reproducibility_blind_{blind}",passed=bool(np.array_equal(means,repeated[0]) and np.array_equal(covs,repeated[1])),value=0.))
        if (seed-999)%10==0:print(f"Estimator checks {seed-999}/40 training trajectories",flush=True)
    data=np.load(BASE/"inputs_frozen/trajectories/1000.npz")
    schedule=observation_schedule(data["position_mm"],1000,"B2",.5)
    arrived=[o for o in schedule if o[0]<=4000]
    delayed=Observer(True);ordered=Observer(True)
    for arrival,stamp,kind,v,R in arrived:delayed.add((stamp*100,kind,v,R),arrival*100)
    for arrival,stamp,kind,v,R in sorted(arrived,key=lambda x:(x[1],x[2])):ordered.add((stamp*100,kind,v,R),stamp*100)
    a=delayed.at(400000);b=ordered.at(400000)
    diff=max(float(np.max(np.abs(a[0]-b[0]))),float(np.max(np.abs(a[1]-b[1]))))
    checks.append(dict(check="delayed_replay_equals_chronological_assimilation",passed=diff<1e-6,value=diff))
    for blind in (False,True):
        selected=[r for r in errors if r["blind"]==blind]
        # Equal weights for the three prespecified strata; no startup-before-first-data is treated as an estimate.
        mse=np.mean([np.mean([r["mean_square_mm2"] for r in selected if r["layer"]==layer]) for layer in ["Center","Edge","Z-Maneuver"]])
        noise=np.mean([np.mean([r["noise_mean_square_mm2"] for r in selected if r["layer"]==layer]) for layer in ["Center","Edge","Z-Maneuver"]])
        ratio=float(math.sqrt(mse/noise))
        checks.append(dict(check=f"main_B1_RMSE_noise_ratio_blind_{blind}",passed=ratio<=5,value=ratio))
    checks.append(dict(check="all_states_and_covariances_finite",passed=all(r["all_finite"] for r in errors),value=0.))
    for name,rows in [("estimator_trajectory_metrics.csv",errors),("estimator_selfchecks.csv",checks)]:
        with (OUT/name).open("w",encoding="utf-8-sig",newline="") as f:
            w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    failed=[r for r in checks if not r["passed"]]
    status={"stage":"estimator_selfchecks","status":"failed" if failed else "passed","checks":checks,"failed":failed,"startup_policy":"not_initialized_samples_excluded_from_RMSE_and_counted_separately"}
    (OUT/"estimator_checkpoint.json").write_text(json.dumps(status,indent=2),encoding="utf-8")
    print(json.dumps(status),flush=True)
    if failed:raise RuntimeError("AUTOMATIC STOP: estimator checkpoint failed")


if __name__=="__main__":main()
