"""G0 harmonic-OU trajectory generation and acceptance checks, independent of controllers."""
from pathlib import Path
import csv
import json
import math
import numpy as np
from scipy.linalg import expm
from numba import njit

BASE=Path(__file__).resolve().parents[1]
CFG=json.loads((BASE/"src/params_p3_run_v1_2.json").read_text(encoding="utf-8"))
OUT=BASE/"inputs_frozen"
DT=1e-4
N=4000


def matrices(sigma_p, sigma_v):
    omega=sigma_v/sigma_p
    A=np.array([[0.,1.],[-omega*omega,-1/.15]])
    F=expm(A*DT)
    stationary=np.diag([sigma_p*sigma_p,sigma_v*sigma_v])
    Q=stationary-F@stationary@F.T
    Q=(Q+Q.T)/2
    L=np.linalg.cholesky(Q)
    G=np.linalg.solve(A,(F-np.eye(2))@np.array([0.,1.]))
    return F,L,G


@njit(cache=True)
def integrate(F,L,G,noise,start,event_starts,event_ends,event_acc,opposing_z):
    count=noise.shape[0]
    state=np.empty((count+1,3,2));state[0]=start
    acc=event_acc.copy()
    for k in range(count):
        force=np.zeros(3)
        for j in range(len(event_starts)):
            if k==event_starts[j] and opposing_z[j]:
                acc[j,0]=0.;acc[j,1]=0.;acc[j,2]=-abs(acc[j,2]) if state[k,2,1]>=0 else abs(acc[j,2])
            if event_starts[j]<=k<event_ends[j]:
                force+=acc[j]
        for axis in range(3):
            for row in range(2):
                state[k+1,axis,row]=F[axis,row,0]*state[k,axis,0]+F[axis,row,1]*state[k,axis,1]+G[axis,row]*force[axis]+L[axis,row,0]*noise[k,axis,0]+L[axis,row,1]*noise[k,axis,1]
    return state


def layer_parameters(layer):
    q=CFG["trajectory"]["layers"][layer]
    sp=np.array([q["xy_sigma_mm"],q["xy_sigma_mm"],q["Z_sigma_mm"]])/1000
    sv=np.array([q["xy_sigma_v_m_s"],q["xy_sigma_v_m_s"],q["Z_sigma_v_m_s"]])
    entries=[matrices(x,v) for x,v in zip(sp,sv)]
    return q,sp,sv,np.array([e[0] for e in entries]),np.array([e[1] for e in entries]),np.array([e[2] for e in entries])


def one_path(seed, attempt, layer, manoeuvres=True):
    rng=np.random.default_rng(np.random.SeedSequence([seed,attempt,20261126]))
    q,sp,sv,F,L,G=layer_parameters(layer)
    start=np.stack([rng.normal(size=3)*sp,rng.normal(size=3)*sv],axis=1)
    centre=np.zeros(3)
    centre[2]=rng.uniform(*q["Z_centre_mm"])/1000
    if layer!="Edge":
        radius=math.sqrt(rng.random())*.01;angle=rng.uniform(0,2*math.pi)
        centre[:2]=radius*np.array([math.cos(angle),math.sin(angle)])
    starts=[];ends=[];accelerations=[]
    t=rng.exponential(.25)
    while manoeuvres and t<.4:
        starts.append(int(round(t/DT)));ends.append(int(round((t+rng.uniform(.03,.08))/DT)))
        vector=rng.normal(size=3);vector/=np.linalg.norm(vector)
        accelerations.append(vector*rng.uniform(4,15));t+=rng.exponential(.25)
    starts=np.asarray(starts,dtype=np.int64);ends=np.asarray(ends,dtype=np.int64)
    accelerations=np.asarray(accelerations,dtype=float).reshape((-1,3))
    opposing=np.zeros(len(starts),dtype=np.bool_)
    if layer=="Z-Maneuver" and len(starts):
        chosen=rng.choice(len(starts),math.ceil(.4*len(starts)),replace=False)
        opposing[chosen]=True
        accelerations[chosen,2]=np.linalg.norm(accelerations[chosen],axis=1)
    state=integrate(F,L,G,rng.normal(size=(N,3,2)),start,starts,ends,accelerations,opposing)
    position=state[:,:,0]+centre;velocity=state[:,:,1].copy()
    if layer=="Edge":
        times=np.arange(N+1)*DT
        R0=rng.uniform(78,85)/1000;Ar=rng.uniform(10,17)/1000;freq=rng.uniform(3,6)
        phase=rng.uniform(0,2*math.pi);vt=rng.uniform(.8,1.3)*rng.choice([-1,1])
        R=R0+Ar*np.sin(2*math.pi*freq*times+phase)
        Rdot=Ar*2*math.pi*freq*np.cos(2*math.pi*freq*times+phase)
        azimuth=rng.uniform(0,2*math.pi)+np.concatenate(([0.],np.cumsum(vt/((R[:-1]+R[1:])/2)*DT)))
        radial=np.stack((np.cos(azimuth),np.sin(azimuth)),axis=1)
        tangent=np.stack((-np.sin(azimuth),np.cos(azimuth)),axis=1)
        position[:,:2]+=R[:,None]*radial
        velocity[:,:2]+=Rdot[:,None]*radial+vt*tangent
    return position,velocity,len(starts),int(opposing.sum())


def evaluate(position, velocity, layer):
    theta=np.rad2deg(.5*np.arctan2(np.linalg.norm(position[:,:2],axis=1),position[:,2]))
    z=position[:,2]*1000
    band=(theta>=6.5)&(theta<=11)
    speed=np.linalg.norm(velocity[:,:2],axis=1)
    current=0;reversals=0
    for v in velocity[:,2]:
        sign=1 if v>=.4 else (-1 if v<=-.4 else 0)
        if sign:
            if current and sign!=current:reversals+=1
            current=sign
    row=dict(min_Z_mm=float(z.min()),max_Z_mm=float(z.max()),max_angle_deg=float(theta.max()),edge_time_fraction=float(band.mean()),edge_median_lateral_speed_m_s=float(np.median(speed[band])) if band.any() else 0.,axial_reversals=reversals)
    ok=row["min_Z_mm"]>=220 and row["max_Z_mm"]<=288 and row["max_angle_deg"]<=11.5
    if layer=="Center":ok=ok and row["max_angle_deg"]<=4.5
    if layer=="Edge":ok=ok and row["edge_time_fraction"]>=.7 and row["edge_median_lateral_speed_m_s"]>=.8
    if layer=="Z-Maneuver":ok=ok and reversals>=2
    return bool(ok),row


def write_csv(path, rows):
    with path.open("w",encoding="utf-8-sig",newline="") as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)


def stationary_check():
    rows=[]
    # Each homogeneous component is checked with 1000 independent stationary paths.
    for test_id,(sp,sv) in enumerate([(.01,.35),(.003,.1),(.014,.7)]):
        F,L,G=matrices(sp,sv);F=np.repeat(F[None],3,axis=0);L=np.repeat(L[None],3,axis=0);G=np.repeat(G[None],3,axis=0)
        sums=np.zeros((3,2));squares=np.zeros((3,2));count=0
        for seed in range(1000):
            rng=np.random.default_rng(np.random.SeedSequence([20261127,test_id,seed]))
            start=rng.normal(size=(3,2))*np.array([sp,sv])
            states=integrate(F,L,G,rng.normal(size=(N,3,2)),start,np.empty(0,np.int64),np.empty(0,np.int64),np.empty((0,3)),np.empty(0,np.bool_))
            sums+=states.sum(axis=0);squares+=(states*states).sum(axis=0);count+=N+1
        std=np.sqrt(squares/count-(sums/count)**2)
        for axis in range(3):
            for component,idx,target in [("position",0,sp),("velocity",1,sv)]:
                error=float(std[axis,idx]/target-1)
                rows.append(dict(component_family=test_id,axis=axis,component=component,target_SI=target,measured_std_SI=float(std[axis,idx]),relative_error=error,trajectories=1000,status="pass" if abs(error)<=.05 else "fail"))
        print(f"Stationary family {test_id}: max relative sigma error {np.max(np.abs(std/np.array([sp,sv])-1)):.5f}",flush=True)
    write_csv(OUT/"trajectory_stationary_check.csv",rows)
    return all(r["status"]=="pass" for r in rows)


def main():
    OUT.mkdir(exist_ok=True); (OUT/"trajectories").mkdir(exist_ok=True)
    if not stationary_check():
        (OUT/"checkpoint.json").write_text(json.dumps({"status":"failed","stop_condition":"trajectory_stationary_statistics_outside_5_percent"}),encoding="utf-8")
        raise RuntimeError("STOP: trajectory stationary check failed")
    records=[];failed=0
    for split,start,end in [("train",1000,1040),("test",2000,2120)]:
        for seed in range(start,end):
            i=seed-start
            layer=(["Center"]*14+["Edge"]*13+["Z-Maneuver"]*13)[i] if split=="train" else ["Center","Edge","Z-Maneuver"][i//40]
            accepted=False
            for attempt in range(500):
                pos,vel,n_events,n_axial=one_path(seed,attempt,layer)
                ok,stats=evaluate(pos,vel,layer)
                if ok:
                    accepted=True
                    path=OUT/"trajectories"/f"{seed}.npz"
                    # Trial-independent readback offsets, never generated by a method RNG.
                    rng=np.random.default_rng(np.random.SeedSequence([seed,902]))
                    np.savez_compressed(path,position_mm=pos*1000,velocity_mm_s=vel*1000,dt_s=DT,seed=seed,layer=layer,calibration_residual_mm=rng.uniform(-.1,.1),power_gain_error=rng.uniform(-.03,.03),max_target_depth_mm=stats["max_Z_mm"])
                    break
            failed+=not accepted
            records.append(dict(seed=seed,split=split,layer=layer,accepted=accepted,attempts=attempt+1,maneuver_count=n_events,forced_axial_maneuvers=n_axial,**stats))
            if len(records)%10==0:print(f"Trajectories {len(records)}/160; failed={failed}; latest attempts={attempt+1}",flush=True)
    write_csv(OUT/"trajectory_manifest.csv",records)
    status="passed" if failed==0 else ("failed" if failed/160>.05 else "incomplete")
    report={"status":status,"completed":160-failed,"expected":160,"failed_seed_fraction":failed/160,"rule":"failed_fraction>5% stops; any unresolved incomplete also prevents batch"}
    (OUT/"checkpoint.json").write_text(json.dumps(report,indent=2),encoding="utf-8")
    if failed:
        raise RuntimeError(f"STOP: {failed}/160 trajectories unavailable; no seeds replaced")
    print(json.dumps(report),flush=True)


if __name__=="__main__":main()
