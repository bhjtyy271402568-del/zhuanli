"""SI optical/thermal helpers. Mathematical non-attainment is None, never Inf."""
import math
import numpy as np
from scipy.integrate import quad
from scipy.optimize import brentq
from scipy.special import erf
from scipy.stats import ncx2

LAMBDA = 1.064e-6
M2 = 1.2
FOCAL = 0.254
K = 0.5
KAPPA = 0.14e-6


def beam(D_mm, dz_mm=0.0):
    waist = M2 * LAMBDA * FOCAL / (math.pi * D_mm / 2000)
    zr = math.pi * waist**2 / (M2 * LAMBDA)
    return waist, zr, waist * math.sqrt(1 + (dz_mm / 1000 / zr)**2)


def capture(w, radius, offset=0.0):
    if offset == 0:
        return -math.expm1(-2 * radius**2 / w**2)
    return float(ncx2.cdf(4 * radius**2 / w**2, 2, 4 * offset**2 / w**2))


def thermal_temperature(t, w, power, alpha, radius=None):
    if t <= 0 or power == 0:
        return 0.0
    angle = math.atan(math.sqrt(8 * KAPPA * t) / w)
    scale = alpha * power * math.sqrt(2) / (math.pi**1.5 * K * w)
    if radius is None:
        return scale * angle
    cutoff = 2 * radius**2 / w**2
    def integrand(phi):
        return 1.0 if phi == 0 else -math.expm1(-cutoff / math.sin(phi)**2)
    return scale * quad(integrand, 0, angle, epsabs=1e-12, epsrel=1e-11)[0]


def thermal_time(w, power, alpha, deltaT, radius=None):
    scale = alpha * power * math.sqrt(2) / (math.pi**1.5 * K * w)
    target = deltaT / scale
    if radius is None:
        angle = target
        if angle >= math.pi / 2:
            return None
    else:
        cutoff = 2 * radius**2 / w**2
        def integral(phi):
            return quad(lambda q: 1.0 if q == 0 else -math.expm1(-cutoff / math.sin(q)**2), 0, phi, epsabs=1e-12, epsrel=1e-11)[0]
        if target >= integral(math.pi/2):
            return None
        angle = brentq(lambda a: integral(a)-target, 0, math.pi/2, xtol=2e-14)
    return w**2 * math.tan(angle)**2 / (8 * KAPPA)


def energy_time(input_power, threshold_J, tau_ms):
    if input_power <= 0:
        return None
    if tau_ms == "infinity":
        return threshold_J / input_power
    tau = float(tau_ms) / 1000
    ratio = threshold_J / (input_power * tau)
    return None if ratio >= 1 else -tau * math.log1p(-ratio)


def static_time(model, D, dz, power, alpha, radius_mm, E_mJ=None, tau="infinity", I_min_kW=None, deltaT=None, hold_ms=None):
    _, _, w = beam(D, dz)
    eta = capture(w, radius_mm/1000)
    if model == "M-E":
        return energy_time(alpha*power*eta, E_mJ/1000, tau)
    if model == "M-I":
        local = power*eta / min(math.pi*(radius_mm/1000)**2, math.pi*w*w) / 1e7
        return energy_time(power*eta if local >= I_min_kW else 0, E_mJ/1000, tau)
    t = thermal_time(w, power, alpha, deltaT, radius_mm/1000)
    return None if t is None else t + hold_ms/1000


def infinite_numeric_temperature(t, w, power, alpha):
    # Independent heat-kernel integral; u=sqrt(lag), then scaled to [0,1].
    integral = quad(lambda v: 1/(w*w+8*KAPPA*t*v*v), 0, 1, epsabs=0, epsrel=1e-11)[0]
    return 4*alpha*power*math.sqrt(KAPPA*t)/(math.pi**1.5*K)*integral


def finite_spatial_temperature(t, w, power, alpha, radius):
    # Independent spatial Green integral; erfc at the observation centre.
    from scipy.special import erfc
    scale = min(w, 2*math.sqrt(KAPPA*t))
    upper = min(radius/scale, 14)
    val = quad(lambda u: math.exp(-2*(scale*u/w)**2)*erfc(scale*u/(2*math.sqrt(KAPPA*t))), 0, upper, epsabs=1e-12, epsrel=1e-10)[0]
    return 2*alpha*power/(math.pi*w*w*K)*scale*val


def analytic_stationary_limit(w, power, alpha, radius=None):
    val = alpha*power/(math.sqrt(2*math.pi)*K*w)
    return val if radius is None else val*erf(math.sqrt(2)*radius/w)
