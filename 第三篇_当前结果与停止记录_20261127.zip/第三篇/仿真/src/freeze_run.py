"""Freeze the user-approved G0 review and one-pass supplement before any tests."""
from pathlib import Path
import hashlib
import json

BASE = Path(__file__).resolve().parents[1]
source = Path(r"C:\Users\Administrator\Desktop\Hubstudio\新建环境1")
references = BASE / "参考输入"
names = ["第三篇_G0审核意见.md", "第三篇_一次性运行补充指令.md"]
for name in names:
    (references / name).write_bytes((source / name).read_bytes())
p = json.loads((BASE / "src/params_p3_spec_v1_1.json").read_text(encoding="utf-8"))
p.update(version="1.2-one-pass-frozen", execution_enabled=True, date="2026-11-26")
p["gate_status"] = {"G0": "conditionally_approved_P0", "P0": "automatic_checkpoint", "A": "automatic_checkpoint", "B": "automatic_checkpoint", "C": "automatic_checkpoint"}
p["authority"] = {"precedence": ["user_run_all", names[1], names[0], "spec_v1.1"], "files": [{"name": n, "sha256": hashlib.sha256((references / n).read_bytes()).hexdigest()} for n in names]}
p["actuators"].update(encoder_noise_model={"xy_bits": 20, "xy_span_deg": 24, "z_quantization_mm": 0.0005, "additive_noise": False}, power_feedback_error_model={"distribution": "fixed_uniform_gain_per_trajectory", "bounds": [-0.03, 0.03], "additive_noise": False})
p["actuators"]["calibration_residual"]["status"] = "G0_approved"
p["sensors"]["proposed_depth_availability"]["status"] = "G0_approved"
p["trajectory"].update(family="harmonic_position_restoring_OU_plus_Poisson", v_rms_axis_definition="per_axis_stationary_sigma_v", ou_correlation_time_s=0.15, initial_state_distribution="stationary_gaussian_per_axis_about_sampled_centre", boundary_conditioning_algorithm="reject_whole_path_maximum_500_attempts_per_seed", strata_assignment_status="G0_approved")
p["trajectory"].pop("v_rms_m_s")
p["trajectory"]["layers"] = {
    "Center": {"centre_xy_radius_mm": 10, "xy_sigma_mm": 10, "xy_sigma_v_m_s": 0.35, "Z_centre_mm": [240, 268], "Z_sigma_mm": 10, "Z_sigma_v_m_s": 0.35},
    "Edge": {"radial_centre_mm": [78, 85], "radial_amplitude_mm": [10, 17], "radial_frequency_Hz": [3, 6], "tangent_speed_m_s": [0.8, 1.3], "xy_sigma_mm": 3, "xy_sigma_v_m_s": 0.1, "Z_centre_mm": [240, 268], "Z_sigma_mm": 10, "Z_sigma_v_m_s": 0.35},
    "Z-Maneuver": {"centre_xy_radius_mm": 10, "xy_sigma_mm": 10, "xy_sigma_v_m_s": 0.35, "Z_centre_mm": [245, 263], "Z_sigma_mm": 14, "Z_sigma_v_m_s": 0.7}}
p["trajectory"].update(axial_reversal_definition="opposite_signed_velocity_excursions_reach_plus_and_minus_0.4_m_s", edge_azimuth_evolution="signed_tangent_speed_divided_by_instantaneous_unperturbed_radius", stationary_check_seed=20261127, stationary_check_trajectories=1000)
p["estimator"].update(IMM_models=[{"name": "CV_9D_acceleration_reset_zero", "sigma_acceleration_m_s2": 2}, {"name": "Singer_9D", "tau_m_s": 0.05, "sigma_m_m_s2": 15}], transition_matrix={"continuous_rates_per_s": {"CV_to_Singer": 10, "Singer_to_CV": 25}, "rule": "expm_rate_matrix_times_actual_dt"}, process_noise="specified_by_each_model_exact_discretization", initial_covariance={"sigma_p_mm": [1, 1, 5], "sigma_v_m_s": [1, 1, 1], "sigma_a_m_s2": [10, 10, 10]}, initial_mode_probability=[0.9, 0.1], OOSM_buffer_ms=150)
p["models"]["ME"]["E_th_abs_mJ"] = [2, 5, 20, 50, 200]
p["models"]["MI"]["zero_I_label"] = "与文献口径一致的截获能量参照（含热弛豫；不是文献实测值）"
p["background"].update(irradiance_thresholds_W_cm2=[1000, 3000, 10000], fluence_thresholds_J_cm2=[5, 20, 50], main_irradiance_threshold_W_cm2=3000, main_fluence_threshold_J_cm2=20, threshold_gate="frozen_before_tests_by_supplement", threshold_status="engineering_scan_values_NOT_validated_crop_safety")
p["control"].update(interception_window_rule="first_reachable_reference_plus_minus_zR_then_K_steps_else_last_K_steps", normalized_search_ranges={"B1_k_lead": [0.5, 1.5], "B1_lowpass_Hz_log": [10, 100], "lambda_u_log": [0.0001, 0.1], "window_weight_ratio_log": [1, 100], "K_dwell_integer": [2, 10], "beta_v": [0, 10], "r_gate_over_rt": [0.2, 1], "z_gate_over_zR": [0.5, 3], "T_fix_ms_log": [2, 20], "p0": [0.3, 0.95], "p1": [0.8, 0.99]}, S3_candidate_window_ms=5, S3_evaluation_period_ms=2, S4_abort_rule={"with_observation_remaining_success_probability": "less_than_0.5_p0_except_B3b", "feedback_background_I_exceeds_limit": True, "maximum_pulse_ms": 20})
p["tuning"].update(optimizer_status="G0_approved", optimizer_seed=20261126, tie_utility_tolerance=0.0001, tie_rule="smallest_normalized_distance_to_baseline_point", stage_C_train_trajectories=54)
p["A"]["corner"]["inheritance_status"] = "G0_approved"
p["B"].update(main_E_th_abs_mJ=5, main_E_th_legacy_mJ=50, main_tau_ms=15, main_I_min_kW_cm2=10, main_delta_T_K=60, main_hold_ms=1, main_parameters_gate="frozen_by_supplement_before_P0", alpha_assumed_multipliers=[0.5, 1, 2], threshold_policy_manifest={"include_frozen_trained_policy": True, "S3_p0": [0.3, 0.5, 0.7, 0.9], "S3_p1": [0.9, 0.95, 0.99], "binary_r_gate_over_rt": [0.3, 0.6, 1], "binary_pulse_ms": [3, 8, 15], "binary_z_gate": "frozen_train_value", "closed_loop_each_policy": True})
p["C"].update(surface_wavelength_mm=[30, 60, 120], step_width_mm=[1, 5], step_position_and_phase_distribution="x_s_uniform_within_400ms_travel_phi_uniform_0_2pi", train_seed_range_inclusive=[3000, 3053], test_seed_range_inclusive=[4000, 4107], train_per_shape=1, test_per_shape=2)
p["statistics"].update(multiple_comparison_rule={"primary_tests": "3_B2_terms_x_3_strata_at_D7_main_against_B1_MPC", "metric": "in_Rayleigh_dwell_fraction", "method": "Holm", "family_alpha": 0.05}, bootstrap_status="G0_approved")
p["one_pass"] = {"stage_order": ["P0", "pilot100", "A_preview", "A_remaining", "B", "C"], "manual_wait_between_passed_stages": False, "max_estimated_runtime_hours": 72, "max_MPC_failure_fraction": 0.01, "max_unaccepted_seed_fraction": 0.05, "stationary_statistics_relative_tolerance": 0.05, "estimator_RMSE_noise_ratio_max": 5, "completion_fraction": 1, "max_failed_run_retries": 1, "mathematical_unreachable": "explicit_status_null_time_not_numeric_infinity", "approximate_reference_rounding": "display_quoted_value_and_relative_difference;_numeric_selfcheck_against_full_precision_analytic_formula"}
def nulls(x, key=""):
    if isinstance(x, dict):
        return [z for k,v in x.items() for z in nulls(v, key+"."+k)]
    if isinstance(x, list):
        return [z for i,v in enumerate(x) for z in nulls(v,key+f"[{i}]")]
    return [key] if x is None else []
assert not nulls(p), nulls(p)
destination = BASE / "src/params_p3_run_v1_2.json"
serialized = (json.dumps(p, ensure_ascii=False, indent=2)+"\n").encode("utf-8")
if destination.exists() and destination.read_bytes() != serialized:
    raise RuntimeError("Frozen config exists with different content; create a reviewed revision, do not overwrite")
destination.write_bytes(serialized)
print(json.dumps({"frozen": str(destination), "sha256": hashlib.sha256(serialized).hexdigest(), "null_fields": 0, "manual_stage_gates": False}, ensure_ascii=False))
