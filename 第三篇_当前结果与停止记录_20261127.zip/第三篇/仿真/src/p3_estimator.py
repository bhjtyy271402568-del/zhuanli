"""Shared 9-state CV/Singer IMM with delayed-observation replay. Units: mm, seconds, radians."""
from bisect import bisect_left
from functools import lru_cache
import math
import numpy as np
from scipy.linalg import expm
from numba import njit


@lru_cache(maxsize=512)
def dynamics(dt_us):
    dt=dt_us*1e-6
    F=np.zeros((2,9,9));Q=np.zeros((2,9,9))
    fcv=np.array([[1.,dt,0.],[0.,1.,0.],[0.,0.,0.]])
    qcv=2000.**2*np.array([[dt**4/4,dt**3/2,0.],[dt**3/2,dt**2,0.],[0.,0.,0.]])
    a=np.array([[0.,1.,0.],[0.,0.,1.],[0.,0.,-20.]])
    noise=np.zeros((3,3));noise[2,2]=2*15000.**2/.05
    van=np.zeros((6,6));van[:3,:3]=a;van[:3,3:]=noise;van[3:,3:]=-a.T
    ev=expm(van*dt);fs=ev[:3,:3];qs=ev[:3,3:]@fs.T;qs=(qs+qs.T)/2
    for axis in range(3):
        ids=np.array([axis,axis+3,axis+6])
        for i in range(3):
            for j in range(3):
                F[0,ids[i],ids[j]]=fcv[i,j];Q[0,ids[i],ids[j]]=qcv[i,j]
                F[1,ids[i],ids[j]]=fs[i,j];Q[1,ids[i],ids[j]]=qs[i,j]
    decay=math.exp(-35*dt)
    transition=np.array([[25/35+10/35*decay,10/35*(1-decay)],[25/35*(1-decay),10/35+25/35*decay]])
    return F,Q,transition


@njit(cache=True)
def propagate(means,covs,weights,F,Q,transition):
    prior=weights@transition
    mixed_m=np.zeros_like(means);mixed_c=np.zeros_like(covs)
    for j in range(2):
        for i in range(2):mixed_m[j]+=weights[i]*transition[i,j]/prior[j]*means[i]
        for i in range(2):
            d=means[i]-mixed_m[j]
            mixed_c[j]+=weights[i]*transition[i,j]/prior[j]*(covs[i]+np.outer(d,d))
        mixed_m[j]=F[j]@mixed_m[j]
        mixed_c[j]=F[j]@mixed_c[j]@F[j].T+Q[j]
        mixed_c[j]=(mixed_c[j]+mixed_c[j].T)/2
    return mixed_m,mixed_c,prior


@njit(cache=True)
def update(means,covs,weights,kind,value,R):
    dim=len(value)
    new_m=means.copy();new_c=covs.copy();logweight=np.empty(2)
    for j in range(2):
        H=np.zeros((dim,9));prediction=np.empty(dim)
        x,y,z=means[j,0],means[j,1],means[j,2]
        if kind==0:
            prediction[0]=math.atan2(x,z);prediction[1]=math.atan2(y,z)
            H[0,0]=z/(x*x+z*z);H[0,2]=-x/(x*x+z*z)
            H[1,1]=z/(y*y+z*z);H[1,2]=-y/(y*y+z*z)
        else:
            prediction[0]=z;H[0,2]=1.
        residual=value-prediction
        S=H@covs[j]@H.T+R
        inverse=np.linalg.inv(S)
        gain=covs[j]@H.T@inverse
        new_m[j]+=gain@residual
        left=np.eye(9)-gain@H
        new_c[j]=left@covs[j]@left.T+gain@R@gain.T
        new_c[j]=(new_c[j]+new_c[j].T)/2
        determinant=np.linalg.det(S)
        logweight[j]=math.log(max(weights[j],1e-300))-.5*(dim*math.log(2*math.pi)+math.log(determinant)+residual@inverse@residual)
    normalizer=np.max(logweight)
    new_w=np.exp(logweight-normalizer);new_w/=new_w.sum()
    return new_m,new_c,new_w


@njit(cache=True)
def collapse(means,covs,weights):
    m=weights@means;c=np.zeros((9,9))
    for j in range(2):
        d=means[j]-m;c+=weights[j]*(covs[j]+np.outer(d,d))
    return m,c


def predict_bank(bank,dt_us):
    return bank if dt_us<=0 else propagate(*bank,*dynamics(int(dt_us)))


class Observer:
    def __init__(self,replay=True):
        self.replay=replay;self.initialized=False;self.discarded=0;self.replay_updates=0
        self.base_time=0;self.observations=[];self.snapshots=[]
        means=np.zeros((2,9));means[:,2]=254
        covariance=np.diag(np.array([1,1,5,1000,1000,1000,10000,10000,10000],dtype=float)**2)
        self.base=(means,np.repeat(covariance[None],2,axis=0),np.array([.9,.1]))
        self.last_time=0;self.bank=self.base

    def add(self,observation,arrival_us):
        stamp,kind,value,R=observation
        stamp=int(stamp) if self.replay else int(arrival_us)
        if not self.initialized:
            means=self.base[0].copy()
            if kind==0:
                means[:,0]=254*math.tan(value[0]);means[:,1]=254*math.tan(value[1])
            else:means[:,2]=value[0]
            self.base=(means,self.base[1],self.base[2]);self.initialized=True
        if not self.replay:
            self.bank=predict_bank(self.bank,stamp-self.last_time)
            # Incorporate the initialization mean into the first prior.
            if not self.observations:self.bank=self.base
            self.bank=update(*self.bank,kind,value,R);self.last_time=stamp
            self.observations=[(stamp,kind,value,R)]
            return
        if stamp<arrival_us-150000 or stamp<self.base_time:
            self.discarded+=1;return
        keys=[(o[0],o[1]) for o in self.observations]
        index=bisect_left(keys,(stamp,kind))
        self.observations.insert(index,(stamp,kind,value,R))
        self.snapshots=self.snapshots[:index]
        bank=self.base if index==0 else self.snapshots[index-1]
        previous=self.base_time if index==0 else self.observations[index-1][0]
        for entry in self.observations[index:]:
            when,typ,val,noise=entry
            bank=predict_bank(bank,when-previous);bank=update(*bank,typ,val,noise)
            self.snapshots.append(bank);previous=when;self.replay_updates+=1
        self.bank=bank;self.last_time=previous
        remove=0
        while remove<len(self.observations) and self.observations[remove][0]<arrival_us-150000:remove+=1
        if remove:
            self.base=self.snapshots[remove-1];self.base_time=self.observations[remove-1][0]
            self.observations=self.observations[remove:];self.snapshots=self.snapshots[remove:]

    def at(self,time_us):
        bank=predict_bank(self.bank,int(time_us)-self.last_time)
        return collapse(*bank)


def observation_schedule(position_mm,seed,depth_tier,los_sigma_mrad):
    tiers={"A1":(250,5,.5),"A2":(200,8,.8),"B1":(60,20,1.5),"B2":(30,30,2.5)}
    rng=np.random.default_rng(np.random.SeedSequence([seed,911]))
    los_noise=rng.normal(size=(4001,2));z_noise=rng.normal(size=4001)
    out=[]
    sigma=los_sigma_mrad*.001
    for tick in range(0,4001,20):
        p=position_mm[tick];value=np.arctan2(p[:2],p[2])+sigma*los_noise[tick]
        out.append((tick+20,tick,0,value,np.eye(2)*sigma*sigma))
    rate,delay,noise=tiers[depth_tier]
    for instant in np.arange(0,.40000001,1/rate):
        tick=int(round(instant/1e-4))
        value=np.array([position_mm[tick,2]+noise*z_noise[tick]])
        out.append((tick+round(delay*10),tick,1,value,np.array([[noise*noise]])))
    return sorted(out,key=lambda o:(o[0],o[1],o[2]))


def observer_series(position_mm,seed,depth_tier,los_sigma_mrad,blind,replay=True):
    schedule=observation_schedule(position_mm,seed,depth_tier,los_sigma_mrad)
    filter=Observer(replay);idx=0;states=[];covariances=[];valid=[]
    for tick in range(0,4001,10):
        while idx<len(schedule) and schedule[idx][0]<=tick:
            arrival,stamp,kind,value,R=schedule[idx];idx+=1
            blinded=blind and stamp%1000<70 and (kind==0 or depth_tier in ("A1","A2"))
            if not blinded:filter.add((stamp*100,kind,value,R),arrival*100)
        m,c=filter.at(tick*100);states.append(m);covariances.append(c);valid.append(filter.initialized)
    return np.asarray(states),np.asarray(covariances),np.asarray(valid),dict(discarded=filter.discarded,replay_updates=filter.replay_updates)
