"""Shared actuator plant and constrained Z MPC. OSQP is isolated in .venv_run."""
from functools import lru_cache
import json
import math
import numpy as np
from scipy.linalg import expm
from scipy import sparse
import osqp
from numba import njit


@njit(cache=True)
def plant_step(x,u,wn,amax,vmax,pmax,dt):
    # RK4 on the acceleration-limited second-order plant; hard stops project the final state.
    k=np.empty((4,2))
    for stage in range(4):
        state=x.copy()
        if stage==1:state=x+.5*dt*k[0]
        elif stage==2:state=x+.5*dt*k[1]
        elif stage==3:state=x+dt*k[2]
        state[1]=min(vmax,max(-vmax,state[1]))
        acceleration=min(amax,max(-amax,wn*wn*(u-state[0])-1.4*wn*state[1]))
        if state[1]>=vmax and acceleration>0:acceleration=0.
        if state[1]<=-vmax and acceleration<0:acceleration=0.
        k[stage,0]=state[1];k[stage,1]=acceleration
    result=x+dt*(k[0]+2*k[1]+2*k[2]+k[3])/6
    vn=min(vmax,max(-vmax,result[1]));pn=result[0]
    if pn>pmax:pn=pmax;vn=min(vn,0.)
    if pn<-pmax:pn=-pmax;vn=max(vn,0.)
    return np.array([pn,vn])


@njit(cache=True)
def advance_z(x,u,hz,acc_g,steps=15):
    xx=x.copy()
    for _ in range(steps):xx=plant_step(xx,u,2*math.pi*hz,acc_g*9810.,500.,14.,.0001)
    return xx


@njit(cache=True)
def xy_future(state,estimate,horizon_times):
    xx=state.copy();out=np.empty((len(horizon_times),2));now=0.
    lag=.001+1.4/(2*math.pi*300)
    for j in range(len(horizon_times)):
        while now+5e-5<horizon_times[j]:
            tau=now+lag
            p=estimate[:3]+estimate[3:6]*tau+.5*estimate[6:9]*tau*tau
            for a in range(2):
                target=min(12.,max(-12.,math.degrees(.5*math.atan2(p[a],p[2]))))
                xx[a]=plant_step(xx[a],target,2*math.pi*300,150000.,600.,12.,.0001)
            now+=.0001
        out[j]=xx[:,0]
    return out


def field_curve(theta,configuration):
    square=np.sum(np.asarray(theta)**2,axis=-1)
    if configuration=="front":return .01285*square
    return 254*(1/np.cos(2*np.sqrt(square)*math.pi/180)-1)


def baseline_parameters():
    return dict(k_lead=1.,lowpass_Hz=100.,lambda_u=.001,window_ratio=1.,K_dwell=4,beta_v=0.,use_future_angle=False,r_gate_over_rt=.6,z_gate_over_zR=1.,T_fix_ms=8.,p0=.7,p1=.95)


def candidate_parameters(method,point):
    q=baseline_parameters();u=np.asarray(point)
    q["lambda_u"]=10**(-4+3*u[2])
    if method in ("B0","B1"):
        q["k_lead"]=.5+u[0];q["lowpass_Hz"]=10**(1+u[1])
    if method in ("B2-pos","P3-control"):
        q["window_ratio"]=10**(2*u[3]);q["K_dwell"]=min(10,2+int(9*u[4]))
    if method in ("B2-vel","P3-control"):q["beta_v"]=10*u[5]
    if method in ("B2-fc","P3-control"):q["use_future_angle"]=True
    return q


@lru_cache(maxsize=32)
def prediction_matrices(hz):
    wn=2*math.pi*hz
    a=np.array([[0.,1.],[-wn*wn,-1.4*wn]])
    A=expm(a*.002);B=np.linalg.solve(a,(A-np.eye(2))@np.array([0.,wn*wn]))
    N=20;S=np.zeros((N,2,2));T=np.zeros((N,2,N));accS=np.zeros((N,2));accT=np.zeros((N,N));endS=np.zeros((N,2));endT=np.zeros((N,N))
    sx=np.eye(2);tx=np.zeros((2,N));C=np.array([-wn*wn,-1.4*wn])
    for k in range(N):
        accS[k]=C@sx;accT[k]=C@tx;accT[k,k]+=wn*wn
        sx=A@sx;tx=A@tx;tx[:,k]+=B
        S[k]=sx;T[k]=tx;endS[k]=C@sx;endT[k]=C@tx;endT[k,k]+=wn*wn
    difference=np.eye(N)
    for i in range(1,N):difference[i,i-1]=-1.
    return S[:,0],T[:,0],S[:,1],T[:,1],accS,accT,endS,endT,difference


class ZMPC:
    def __init__(self,hz,acc_g,D_mm,configuration,parameters):
        from p3_physics import beam
        self.hz=hz;self.amax=acc_g*9810.;self.configuration=configuration;self.par=parameters
        self.zr_mm=beam(D_mm)[1]*1000;self.scale=self.zr_mm/3.08
        self.Sz,self.Tz,self.Sv,self.Tv,self.Sa,self.Ta,self.Se,self.Te,self.Diff=prediction_matrices(hz)
        self.C=np.vstack((self.Tz/14,self.Tv/500,self.Ta/self.amax,self.Te/self.amax,np.eye(20)/14))
        self.solver_cache={};self.failures=0;self.calls=0;self.iterations=0;self.last_status="not_called";self.failure_records=[]

    def reset(self):
        for solver,_,_ in self.solver_cache.values():solver.warm_start(x=np.zeros(20),y=np.zeros(100))
        self.failures=0;self.calls=0;self.iterations=0

    def command(self,x,estimate,xy_state,previous_command):
        times=.0015+np.arange(1,21)*.002
        zref=estimate[2]+estimate[5]*times+.5*estimate[8]*times**2
        if self.par["use_future_angle"]:
            angles=xy_future(xy_state,estimate,times)
        else:angles=np.repeat(xy_state[:,0][None],20,axis=0)
        curve=field_curve(angles,self.configuration)
        reference=(zref-254+curve)/3.08
        reference_velocity=(estimate[5]+estimate[8]*times+np.gradient(curve,.002))/3.08
        x0=advance_z(x,previous_command,self.hz,self.amax/9810.)
        weights=np.ones(20)
        start=20-self.par["K_dwell"]
        if self.par["window_ratio"]!=1:
            # Reachability includes velocity saturation; bound uses full-force motion in each direction.
            upper=x0.copy();lower=x0.copy()
            for k in range(20):
                vhi=min(500.,upper[1]+self.amax*.002);vlo=max(-500.,lower[1]-self.amax*.002)
                upper[0]=min(14.,upper[0]+(upper[1]+vhi)*.001);upper[1]=vhi
                lower[0]=max(-14.,lower[0]+(lower[1]+vlo)*.001);lower[1]=vlo
                if lower[0]<=reference[k]+self.scale and upper[0]>=reference[k]-self.scale:
                    start=k;break
            weights[start:min(20,start+self.par["K_dwell"]+1)]=self.par["window_ratio"]
        else:start=-1
        key=start
        if key not in self.solver_cache:
            H=(self.Tz.T*weights)@self.Tz/self.scale**2
            H+=self.par["beta_v"]*(self.Tv.T@self.Tv)/(self.scale/.01)**2
            H+=self.par["lambda_u"]*(self.Diff.T@self.Diff)/self.scale**2
            solver=osqp.OSQP()
            solver.setup(P=sparse.csc_matrix(np.triu(2*H)),q=np.zeros(20),A=sparse.csc_matrix(self.C),l=-np.ones(100),u=np.ones(100),verbose=False,eps_abs=2e-5,eps_rel=2e-5,max_iter=4000,adaptive_rho_interval=50,check_termination=25,polishing=False,warm_starting=True)
            self.solver_cache[key]=(solver,weights.copy(),H)
        solver,weights,H=self.solver_cache[key]
        smooth=np.zeros(20);smooth[0]=-previous_command
        q=self.Tz.T@(weights*(self.Sz@x0-reference))/self.scale**2
        q+=self.par["beta_v"]*self.Tv.T@(self.Sv@x0-reference_velocity)/(self.scale/.01)**2
        q+=self.par["lambda_u"]*self.Diff.T@smooth/self.scale**2
        baseline=np.concatenate((self.Sz@x0/14,self.Sv@x0/500,self.Sa@x0/self.amax,self.Se@x0/self.amax,np.zeros(20)))
        solver.update(q=2*q,l=-1-baseline,u=1-baseline)
        result=solver.solve(raise_error=False)
        self.calls+=1;self.iterations+=result.info.iter;self.last_status=result.info.status
        # Status 2 (inaccurate) is accepted only after explicit primal constraint check.
        ok=result.info.status_val in (1,2) and result.x is not None and np.isfinite(result.x).all()
        if ok:ok=np.max(np.abs(self.C@result.x+baseline)-1)<=1e-3
        if not ok:
            self.failures+=1
            self.failure_records.append(dict(call=self.calls,status=result.info.status,status_val=result.info.status_val,primal_residual=float(result.info.prim_res),dual_residual=float(result.info.dual_res),feedback_state=x.tolist(),predicted_delayed_state=x0.tolist(),reference_first_mm=float(reference[0])))
            return float(np.clip(previous_command,-14,14)),False
        return float(np.clip(result.x[0],-14,14)),True


@njit(cache=True)
def integrate_block(z,xy,z_command,xy_command,hz,acc_g,steps):
    zz=np.empty((steps,2));xx=np.empty((steps,2,2))
    for i in range(steps):
        z=plant_step(z,z_command,2*math.pi*hz,acc_g*9810.,500.,14.,.0001)
        for axis in range(2):xy[axis]=plant_step(xy[axis],xy_command[axis],2*math.pi*300,150000.,600.,12.,.0001)
        zz[i]=z;xx[i]=xy
    return z,xy,zz,xx


def run_control(position_mm,states,valid,case,method,parameters,calibration_bias_mm=0.,return_series=False):
    from p3_physics import beam
    hz=case["z_Hz"];acc_g=case["a_g"];configuration=case["configuration"]
    mpc=None if method in ("B0","B1") else ZMPC(hz,acc_g,case["D_mm"],configuration,parameters)
    z=np.zeros(2);xy=np.zeros((2,2));z_history=np.zeros((4001,2));xy_history=np.zeros((4001,2,2))
    z_schedule=np.zeros(4021);xy_schedule=np.zeros((4021,2))
    active_z=0.;active_xy=np.zeros(2);lowpass=0.;previous_z=0.;last_encoder_z=0.;last_encoder_xy=np.zeros(2)
    qp_status=[]
    for tick in range(0,4000,5):
        if tick%10==0:
            index=tick//10;m=states[index]
            if valid[index]:
                delay=0 if method=="B0" else .001+1.4/(2*math.pi*300)
                pred=m[:3]+m[3:6]*delay+.5*m[6:9]*delay*delay
                target=np.clip(np.rad2deg(.5*np.arctan2(pred[:2],pred[2])),-12,12)
                xy_schedule[tick+10]=target
            else:xy_schedule[tick+10]=active_xy
        if tick%20==0:
            index=tick//10;m=states[index]
            enc_z=round(z[0]/.0005)*.0005
            enc_xy=np.round(xy[:,0]/(24/2**20))*(24/2**20)
            measured_z=np.array([enc_z,(enc_z-last_encoder_z)/.002])
            measured_xy=np.stack((enc_xy,(enc_xy-last_encoder_xy)/.002),axis=1)
            last_encoder_z=enc_z;last_encoder_xy=enc_xy
            if valid[index]:
                if method in ("B0","B1"):
                    lead=0 if method=="B0" else parameters["k_lead"]*(.0015+1.4/(2*math.pi*hz))
                    reference=(m[2]+m[5]*lead+.5*m[8]*lead*lead-254+float(field_curve(enc_xy,configuration)))/3.08
                    if method=="B0":lowpass=reference
                    else:lowpass+=(1-math.exp(-2*math.pi*parameters["lowpass_Hz"]*.002))*(reference-lowpass)
                    command=float(np.clip(lowpass,-14,14))
                else:
                    command,ok=mpc.command(measured_z,m,measured_xy,active_z);qp_status.append(ok)
                previous_z=command
            z_schedule[tick+15]=previous_z
        # Commands are held. Z arrivals occur at 1.5ms modulo 2ms; XY at each 1ms.
        if tick>=15 and (tick-15)%20==0:active_z=z_schedule[tick]
        if tick>=10 and tick%10==0:active_xy=xy_schedule[tick].copy()
        z,xy,zs,xs=integrate_block(z,xy,active_z,active_xy,hz,acc_g,5)
        z_history[tick+1:tick+6]=zs;xy_history[tick+1:tick+6]=xs
    actual_focus=254+3.08*z_history[:,0]-field_curve(xy_history[:,:,0],configuration)+calibration_bias_mm
    error=actual_focus-position_mm[:,2]
    spot_xy=position_mm[:,2,None]*np.tan(2*xy_history[:,:,0]*math.pi/180)
    lateral=np.linalg.norm(spot_xy-position_mm[:,:2],axis=1)
    zr=beam(case["D_mm"])[1]*1000;inside=np.abs(error)<=zr
    edges=np.diff(np.concatenate(([False],inside,[False])).astype(np.int8));durations=(np.flatnonzero(edges==-1)-np.flatnonzero(edges==1))*.1
    metrics=dict(dwell=float(inside.mean()),dwell_2zR=float((np.abs(error)<=2*zr).mean()),defocus_median_mm=float(np.median(np.abs(error))),defocus_RMSE_mm=float(np.sqrt(np.mean(error**2))),defocus_P95_mm=float(np.percentile(np.abs(error),95)),defocus_P95_zR=float(np.percentile(np.abs(error),95)/zr),lateral_RMSE_mm=float(np.sqrt(np.mean(lateral*lateral))),lateral_P95_mm=float(np.percentile(lateral,95)),longest_focus_ms=float(durations.max()) if len(durations) else 0.,focus_segment_mean_ms=float(durations.mean()) if len(durations) else 0.,qp_calls=mpc.calls if mpc else 0,qp_failures=mpc.failures if mpc else 0,qp_iterations=mpc.iterations if mpc else 0,position_limit_fraction=float((np.abs(z_history[:,0])>=14-1e-6).mean()),velocity_limit_fraction=float((np.abs(z_history[:,1])>=500-1e-6).mean()))
    if not np.isfinite(z_history).all() or not np.isfinite(xy_history).all() or not np.isfinite(list(metrics.values())).all():
        raise RuntimeError("AUTOMATIC STOP: non-finite control state or metric")
    metrics["qp_failure_details_json"]=json.dumps(mpc.failure_records if mpc else [])
    if return_series:return metrics,dict(z=z_history,xy=xy_history,focus_mm=actual_focus,defocus_mm=error,lateral_mm=lateral)
    return metrics
