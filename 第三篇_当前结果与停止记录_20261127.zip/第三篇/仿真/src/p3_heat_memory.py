"""Finite-disk surface heating at the target centre: radial quadrature and checked exponential tail."""
from pathlib import Path
import json
import math
import numpy as np
from scipy.special import erfc,i0e
from scipy.linalg import lstsq
from scipy.optimize import brentq
from numpy.polynomial.legendre import leggauss
from numba import njit

DT=.0001
KAPPA=.14e-6
K=.5
BASE=Path(__file__).resolve().parents[1]
TABLE=BASE/"inputs_frozen/thermal_kernel.npz"


def build_kernel():
    # Fixed before any method comparison. Source quadrature resolves the smallest 14.7um waist.
    radius=.00025;nr=128;direct=48;modes=56;maximum_lag=4000
    x,w=leggauss(nr);r=(x+1)*radius/2;weights=w*radius/2/K
    time=np.arange(maximum_lag+1)*DT
    S=np.zeros((maximum_lag+1,nr))
    S[1:]=erfc(r[None]/(2*np.sqrt(KAPPA*time[1:,None])))*weights
    H=np.diff(S,axis=0)
    rates=np.geomspace(.25,2000,modes)
    lags=np.arange(maximum_lag-direct)*DT
    E=np.exp(-lags[:,None]*rates[None])
    scales=np.maximum(np.max(H[direct:],axis=0),1e-100)
    coeff=lstsq(E,H[direct:]/scales,cond=1e-12,lapack_driver="gelsd")[0]*scales
    approx=E@coeff
    normalized_max=float(np.max(np.abs(approx-H[direct:])/scales))
    np.savez_compressed(TABLE,r=r,weights=weights,Hdirect=H[:direct],coeff=coeff,decay=np.exp(-rates*DT),rates=rates,kernel_exact=H,kernel_tail_error_relative_to_each_shell_peak=normalized_max)
    return normalized_max


def radial_flux(r,w,e,power_abs):
    return 2*power_abs/(math.pi*w*w)*np.exp(-2*((r-e)/w)**2)*i0e(4*r*e/(w*w))


@njit(cache=True)
def advance_kernel(ring,tail,head,count,source,H,coeff,decay):
    length=H.shape[0]
    tail=tail*decay
    if count>=length:
        old=ring[head]
        for j in range(len(tail)):
            for k in range(len(source)):tail[j]+=coeff[j,k]*old[k]
    ring[head]=source
    result=tail.sum()
    n=min(count+1,length)
    for lag in range(n):
        index=(head-lag)%length
        for k in range(len(source)):result+=H[lag,k]*ring[index,k]
    return tail,(head+1)%length,count+1,result


class HeatMemory:
    _table=None
    def __init__(self):
        if HeatMemory._table is None:HeatMemory._table=dict(np.load(TABLE))
        tab=HeatMemory._table
        self.r=tab["r"];self.weights=tab["weights"];self.H=tab["Hdirect"];self.coeff=tab["coeff"];self.decay=tab["decay"];self.rates=tab["rates"]
        self.ring=np.zeros_like(self.H);self.tail=np.zeros(len(self.rates));self.head=0;self.count=0;self.temperature=0.

    def copy(self):
        other=HeatMemory();other.ring=self.ring.copy();other.tail=self.tail.copy();other.head=self.head;other.count=self.count;other.temperature=self.temperature
        return other

    def at_fraction(self,dt,source):
        result=float((self.tail*np.exp(-self.rates*dt)).sum())
        if dt>0:result+=float((erfc(self.r/(2*np.sqrt(KAPPA*dt)))*self.weights)@source)
        n=min(self.count,len(self.H))
        if n:
            ages=np.arange(n)*DT+dt
            end=erfc(self.r[None]/(2*np.sqrt(KAPPA*(ages[:,None]+DT))))
            start=np.zeros_like(end)
            mask=ages>0
            start[mask]=erfc(self.r[None]/(2*np.sqrt(KAPPA*ages[mask,None])))
            history=self.ring[(self.head-1-np.arange(n))%len(self.H)]
            result+=float(np.sum((end-start)*self.weights[None]*history))
        return result

    def step(self,source,threshold=None):
        crossing=None
        if threshold is not None:
            next_value=self.at_fraction(DT,source)
            if (self.temperature<threshold<=next_value) or (self.temperature>=threshold>next_value):
                crossing=brentq(lambda t:self.at_fraction(t,source)-threshold,0,DT,xtol=1e-13)
        self.tail,self.head,self.count,self.temperature=advance_kernel(self.ring,self.tail,self.head,self.count,source,self.H,self.coeff,self.decay)
        return self.temperature,crossing


def selfcheck():
    from p3_physics import thermal_time,thermal_temperature
    if not TABLE.exists():build_kernel()
    tab=dict(np.load(TABLE));tests=[]
    for w in [14.7471697e-6,29.4943394e-6,.000140916,.000276,.001]:
        for offset in [0.,.5*w,2*w,.00025]:
            source=radial_flux(tab["r"],w,offset,.5)
            m=HeatMemory();values=[]
            for i in range(4000):values.append(m.step(source)[0])
            exact=np.cumsum(tab["kernel_exact"]@source)
            predicted=np.array(values)
            relevant=exact>=1.
            err=float(np.max(np.abs(predicted[relevant]-exact[relevant])/exact[relevant])) if relevant.any() else 0.
            tests.append(dict(check=f"memory_constant_w{w}_e{offset}",relative_error=err,passed=err<=.01))
            if offset==0:
                refs=np.array([thermal_temperature(t,w,50,.01,.00025) for t in [.0001,.001,.01,.1,.4]])
                actual=predicted[np.array([1,10,100,1000,4000])-1]
                error=float(np.max(np.abs(actual/refs-1)))
                tests.append(dict(check=f"radial_quad_vs_independent_w{w}",relative_error=error,passed=error<=.01))
    for w in [29.4943394058811e-6,140.91647892303178e-6,275.9848381968675e-6]:
        m=HeatMemory();source=radial_flux(m.r,w,0.,.5)
        expected=thermal_time(w,50,.01,60,.00025)
        # Query the exact finite radial Green function at arbitrary sub-grid times.
        crossed=brentq(lambda t:m.at_fraction(t,source)-60,expected*.1,expected*10,xtol=1e-14)
        error=abs(crossed/expected-1)
        tests.append(dict(check=f"substep_60K_crossing_{w}",relative_error=error,passed=error<=.01))
    rng=np.random.default_rng(20261128);m=HeatMemory();history=[];max_error=0.
    for i in range(4000):
        power=.5 if i%120<45 else 0.
        width=30e-6+200e-6*(.5+.5*math.sin(i*.004))
        offset=.0002*(.5+.5*math.sin(i*.009))
        source=radial_flux(m.r,width,offset,power);history.append(source)
        value=m.step(source)[0]
        if i%37==0:
            exact=float(np.sum(tab["kernel_exact"][:i+1]*np.asarray(history)[::-1]))
            if exact>=1:max_error=max(max_error,abs(value/exact-1))
    tests.append(dict(check="moving_defocused_pulsed_history",relative_error=max_error,passed=max_error<=.01))
    report=dict(status="passed" if all(t["passed"] for t in tests) else "failed",tests=tests,radial_nodes=len(tab["r"]),direct_history_steps=len(tab["Hdirect"]),exponential_modes=len(tab["rates"]),dt_s=DT)
    (BASE/"implementation_checks/thermal_memory_checkpoint.json").write_text(json.dumps(report,indent=2),encoding="utf-8")
    print(json.dumps(report),flush=True)
    if report["status"]!="passed":raise RuntimeError("AUTOMATIC STOP: dynamic thermal implementation self-check failed")


if __name__=="__main__":selfcheck()
