"""Independent physical-time convergence check for a moving, finite-target heat source."""
from pathlib import Path
import csv
import json
import numpy as np
from scipy.special import erfc
from p3_heat_memory import HeatMemory,radial_flux,KAPPA,DT
from p3_physics import beam

BASE=Path(__file__).resolve().parents[1]
OUT=BASE/"implementation_checks"


def independent_integral(step,w,speed,centre_time,end_time=.003):
    memory=HeatMemory()
    n=int(round(end_time/step))
    starts=np.arange(n)*step;ends=starts+step
    midpoint=(starts+ends)/2
    offsets=np.abs(speed*(midpoint-centre_time))
    # Source absorption alpha*P=0.05*50=2.5 W; finite disk radius=0.25mm.
    source=np.stack([radial_flux(memory.r,w,e,2.5) for e in offsets])
    younger=end_time-ends;older=end_time-starts
    old=erfc(memory.r[None]/(2*np.sqrt(KAPPA*older[:,None])))
    young=np.zeros_like(old);positive=younger>1e-15
    young[positive]=erfc(memory.r[None]/(2*np.sqrt(KAPPA*younger[positive,None])))
    return float(np.sum((old-young)*memory.weights[None]*source))


def main():
    rows=[]
    for D in [7,14]:
        w=beam(D)[0]
        for centre in [.002325,.00235,.002375]:
            fine=independent_integral(DT/128,w,1.,centre)
            previous=independent_integral(DT/64,w,1.,centre)
            ref_error=abs(previous/fine-1)
            memory=HeatMemory()
            for i in range(30):
                e=abs(((i+.5)*DT-centre)*1.)
                actual=memory.step(radial_flux(memory.r,w,e,2.5))[0]
            same_grid=independent_integral(DT,w,1.,centre)
            error=abs(actual/fine-1)
            rows.append(dict(D_mm=D,waist_um=w*1e6,target_radius_mm=.25,power_W=50,alpha=.05,relative_lateral_speed_m_s=1.,centre_crossing_time_ms=centre*1000,observation_time_ms=3.,implemented_dt_us=DT*1e6,reference_dt_us=DT/128*1e6,implemented_deltaT_K=actual,reference_deltaT_K=fine,same_grid_integral_deltaT_K=same_grid,reference_refinement_relative_error=ref_error,dynamic_time_relative_error=error,passed=ref_error<=.001 and error<=.01))
    with (OUT/"moving_heat_convergence.csv").open("w",encoding="utf-8-sig",newline="") as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    report=dict(stage="dynamic_thermal_time_convergence",status="passed" if all(r["passed"] for r in rows) else "failed",criterion="relative error <=1%; independent reference refinement <=0.1%",cases=len(rows),passed=sum(r["passed"] for r in rows),max_relative_error=max(r["dynamic_time_relative_error"] for r in rows),failed_rows=[i+2 for i,r in enumerate(rows) if not r["passed"]],automatic_stop_rule="supplement_section_3_item_1__spec_13_2_thermal_refinement")
    (OUT/"moving_heat_checkpoint.json").write_text(json.dumps(report,indent=2),encoding="utf-8")
    print(json.dumps(report),flush=True)
    if report["status"]!="passed":raise RuntimeError("AUTOMATIC STOP: moving-source thermal time-convergence exceeded 1 percent")


if __name__=="__main__":main()
