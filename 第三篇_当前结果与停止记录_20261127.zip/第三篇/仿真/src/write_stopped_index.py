"""Report and package the requested automatic stop. This script performs no simulation."""
from pathlib import Path
import csv
import hashlib
import importlib.metadata
import json
import platform
import sys
import zipfile

BASE=Path(__file__).resolve().parents[1]
def read_csv(path):
    with path.open(encoding="utf-8-sig",newline="") as f:return list(csv.DictReader(f))

checks=BASE/"implementation_checks"
moving=read_csv(checks/"moving_heat_convergence.csv")
control=read_csv(checks/"control_selfchecks.csv")
worst=max(enumerate(moving,start=2),key=lambda x:float(x[1]["dynamic_time_relative_error"]))
state={"status":"AUTOMATIC_STOP_WAITING_FOR_INSTRUCTION","date":"2026-11-27","stop_reason":"Moving-source thermal input time convergence failed spec 13.2 <=1% tolerance", "trigger_file":"implementation_checks/moving_heat_checkpoint.json", "maximum_relative_error":float(worst[1]["dynamic_time_relative_error"]),"maximum_error_source_row":worst[0],"simulations_running":False,"manual_interstage_review_required":False,"stop_authority":"第三篇_一次性运行补充指令.md section 3 item 1", "next_work":"Improve thermal-input time integration independently of the fixed 0.1ms control/plant grid; revalidate before pilot/A/B/C", "stages":{"P0":{"status":"complete","completed":478368,"expected":478368},"trajectory_inputs":{"status":"complete","completed":160,"expected":160},"pilot":{"status":"not_started","completed":0,"expected":100},"A_training":{"status":"not_started","completed":0,"expected":53760},"A_test":{"status":"not_started","completed":0,"expected":95760},"B":{"status":"not_started","completed":0,"expected":None,"reason":"formal policy manifest not generated before the implementation stop"},"C":{"status":"not_started","completed":0,"expected":None,"reason":"formal run manifest not generated before the implementation stop"}}}
(BASE/"run_state.json").write_text(json.dumps(state,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")

detail=["# 实现检查 results_for_writing", "", "这些是程序验收记录，不能用作S2/S3/S4的效果数据。Python数值检查，非Zemax、非实测；确定性检查无抽样CI。", "", "| 编号 | 数值 | 95%CI | 条件与来源 |", "|---|---|---|---|"]
detail.append(f"| [R-CHECK-01] | 移动热源6个收敛算例，0个满足≤1%要求 | NA：确定性检查 | moving_heat_convergence.csv第2～7行；D7/D14、50W、α5%、1m/s、r_t=0.25mm、三种过中心时刻 |")
detail.append(f"| [R-CHECK-02] | 最大温升相对差 {100*float(worst[1]['dynamic_time_relative_error']):.9g}% | NA：确定性检查 | moving_heat_convergence.csv第{worst[0]}行；D14、3ms观察时刻、100μs热输入网格与0.78125μs参考 |")
detail.append(f"| [R-CHECK-03] | 该例计算温升 {float(worst[1]['implemented_deltaT_K']):.12g}K，参考 {float(worst[1]['reference_deltaT_K']):.12g}K；参考再加密相对差 {float(worst[1]['reference_refinement_relative_error']):.9g} | NA：确定性检查 | 同上；是线性热模型数学自检值，超出高温物理适用域，不作真实组织温度解释 |")
for index,(line,row) in enumerate([(i+2,r) for i,r in enumerate(control) if r['check'].startswith('MPC_fail_rate')],start=4):
    detail.append(f"| [R-CHECK-{index:02d}] | QP调用失败率 {100*float(row['value']):.9g}% | NA：实现检查集；非正式测试CI | {row['check']}；40条训练轨迹、固定盲窗；control_selfchecks.csv第{line}行 |")
detail += ["", "## 不成立或增益消失的结果", "", "当前‘0.1ms内热源视为恒定’的实现未通过移动光斑时间收敛检查。固定热输入离散核的一致性检查通过，不能替代连续运动热源的时间加密检查。", "", "尚未运行A/B/C正式比较；不存在可引用的控制增益、门控增益或作业完成率。", "", "## 自动停止", "", "补充指令第3节规定自检失败后停下报告并等待指示，已执行。未继续启动试点或批量仿真；参数没有为通过检查而修改。"]
(checks/"results_for_writing.md").write_text("\n".join(detail)+"\n",encoding="utf-8")

index="""# 第三篇仿真总索引

**状态：自动检查失败后停止；没有全跑完。** 记录日期：2026-11-27（Asia/Shanghai）。

## 从这里查看

1. [自动停止的数值证据](implementation_checks/results_for_writing.md)
2. [P0可引用数值](out_P0/results_for_writing.md)
3. [冻结参数v1.2](src/params_p3_run_v1_2.json)
4. [机器可读总状态](run_state.json)

## 各阶段完成情况

| 阶段 | 完成/应完成 | 当前状态 |
|---|---:|---|
| P0静态记录 | 478368/478368 | 完成；111项自检通过 |
| 轨迹输入 | 160/160 | 完成；位置回复OU、边缘径向运动、拒绝采样验收通过 |
| 估计器验收 | 6/6项通过 | 40条训练轨迹×两种盲窗；未视为A正式调参 |
| 控制器验收 | 139/139项通过 | 40条训练轨迹×3代表工况×2次重复；非A正式结果 |
| 动态热源时间收敛 | 0/6项通过 | **触发停止** |
| 试点 | 0/100 | 未启动；无总耗时估计 |
| A训练候选评估 | 0/53760 | 未启动 |
| A留出测试 | 0/95760 | 未启动 |
| B | 未启动，正式策略运行清单尚未生成 | 不以0/0冒充完成 |
| C | 未启动，正式运行清单尚未生成 | 不以0/0冒充完成 |

## 为什么停止

补充指令第3节第1项要求：§13.2任一自检不通过即停止并报告。本次失败的是**随光斑运动变化的热输入时间离散**。

测试条件使用本项目的D7/D14、50W、吸收率5%、目标半径0.25mm、相对横向速度1m/s。每个0.1ms步内，光斑中心相对目标移动100μm；D14的1/e²直径约29.5μm。将整步热输入取一个代表值，可能跳过或过度采中光斑中心。6个相位/口径测试的温升相对差约5.86%～160.17%，均超过1%。

逐例数据：[moving_heat_convergence.csv](implementation_checks/moving_heat_convergence.csv)。独立参考采用0.78125μs步长，继续与1.5625μs结果比较，参考温升相对差均小于0.000031%。同一0.1ms网格的直接格林积分与压缩记忆核结果一致，因此目前定位到热源时间采样。高温数值仅用于线性方程的数值验证，不表示真实组织可达到这些温度。

下一项工作应保持规定的运动/控制网格，给热输入增加足够细或自适应的区间积分，并重新通过温升与首次阈值时间收敛检查；之后才能继续100次试点和A/B/C。此次按停止指令保留现场，未改物理参数或降低1%门限。

## 自检记录

- [P0独立热、截获和背景积分检查](out_P0/selfchecks.csv)
- [OU分量的无机动平稳统计检查](inputs_frozen/trajectory_stationary_check.csv)：每种分量1000条，最大标准差相对偏差约1.46%。
- [160条轨迹验收表](inputs_frozen/trajectory_manifest.csv)：没有替换失败种子。
- [估计器检查](implementation_checks/estimator_selfchecks.csv)：乱序回放与按采样顺序更新一致；重复运行一致；主工况RMSE/量测折算误差分别约3.80和4.52，低于5。
- [控制器检查](implementation_checks/control_selfchecks.csv)：零附加项退化一致，RK4核验及重复运行通过；三代表工况QP失败率均低于1%。
- [固定离散热输入的记忆核检查](implementation_checks/thermal_memory_checkpoint.json)：通过；它没有检验输入随时间运动时的采样误差，不能覆盖下面一项。
- [动态热输入时间收敛检查](implementation_checks/moving_heat_checkpoint.json)：失败，停止依据。

此前控制检查脚本曾误把1%门限按单条轨迹而不是方法×工况应用；原记录在implementation_checks/control_check_attempt01_per_trajectory_grouping/，保留未删。修正统计口径后重新检查了全部40条训练轨迹，没有因此调整控制器参数。

## P0原始数据与图

- [静态逐条件记录](out_P0/static_threshold_times.csv)
- [参考值逐项对照](out_P0/thermal_reference_comparison.csv)
- [穿焦时间比](out_P0/focus_crossing_ratios.csv)、[条件判据与跨界区间](out_P0/defocus_boundaries.csv)
- [背景稀释](out_P0/background_dilution.csv)、[焦点后移的背景辐照度](out_P0/background_focus_shift.csv)
- [静态阈值图](out_P0/static_threshold_times.png)、[背景敏感度图](out_P0/background_focus_shift.png)；同名SVG可编辑。
- [P0日志](out_P0/run_log.md)、[P0清单](out_P0/manifest.json)

## 跨阶段的不成立或增益消失结果汇总

- P0中，M-E有34799条静态记录不可达，M-I有81810条不可达；完整网格及计量口径不同，不将记录数直接解释为方法胜负。M-T本次静态参数均可达到模型阈值，不能推断实际致死效果。
- 当前动态热输入实现未达到规定的时间收敛精度。
- A/B/C未运行，没有S2/S3/S4正向或负向增益结果；不得由写作方补齐数字或作机制去留判断。

## 工具与复现

Python数值仿真，非Zemax、非实物测量。环境版本见[environment.json](environment.json)。参数、源代码、输入与结果哈希见[PROVENANCE.json](PROVENANCE.json)。自动停止状态保持在run_state.json；当前没有后台仿真进程。

P0入口src/run_p0.py；轨迹入口src/p3_trajectories.py；验收入口src/check_estimator.py、src/check_control.py、src/p3_heat_memory.py、src/check_moving_heat_convergence.py。control相关脚本使用本项目.venv_run解释器及OSQP。B/C批量执行器尚未完成，不能把这些入口当作一条已经完成的全阶段流水线。

原v1.1/G0审阅包留存为历史；本次执行优先级为用户最新指令、一次性补充指令、G0审核意见、v1.1。原人工中途关口已经取消；本次停止只因自动自检异常。
"""
(BASE/"总索引.md").write_text(index,encoding="utf-8")
env={"python":sys.version,"executable":sys.executable,"platform":platform.platform(),"packages":{name:importlib.metadata.version(name) for name in ["numpy","scipy","numba","matplotlib","osqp"]},"OSQP_API_reference":"https://osqp.org/docs/interfaces/python.html","date":"2026-11-27"}
(BASE/"environment.json").write_text(json.dumps(env,ensure_ascii=False,indent=2),encoding="utf-8")

# Add deterministic P0 grid counts to the numbered writing handoff; no new computation.
p0=BASE/"out_P0/results_for_writing.md"
text=p0.read_text(encoding="utf-8")
if "[R-P0-10]" not in text:
    text+="\n## 静态网格完整性（不是随机完成率）\n\n| 编号 | 数值 | 95%CI | 来源 |\n|---|---|---|---|\n"
    for number,row in enumerate(read_csv(BASE/"out_P0/model_status_counts.csv"),start=10):
        text+=f"| [R-P0-{number}] | {row['model']}：可达{row['reachable']}条，不可达{row['unreachable']}条 | NA：确定性网格计数 | model_status_counts.csv第{number-8}行；参数详见static_threshold_times.csv |\n"
    p0.write_text(text,encoding="utf-8")

files=[BASE/name for name in ["总索引.md","run_state.json","environment.json","第三篇_仿真设计说明书_v1.1.md","v1.1_修改映射与G0核对.md"]]
for directory in ["src","参考输入","out_P0","inputs_frozen","implementation_checks"]:
    for path in (BASE/directory).rglob("*"):
        if path.is_file() and "__pycache__" not in path.parts and path.suffix not in (".pyc",".nbc",".nbi"):
            files.append(path)
files=sorted(set(files))
provenance={"status":state["status"],"files":[{"path":str(f.relative_to(BASE)).replace("\\","/"),"bytes":f.stat().st_size,"sha256":hashlib.sha256(f.read_bytes()).hexdigest()} for f in files]}
(BASE/"PROVENANCE.json").write_text(json.dumps(provenance,ensure_ascii=False,indent=2),encoding="utf-8")
files.append(BASE/"PROVENANCE.json")
destination=Path(r"F:\激光动态聚焦系统\第三篇\仿真\第三篇_当前结果与停止记录_20261127.zip")
with zipfile.ZipFile(destination,"w",compression=zipfile.ZIP_DEFLATED) as archive:
    for f in files:archive.write(f,Path("第三篇/仿真")/f.relative_to(BASE))
with zipfile.ZipFile(destination) as archive:
    assert archive.testzip() is None
    for item in provenance["files"]:
        content=archive.read("第三篇/仿真/"+item["path"])
        assert hashlib.sha256(content).hexdigest()==item["sha256"]
print(json.dumps({"index":str(BASE/"总索引.md"),"package":str(destination),"files":len(files),"bytes":destination.stat().st_size,"sha256":hashlib.sha256(destination.read_bytes()).hexdigest(),"status":state["status"]},ensure_ascii=False))
