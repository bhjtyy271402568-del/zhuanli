from pathlib import Path
import json
import csv
import numpy as np
from scipy.linalg import expm
from p3_control import ZMPC,baseline_parameters,plant_step,run_control
from p3_estimator import observer_series

BASE=Path(__file__).resolve().parents[1]
OUT=BASE/"implementation_checks"


def main():
    checks=[]
    # Unsaturated RK4 agrees with exact ZOH at the fixed truth timestep.
    for hz in [25,30,40,80,150,300]:
        wn=2*np.pi*hz;a=np.array([[0,1],[-wn*wn,-1.4*wn]])
        A=expm(a*.0001);B=np.linalg.solve(a,(A-np.eye(2))@np.array([0.,wn*wn]))
        x=np.array([.01,.02]);u=.0101
        actual=plant_step(x,u,wn,1e12,1e12,1e12,.0001);reference=A@x+B*u
        error=float(np.max(np.abs(actual-reference)))
        checks.append(dict(check=f"RK4_matches_exact_unsaturated_{hz}",passed=error<1e-6,value=error))
    for hz in [25,150]:
        p=baseline_parameters();m=np.array([25.,5.,258.,150.,100.,600.,0.,0.,1000.]);xy=np.array([[2.,10.],[.5,3.]]);x=np.array([.2,50.])
        commands=[]
        for method in ["B1-MPC","B2-pos-zero","B2-vel-zero","B2-fc-frozen"]:
            solver=ZMPC(hz,4,7,"front",p.copy());command,ok=solver.command(x,m,xy,0.)
            commands.append(command)
            checks.append(dict(check=f"ablation_solver_{method}_{hz}",passed=ok,value=float(solver.failures)))
        err=float(np.ptp(commands));checks.append(dict(check=f"zero_additions_equal_generic_MPC_{hz}",passed=err<1e-10,value=err))
    rows=[]
    for seed in range(1000,1040):
        d=np.load(BASE/f"inputs_frozen/trajectories/{seed}.npz")
        states,_,valid,_=observer_series(d["position_mm"],seed,"A1",.5,True)
        for D,hz,acc,config in [(7,30,4,"front"),(14,25,3,"post"),(7,150,6,"front")]:
            case=dict(D_mm=D,z_Hz=hz,a_g=acc,configuration=config)
            results=[]
            for repeat in range(2):
                metric=run_control(d["position_mm"],states,valid,case,"B1-MPC",baseline_parameters(),float(d["calibration_residual_mm"]))
                results.append(metric)
            equal=results[0]==results[1]
            checks.append(dict(check=f"control_repeat_{seed}_{D}_{hz}_{config}",passed=equal,value=0. if equal else 1.))
            rows.append(dict(seed=seed,**case,**results[0]))
        if (seed-999)%5==0:print(f"Control validation trajectories {seed-999}/40",flush=True)
    for D,hz,acc,config in [(7,30,4,"front"),(14,25,3,"post"),(7,150,6,"front")]:
        group=[r for r in rows if r["D_mm"]==D and r["z_Hz"]==hz and r["a_g"]==acc and r["configuration"]==config]
        fraction=sum(r["qp_failures"] for r in group)/sum(r["qp_calls"] for r in group)
        checks.append(dict(check=f"MPC_fail_rate_B1_MPC_D{D}_{hz}Hz_{acc}g_{config}",passed=fraction<=.01,value=fraction))
    for name,data in [("control_selfchecks.csv",checks),("control_development_runs.csv",rows)]:
        with (OUT/name).open("w",encoding="utf-8-sig",newline="") as f:
            w=csv.DictWriter(f,fieldnames=list(data[0]));w.writeheader();w.writerows(data)
    failures=[x for x in checks if not x["passed"]]
    report=dict(status="failed" if failures else "passed",checks=len(checks),failed=failures)
    (OUT/"control_checkpoint.json").write_text(json.dumps(report,indent=2),encoding="utf-8")
    print(json.dumps(report),flush=True)
    if failures:raise RuntimeError("AUTOMATIC STOP: control checkpoint failed")


if __name__=="__main__":main()
