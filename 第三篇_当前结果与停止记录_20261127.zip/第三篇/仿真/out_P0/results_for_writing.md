# results_for_writing — P0

工具：Python数值仿真，非Zemax、非实物测量。数值是代理模型计算，不是昆虫实测致死率。

| 编号 | 数值 | 95%CI | 工况与来源 |
|---|---|---|---|
| [R-P0-01] | w=29.4943394 μm；z_R=2.14044635 mm；到60K 0.0377114171 μs | NA：确定性解析值；独立积分相对误差6.66e-16 | D7、离焦0mm、50W、α1%、无限面源；thermal_reference_comparison.csv第2行 |
| [R-P0-02] | w=140.916479 μm；z_R=2.14044635 mm；到60K 19.6640148 μs | NA：确定性解析值；独立积分相对误差6.66e-16 | D7、离焦10mm、50W、α1%、无限面源；thermal_reference_comparison.csv第3行 |
| [R-P0-03] | w=275.984838 μm；z_R=0.535111586 mm；到60K 289.919224 μs | NA：确定性解析值；独立积分相对误差9.55e-15 | D14、离焦10mm、50W、α1%、无限面源；thermal_reference_comparison.csv第4行 |
| [R-P0-04] | w_bg=0.689607399 mm，稀释比546.671557；未衰减峰值I=6693.39264 W/cm² | NA：确定性计算 | D7、焦后50mm；background_dilution.csv第2行；50W未扣吸收与5%吸收列分开 |
| [R-P0-05] | w_bg=1.37826838 mm，稀释比2183.68623；未衰减峰值I=1675.64704 W/cm² | NA：确定性计算 | D7、焦后100mm；background_dilution.csv第3行；50W未扣吸收与5%吸收列分开 |
| [R-P0-06] | w_bg=2.06713956 mm，稀释比4912.04401；未衰减峰值I=744.921537 W/cm² | NA：确定性计算 | D7、焦后150mm；background_dilution.csv第4行；50W未扣吸收与5%吸收列分开 |
| [R-P0-07] | w_bg=1.37803167 mm，稀释比8731.74491；未衰减峰值I=1676.22275 W/cm² | NA：确定性计算 | D14、焦后50mm；background_dilution.csv第5行；50W未扣吸收与5%吸收列分开 |
| [R-P0-08] | w_bg=2.75594497 mm，稀释比34923.9797；未衰减峰值I=419.091686 W/cm² | NA：确定性计算 | D14、焦后100mm；background_dilution.csv第6行；50W未扣吸收与5%吸收列分开 |
| [R-P0-09] | w_bg=4.13388457 mm，稀释比78577.7042；未衰减峰值I=186.265934 W/cm² | NA：确定性计算 | D14、焦后150mm；background_dilution.csv第7行；50W未扣吸收与5%吸收列分开 |

## 不成立或增益消失的结果

尚未比较控制器，因此无S2/S3/S4增益结果。M-E和M-I部分代理门槛因稳态弛豫上限或辐照度门槛无法达到，详见model_status_counts.csv和原始表status=unreachable；这些行没有删去，也没有填NaN/Inf。

任务书约0.04μs的参考为低有效位舍入；本轮精确公式得到0.0377114μs，给值相对差约5.72%，独立积分与未舍入解析式误差远小于1%。不将舍入差说成热求解器误差。19.7和290μs同样保留原参考与计算差。

全条件T_threshold/T_cross逐点表见focus_crossing_ratios.csv；条件跨界与0～10mm全范围判据见defocus_boundaries.csv。本执行方只提供每个条件的true/false，不替审核方决定机制去留。

## 图说明

- static_threshold_times：P50W、α5%、目标半径0.25mm，按补充指令各模型主点比较离焦与模型阈值时间。
- background_focus_shift：固定背景在目标后100mm，焦点后移时的背景峰值I；灰线仅为工程扫描限额，没有作物实验验证。

数值原表行号从含表头的第1行计；确定性值不构造Bootstrap CI。

## 静态网格完整性（不是随机完成率）

| 编号 | 数值 | 95%CI | 来源 |
|---|---|---|---|
| [R-P0-10] | M-E：可达73921条，不可达34799条 | NA：确定性网格计数 | model_status_counts.csv第2行；参数详见static_threshold_times.csv |
| [R-P0-11] | M-I：可达266094条，不可达81810条 | NA：确定性网格计数 | model_status_counts.csv第3行；参数详见static_threshold_times.csv |
| [R-P0-12] | M-T：可达21744条，不可达0条 | NA：确定性网格计数 | model_status_counts.csv第4行；参数详见static_threshold_times.csv |
